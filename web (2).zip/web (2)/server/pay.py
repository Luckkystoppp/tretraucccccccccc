#!/usr/bin/env python3
"""
TreTrauChecker — Payment Bot (pay.py)
Chỉ file này polling token payment bot. server.js dùng polling=false.
Chỉ ADMIN_ID mới được approve/reject.
"""

import json, os, sys, atexit, requests, telebot
from telebot import types

BOT_TOKEN  = '8853294820:AAFI4aP8EJ0uDxtkbq-PKmXDLEVNNIQKI_s'
ADMIN_ID   = 7490574579
SERVER_URL = 'http://localhost:3456'

# ── PID lock — tránh chạy 2 instance cùng lúc ────────────────────────────────
_BASE = os.path.join(os.path.dirname(__file__), '..', 'data')
PID_FILE = os.path.join(_BASE, 'pay.pid')
if os.path.exists(PID_FILE):
    try:
        old_pid = int(open(PID_FILE).read().strip())
        os.kill(old_pid, 0)          # check if alive
        os.kill(old_pid, 15)         # SIGTERM
        print(f'[PID] Killed old instance {old_pid}')
    except (ProcessLookupError, ValueError):
        pass
open(PID_FILE, 'w').write(str(os.getpid()))
atexit.register(lambda: os.path.exists(PID_FILE) and os.remove(PID_FILE))

# ── Đọc PAY_SECRET từ file (server.js tự gen và lưu vào đây) ─────────────────
_secret_file = os.path.join(_BASE, '.pay_secret')
try:
    PAY_SECRET = open(_secret_file).read().strip()
except FileNotFoundError:
    print(f'[ERROR] .pay_secret not found at {_secret_file}. Start server.js first.')
    sys.exit(1)

bot = telebot.TeleBot(BOT_TOKEN, parse_mode='Markdown')
HEADERS = {'x-pay-secret': PAY_SECRET, 'Content-Type': 'application/json'}

# ── Helpers ──────────────────────────────────────────────────────────────────
def api_post(path, data=None):
    try:
        r = requests.post(f'{SERVER_URL}{path}', json=data or {}, headers=HEADERS, timeout=10)
        return r.json()
    except Exception as e:
        return {'success': False, 'message': str(e)}

def api_get(path):
    try:
        r = requests.get(f'{SERVER_URL}{path}', headers=HEADERS, timeout=10)
        return r.json()
    except Exception as e:
        return {'success': False, 'message': str(e)}

def is_admin(user_id):
    """Chỉ admin ID mới được duyệt đơn."""
    return user_id == ADMIN_ID

def approve_buttons(order_id):
    markup = types.InlineKeyboardMarkup()
    markup.row(
        types.InlineKeyboardButton('✅ Duyệt',    callback_data=f'approve_{order_id}'),
        types.InlineKeyboardButton('❌ Từ chối',  callback_data=f'reject_{order_id}')
    )
    return markup

# ── Callback: nút bấm ────────────────────────────────────────────────────────
@bot.callback_query_handler(func=lambda call: True)
def handle_callback(call):
    user_id  = call.from_user.id
    username = call.from_user.username or call.from_user.first_name or f'id_{user_id}'
    data     = call.data

    # Bắt buộc phải là admin group
    if not is_admin(user_id):
        bot.answer_callback_query(call.id, '🚫 Chỉ admin group mới có quyền duyệt đơn!', show_alert=True)
        return

    if data.startswith('approve_'):
        order_id = data.replace('approve_', '').upper()
        res = api_post(f'/internal/approve/{order_id}', {'approvedBy': username})

        if res.get('success'):
            order = res['order']
            bal   = res['newBalance']
            bot.answer_callback_query(call.id, '✅ Đã duyệt!', show_alert=False)
            bot.edit_message_text(
                f'✅ *ĐÃ DUYỆT #* `{order_id}`\n\n'
                f'👤 User: *{order["username"]}*\n'
                f'💰 +*{order["credits"]}* credits\n'
                f'Số dư mới: *{bal}* credits\n'
                f'━━━━━━━━━━━━━━\n'
                f'👮 Duyệt bởi: @{username}',
                chat_id=call.message.chat.id,
                message_id=call.message.message_id,
                parse_mode='Markdown',
                reply_markup=None
            )
        else:
            bot.answer_callback_query(call.id, f'❌ {res.get("message","Lỗi")}', show_alert=True)

    elif data.startswith('reject_'):
        order_id = data.replace('reject_', '').upper()
        res = api_post(f'/internal/reject/{order_id}', {'rejectedBy': username})

        if res.get('success'):
            bot.answer_callback_query(call.id, '❌ Đã từ chối', show_alert=False)
            bot.edit_message_text(
                f'❌ *ĐÃ TỪ CHỐI #* `{order_id}`\n\n'
                f'👮 Từ chối bởi: @{username}',
                chat_id=call.message.chat.id,
                message_id=call.message.message_id,
                parse_mode='Markdown',
                reply_markup=None
            )
        else:
            bot.answer_callback_query(call.id, f'❌ {res.get("message","Lỗi")}', show_alert=True)

# ── /approve (text command) ───────────────────────────────────────────────────
@bot.message_handler(commands=['approve'])
def cmd_approve(msg):
    if not is_admin(msg.from_user.id):
        return bot.reply_to(msg, '🚫 Chỉ admin group mới có quyền duyệt đơn!')
    parts    = msg.text.strip().split()
    approver = msg.from_user.username or f'id_{msg.from_user.id}'
    if len(parts) < 2:
        return bot.reply_to(msg, '❌ Usage: /approve ORDER\\_ID')
    order_id = parts[1].upper()
    res = api_post(f'/internal/approve/{order_id}', {'approvedBy': approver})
    if res.get('success'):
        o = res['order']
        bot.reply_to(msg,
            f'✅ *ĐÃ DUYỆT #{order_id}*\n\n'
            f'👤 *{o["username"]}* → +*{o["credits"]}* credits\n'
            f'Số dư mới: *{res["newBalance"]}*\n'
            f'👮 Duyệt bởi: @{approver}')
    else:
        bot.reply_to(msg, f'❌ {res.get("message","Lỗi")}')

# ── /reject (text command) ────────────────────────────────────────────────────
@bot.message_handler(commands=['reject'])
def cmd_reject(msg):
    if not is_admin(msg.from_user.id):
        return bot.reply_to(msg, '🚫 Chỉ admin group mới có quyền từ chối đơn!')
    parts    = msg.text.strip().split()
    rejector = msg.from_user.username or f'id_{msg.from_user.id}'
    if len(parts) < 2:
        return bot.reply_to(msg, '❌ Usage: /reject ORDER\\_ID')
    order_id = parts[1].upper()
    res = api_post(f'/internal/reject/{order_id}', {'rejectedBy': rejector})
    if res.get('success'):
        bot.reply_to(msg, f'❌ *ĐÃ TỪ CHỐI #{order_id}*\n\n👮 Bởi: @{rejector}')
    else:
        bot.reply_to(msg, f'❌ {res.get("message","Lỗi")}')

# ── /orders ───────────────────────────────────────────────────────────────────
@bot.message_handler(commands=['orders'])
def cmd_orders(msg):
    if not is_admin(msg.from_user.id):
        return bot.reply_to(msg, '🚫 Chỉ admin mới xem được danh sách đơn!')
    res = api_get('/internal/orders/pending')
    if not res.get('success'):
        return bot.reply_to(msg, f'❌ {res.get("message","Lỗi")}')
    orders = res['orders']
    if not orders:
        return bot.reply_to(msg, '📭 Không có đơn pending.')
    for o in orders:
        bot.send_message(
            msg.chat.id,
            f'💳 *Đơn #* `{o["orderId"]}`\n'
            f'👤 *{o["username"]}*  💰 {o["credits"]}cr  💱 {o["method"]}',
            reply_markup=approve_buttons(o['orderId'])
        )

# ── /addcredit ────────────────────────────────────────────────────────────────
@bot.message_handler(commands=['addcredit', 'addcredits'])
def cmd_addcredit(msg):
    if not is_admin(msg.from_user.id):
        return bot.reply_to(msg, '🚫 Chỉ admin mới có quyền này!')
    parts = msg.text.strip().split()
    if len(parts) < 3:
        return bot.reply_to(msg, '❌ Usage: /addcredit username amount')
    username, amount = parts[1].lower(), parts[2]
    if not amount.replace('.','',1).isdigit():
        return bot.reply_to(msg, '❌ Amount phải là số.')
    res = api_post('/internal/addcredit', {'username': username, 'amount': float(amount)})
    if res.get('success'):
        bot.reply_to(msg, f'✅ +*{amount}* credits → *{username}*\nSố dư mới: *{res["newBalance"]}*')
    else:
        bot.reply_to(msg, f'❌ {res.get("message","Lỗi")}')

# ── /ban ──────────────────────────────────────────────────────────────────────
@bot.message_handler(commands=['ban'])
def cmd_ban(msg):
    if not is_admin(msg.from_user.id):
        return bot.reply_to(msg, '🚫 Chỉ admin mới có quyền ban!')
    parts = msg.text.strip().split()
    if len(parts) < 2:
        return bot.reply_to(msg, '❌ Usage: /ban username [ip]')
    username = parts[1].lower()
    ip       = parts[2] if len(parts) > 2 else None
    res = api_post('/internal/ban', {'username': username, 'ip': ip})
    if res.get('success'):
        reply = f'🚫 *Đã ban:* `{username}`'
        if ip: reply += f'\nIP: `{ip}`'
        bot.reply_to(msg, reply)
    else:
        bot.reply_to(msg, f'❌ {res.get("message","Lỗi")}')

# ── /balance ──────────────────────────────────────────────────────────────────
@bot.message_handler(commands=['balance'])
def cmd_balance(msg):
    parts = msg.text.strip().split()
    if len(parts) < 2:
        return bot.reply_to(msg, '❌ Usage: /balance username')
    DB_PATH = os.path.join(os.path.dirname(__file__), '..', 'data', 'db.json')
    try:
        db   = json.load(open(DB_PATH))
        user = db['users'].get(parts[1].lower())
        if not user:
            return bot.reply_to(msg, '❌ User không tồn tại.')
        bot.reply_to(msg,
            f'💰 *{user["username"]}*\n'
            f'Credits: *{user["credits"]}* (${user["credits"]*0.1:.2f})\n'
            f'Plan: *{user["plan"]}*')
    except Exception as e:
        bot.reply_to(msg, f'❌ {e}')

# ── /help ─────────────────────────────────────────────────────────────────────
@bot.message_handler(commands=['help', 'start'])
def cmd_help(msg):
    bot.reply_to(msg,
        '🛡️ *TreTrauChecker Pay Bot*\n\n'
        '*(Chỉ admin group mới duyệt được)*\n\n'
        '/approve ID       — Duyệt đơn + cộng credit\n'
        '/reject ID        — Từ chối đơn\n'
        '/orders           — Danh sách đơn pending\n'
        '/addcredit USER N — Cộng credit thủ công\n'
        '/ban USER \\[IP\\]   — Ban tài khoản/IP\n'
        '/balance USER     — Xem số dư')

if __name__ == '__main__':
    print('💳 Pay bot started — only this process polls.')
    bot.infinity_polling(timeout=30, long_polling_timeout=20)
