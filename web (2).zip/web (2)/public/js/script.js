// ===== PARTICLES =====
function createParticles() {
    const container = document.getElementById('particles');
    for (let i = 0; i < 40; i++) {
        const particle = document.createElement('div');
        particle.className = 'particle';
        particle.style.left = Math.random() * 100 + '%';
        particle.style.animationDelay = Math.random() * 8 + 's';
        particle.style.animationDuration = (6 + Math.random() * 6) + 's';
        particle.style.width = particle.style.height = (2 + Math.random() * 3) + 'px';
        container.appendChild(particle);
    }
}

// ===== NAVBAR SCROLL =====
function initNavbar() {
    const navbar = document.querySelector('.navbar');
    const links = document.querySelectorAll('.nav-links a');
    const mobileToggle = document.getElementById('mobileToggle');
    const navLinks = document.querySelector('.nav-links');

    window.addEventListener('scroll', () => {
        navbar.classList.toggle('scrolled', window.scrollY > 50);
        
        // Active link
        const sections = document.querySelectorAll('section');
        let current = '';
        sections.forEach(section => {
            const top = section.offsetTop - 100;
            if (window.scrollY >= top) current = section.getAttribute('id');
        });
        links.forEach(link => {
            link.classList.toggle('active', link.getAttribute('href') === '#' + current);
        });
    });

    mobileToggle.addEventListener('click', () => {
        navLinks.classList.toggle('active');
    });

    // Smooth scroll
    links.forEach(link => {
        link.addEventListener('click', (e) => {
            navLinks.classList.remove('active');
        });
    });
}

// ===== AUTH SYSTEM =====
const API_BASE = '';

function initModal() {
    const modal = document.getElementById('authModal');
    const loginBtn = document.getElementById('loginBtn');
    const registerBtn = document.getElementById('registerBtn');
    const modalClose = document.getElementById('modalClose');
    const tabs = document.querySelectorAll('.modal-tab');
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');

    function openModal(tab) {
        modal.classList.add('active');
        switchTab(tab);
        clearMessages();
    }

    function closeModal() {
        modal.classList.remove('active');
    }

    function switchTab(tab) {
        tabs.forEach(t => t.classList.toggle('active', t.dataset.tab === tab));
        loginForm.classList.toggle('hidden', tab !== 'login');
        registerForm.classList.toggle('hidden', tab !== 'register');
        clearMessages();
    }

    function clearMessages() {
        document.querySelectorAll('.auth-message').forEach(el => {
            el.className = 'auth-message';
            el.textContent = '';
        });
    }

    function showMsg(id, msg, type) {
        const el = document.getElementById(id);
        el.className = `auth-message show ${type}`;
        el.innerHTML = msg;
    }

    loginBtn.addEventListener('click', () => openModal('login'));
    registerBtn.addEventListener('click', () => openModal('register'));
    modalClose.addEventListener('click', closeModal);
    modal.addEventListener('click', (e) => { if (e.target === modal) closeModal(); });
    tabs.forEach(tab => tab.addEventListener('click', () => switchTab(tab.dataset.tab)));

    // --- Register ---
    document.getElementById('regSubmit').addEventListener('click', async () => {
        const username = document.getElementById('regUser').value.trim();
        const email = document.getElementById('regEmail').value.trim();
        const password = document.getElementById('regPass').value;
        const btn = document.getElementById('regSubmit');

        if (!username || !email || !password) {
            return showMsg('regMsg', 'All fields are required.', 'error');
        }

        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Registering...';
        btn.disabled = true;

        try {
            const res = await fetch(API_BASE + '/api/register', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username, email, password })
            });
            const data = await res.json();

            if (data.success) {
                showMsg('regMsg', `✅ ${data.message.replace(/\n/g, '<br>')}`, 'success');
                showToast('Registration pending! Confirm via Telegram bot.', 'success');
            } else {
                showMsg('regMsg', `❌ ${data.message}`, 'error');
            }
        } catch (err) {
            showMsg('regMsg', '❌ Server error. Please try again.', 'error');
        }

        btn.innerHTML = '<i class="fas fa-user-plus"></i> Register';
        btn.disabled = false;
    });

    // --- Login ---
    document.getElementById('loginSubmit').addEventListener('click', async () => {
        const username = document.getElementById('loginUser').value.trim();
        const password = document.getElementById('loginPass').value;
        const btn = document.getElementById('loginSubmit');

        if (!username || !password) {
            return showMsg('loginMsg', 'Username and password required.', 'error');
        }

        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Logging in...';
        btn.disabled = true;

        try {
            const res = await fetch(API_BASE + '/api/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username, password })
            });
            const data = await res.json();

            if (data.success) {
                localStorage.setItem('token', data.token);
                localStorage.setItem('user', JSON.stringify(data.user));
                showToast(`Welcome back, ${data.user.username}!`, 'success');
                closeModal();
                updateNavAuth(data.user);
            } else {
                showMsg('loginMsg', `❌ ${data.message}`, 'error');
            }
        } catch (err) {
            showMsg('loginMsg', '❌ Server error. Please try again.', 'error');
        }

        btn.innerHTML = '<i class="fas fa-sign-in-alt"></i> Login';
        btn.disabled = false;
    });
}

// ===== NAV AUTH STATE =====
function updateNavAuth(user) {
    const navActions = document.getElementById('navActions');
    if (user) {
        navActions.innerHTML = `
            <a href="dashboard.html" class="btn btn-outline"><i class="fas fa-th-large"></i> Dashboard</a>
            <button class="nav-user-btn" id="navUserBtn">
                <i class="fas fa-user-circle"></i>
                ${user.username}
                <span class="nav-credits">${user.credits} credits</span>
            </button>
        `;
        document.getElementById('navUserBtn').addEventListener('click', () => openUserPanel(user));
    } else {
        navActions.innerHTML = `
            <a href="login.html" class="btn btn-outline">Login</a>
            <a href="register.html" class="btn btn-primary">Register</a>
        `;
    }
}

// ===== USER PANEL =====
function openUserPanel(user) {
    const panel = document.getElementById('userPanel');
    document.getElementById('panelUsername').textContent = user.username;
    document.getElementById('panelPlan').textContent = user.plan || 'Free';
    document.getElementById('panelCredits').textContent = user.credits;
    document.getElementById('panelEmail').textContent = user.email;
    document.getElementById('panelJoined').textContent = user.createdAt ? user.createdAt.split('T')[0] : '—';
    panel.classList.add('active');
}

function initUserPanel() {
    const panel = document.getElementById('userPanel');
    document.getElementById('panelClose').addEventListener('click', () => panel.classList.remove('active'));
    panel.addEventListener('click', (e) => { if (e.target === panel) panel.classList.remove('active'); });

    document.getElementById('logoutBtn').addEventListener('click', () => {
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        panel.classList.remove('active');
        updateNavAuth(null);
        showToast('Logged out.', 'info');
    });
}

// ===== CHECK SESSION ON LOAD =====
async function checkSession() {
    const token = localStorage.getItem('token');
    if (!token) return;

    try {
        const res = await fetch(API_BASE + '/api/me', {
            headers: { 'Authorization': 'Bearer ' + token }
        });
        const data = await res.json();
        if (data.success) {
            localStorage.setItem('user', JSON.stringify(data.user));
            updateNavAuth(data.user);
        } else {
            localStorage.removeItem('token');
            localStorage.removeItem('user');
        }
    } catch {
        const cached = localStorage.getItem('user');
        if (cached) updateNavAuth(JSON.parse(cached));
    }
}

// ===== TOAST NOTIFICATION =====
function showToast(message, type = 'info') {
    const container = document.getElementById('toastContainer');
    const icons = {
        success: 'fa-check-circle',
        error: 'fa-exclamation-circle',
        info: 'fa-info-circle'
    };
    
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.innerHTML = `<i class="fas ${icons[type]}"></i> ${message}`;
    container.appendChild(toast);

    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateX(30px)';
        setTimeout(() => toast.remove(), 300);
    }, 3500);
}

// ===== LUHN ALGORITHM =====
function luhnCheck(num) {
    const digits = num.replace(/\D/g, '').split('').reverse().map(Number);
    if (digits.length < 13 || digits.length > 19) return false;
    let sum = 0;
    for (let i = 0; i < digits.length; i++) {
        let d = digits[i];
        if (i % 2 === 1) {
            d *= 2;
            if (d > 9) d -= 9;
        }
        sum += d;
    }
    return sum % 10 === 0;
}

// ===== CARD TYPE DETECTION =====
function getCardType(num) {
    const n = num.replace(/\D/g, '');
    if (/^4/.test(n)) return { type: 'Visa', icon: 'fab fa-cc-visa' };
    if (/^5[1-5]/.test(n)) return { type: 'Mastercard', icon: 'fab fa-cc-mastercard' };
    if (/^3[47]/.test(n)) return { type: 'Amex', icon: 'fab fa-cc-amex' };
    if (/^6(?:011|5)/.test(n)) return { type: 'Discover', icon: 'fab fa-cc-discover' };
    if (/^35/.test(n)) return { type: 'JCB', icon: 'fab fa-cc-jcb' };
    if (/^3(?:0[0-5]|[68])/.test(n)) return { type: 'Diners', icon: 'fab fa-cc-diners-club' };
    return { type: 'Unknown', icon: 'fas fa-credit-card' };
}

// ===== RANDOM DATA GENERATION =====
const banks = ['Chase Bank', 'Bank of America', 'Wells Fargo', 'Citibank', 'Capital One', 'HSBC', 'Barclays', 'Deutsche Bank', 'BNP Paribas', 'Santander'];
const countries = [
    { name: 'United States', flag: '🇺🇸' },
    { name: 'United Kingdom', flag: '🇬🇧' },
    { name: 'Canada', flag: '🇨🇦' },
    { name: 'Germany', flag: '🇩🇪' },
    { name: 'France', flag: '🇫🇷' },
    { name: 'Australia', flag: '🇦🇺' },
    { name: 'Japan', flag: '🇯🇵' },
    { name: 'Brazil', flag: '🇧🇷' }
];

const responses = {
    live: [
        'Approved - 00',
        'Transaction Approved',
        'Authorized - 05',
        'CCN Approved',
        'Auth Code: A01'
    ],
    dead: [
        'Declined - 05',
        'Insufficient Funds',
        'Card Expired',
        'Invalid Card Number',
        'Do Not Honor',
        'Restricted Card',
        'Lost/Stolen Card'
    ]
};

function randomItem(arr) {
    return arr[Math.floor(Math.random() * arr.length)];
}

// ===== RESULT COUNTER =====
let resultCount = 0;

// ===== ADD RESULT TO TABLE =====
function addResult(cardNum, isLive) {
    const tbody = document.getElementById('resultsBody');
    const emptyRow = tbody.querySelector('.empty-row');
    if (emptyRow) emptyRow.remove();

    resultCount++;
    const cardInfo = getCardType(cardNum);
    const bank = randomItem(banks);
    const country = randomItem(countries);
    const status = isLive ? 'LIVE' : 'DEAD';
    const statusClass = isLive ? 'status-live' : 'status-dead';
    const response = isLive ? randomItem(responses.live) : randomItem(responses.dead);
    const masked = cardNum.replace(/\D/g, '').replace(/(\d{4})(\d{4})(\d{4})(\d+)/, '$1****$3$4');

    const tr = document.createElement('tr');
    tr.style.animation = 'fadeInUp 0.3s ease';
    tr.innerHTML = `
        <td>${resultCount}</td>
        <td>${masked}</td>
        <td><i class="${cardInfo.icon}" style="margin-right:4px;color:var(--primary-light)"></i> ${cardInfo.type}</td>
        <td>${bank}</td>
        <td>${country.flag} ${country.name}</td>
        <td><span class="status-badge ${statusClass}">${status}</span></td>
        <td style="color:${isLive ? 'var(--success)' : 'var(--danger)'}">${response}</td>
    `;
    tbody.prepend(tr);
}

// ===== CARD LINE NORMALIZATION =====
function normalizeCardLine(value) {
    if (!value || typeof value !== 'string') return null;
    const raw = value.trim();
    if (!raw) return null;

    const pieces = raw.split(/[^0-9]+/).filter(Boolean);
    let cc = '';
    let mm = '';
    let yy = '';
    let cvv = '';

    if (pieces.length >= 4) {
        [cc, mm, yy, cvv] = pieces;
    } else if (pieces.length === 3) {
        cc = pieces[0];
        cvv = pieces[2];
        const middle = pieces[1];
        if (middle.length === 4) {
            mm = middle.slice(0, 2);
            yy = middle.slice(2);
        } else if (middle.length === 6) {
            mm = middle.slice(0, 2);
            yy = middle.slice(2);
        } else if (middle.length === 2) {
            mm = middle;
            yy = pieces[2].length === 3 ? String(new Date().getFullYear()).slice(0, 2) + pieces[2].slice(0, 1) : '';
        }
    } else if (pieces.length === 2) {
        cc = pieces[0];
        const tail = pieces[1];
        if (tail.length >= 9) {
            mm = tail.slice(0, 2);
            yy = tail.slice(2, 6);
            cvv = tail.slice(6);
        } else if (tail.length === 7) {
            mm = tail.slice(0, 2);
            yy = '20' + tail.slice(2, 4);
            cvv = tail.slice(4);
        } else if (tail.length === 6) {
            mm = tail.slice(0, 2);
            yy = '20' + tail.slice(2, 4);
            cvv = tail.slice(4);
        }
    } else if (pieces.length === 1) {
        const digits = pieces[0];
        if (digits.length >= 22) {
            cc = digits.slice(0, 16);
            mm = digits.slice(16, 18);
            if (digits.length >= 25) {
                yy = digits.slice(18, 22);
                cvv = digits.slice(22);
            } else if (digits.length === 23) {
                yy = '20' + digits.slice(18, 20);
                cvv = digits.slice(20);
            }
        }
    }

    if (!cc || !mm || !yy || !cvv) return null;
    cc = cc.replace(/\D/g, '');
    mm = mm.replace(/\D/g, '');
    yy = yy.replace(/\D/g, '');
    cvv = cvv.replace(/\D/g, '');
    if (cc.length < 13 || cc.length > 19) return null;
    if (mm.length === 1) mm = '0' + mm;
    if (yy.length === 2) {
        const yearNum = parseInt(yy, 10);
        yy = yearNum >= 0 && yearNum <= 99 ? (yearNum < 50 ? '20' + yy.padStart(2, '0') : '19' + yy.padStart(2, '0')) : yy;
    }
    if (mm.length !== 2 || yy.length !== 4 || cvv.length < 3 || cvv.length > 4) return null;
    return `${cc}|${mm}|${yy}|${cvv}`;
}

// ===== CC FORMAT INPUT =====
function formatCCInput() {
    const input = document.getElementById('ccNumber');
    input.addEventListener('input', (e) => {
        const raw = e.target.value.trim();
        const normalized = normalizeCardLine(raw);
        if (normalized && /[|\/]/.test(raw)) {
            const [cc, mm, yy, cvv] = normalized.split('|');
            e.target.value = cc.match(/.{1,4}/g)?.join(' ') || cc;
            const monthEl = document.getElementById('ccMonth');
            const yearEl = document.getElementById('ccYear');
            const cvvEl = document.getElementById('ccCvv');
            if (monthEl) monthEl.value = mm;
            if (yearEl) yearEl.value = yy;
            if (cvvEl) cvvEl.value = cvv;
            return;
        }

        let val = raw.replace(/\D/g, '');
        val = val.match(/.{1,4}/g)?.join(' ') || val;
        e.target.value = val;
    });
}

// ===== SINGLE CHECK =====
function initSingleCheck() {
    const btn = document.getElementById('singleCheckBtn');
    const resultBox = document.getElementById('singleResult');

    btn.addEventListener('click', () => {
        let ccInput = document.getElementById('ccNumber').value.trim();
        const parsed = normalizeCardLine(ccInput);
        let cc = document.getElementById('ccNumber').value.replace(/\s/g, '');
        let mm = document.getElementById('ccMonth').value;
        let yy = document.getElementById('ccYear').value;
        let cvv = document.getElementById('ccCvv').value;

        if (parsed && /[|\/]/.test(ccInput)) {
            const [pCc, pMm, pYy, pCvv] = parsed.split('|');
            cc = pCc;
            mm = pMm;
            yy = pYy;
            cvv = pCvv;
            document.getElementById('ccNumber').value = pCc.match(/.{1,4}/g)?.join(' ') || pCc;
            document.getElementById('ccMonth').value = pMm;
            document.getElementById('ccYear').value = pYy;
            document.getElementById('ccCvv').value = pCvv;
        }

        if (!cc || cc.length < 13) {
            showToast('Please enter a valid card number', 'error');
            return;
        }

        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Checking...';
        btn.disabled = true;

        setTimeout(() => {
            const isValid = luhnCheck(cc);
            const isLive = isValid && Math.random() > 0.45;
            const cardInfo = getCardType(cc);

            resultBox.className = 'result-box show ' + (isLive ? 'live' : 'dead');
            resultBox.innerHTML = `
                <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px">
                    <i class="${isLive ? 'fas fa-check-circle' : 'fas fa-times-circle'}" 
                       style="color:${isLive ? 'var(--success)' : 'var(--danger)'}; font-size:18px"></i>
                    <strong style="color:${isLive ? 'var(--success)' : 'var(--danger)'}">${isLive ? 'LIVE' : 'DEAD'}</strong>
                    <span style="color:var(--text-muted)">|</span>
                    <i class="${cardInfo.icon}" style="color:var(--primary-light)"></i> ${cardInfo.type}
                </div>
                <div style="color:var(--text-muted);font-size:12px">
                    Card: ${cc.replace(/(\d{4})/g, '$1 ').trim()} | ${mm}/${yy} | CVV: ${cvv}<br>
                    Bank: ${randomItem(banks)} | Country: ${randomItem(countries).flag} ${randomItem(countries).name}<br>
                    Response: ${isLive ? randomItem(responses.live) : randomItem(responses.dead)}
                </div>
            `;

            addResult(cc, isLive);
            showToast(isLive ? 'Card is LIVE!' : 'Card is DEAD', isLive ? 'success' : 'error');

            btn.innerHTML = '<i class="fas fa-bolt"></i> Check Now';
            btn.disabled = false;
        }, 1200 + Math.random() * 800);
    });
}

// ===== MASS CHECK =====
function initMassCheck() {
    const btn = document.getElementById('massCheckBtn');
    const resultBox = document.getElementById('massResult');

    btn.addEventListener('click', () => {
        const input = document.getElementById('massInput').value.trim();
        if (!input) {
            showToast('Please enter card list', 'error');
            return;
        }

        const lines = input.split('\n').filter(l => l.trim());
        if (lines.length === 0) {
            showToast('No valid cards found', 'error');
            return;
        }

        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Checking...';
        btn.disabled = true;

        let checked = 0;
        let live = 0;
        let dead = 0;

        resultBox.className = 'result-box show';
        resultBox.innerHTML = `<div style="color:var(--text-muted)"><i class="fas fa-spinner fa-spin"></i> Processing ${lines.length} cards...</div>`;

        lines.forEach((line, index) => {
            setTimeout(() => {
                const normalized = normalizeCardLine(line);
                const cc = normalized ? normalized.split('|')[0] : line.replace(/\D/g, '');
                const isValid = cc.length >= 13 && luhnCheck(cc);
                const isLive = isValid && Math.random() > 0.5;

                if (isLive) live++; else dead++;
                checked++;

                addResult(cc || '0000000000000000', isLive);

                resultBox.innerHTML = `
                    <div style="display:flex;gap:16px;align-items:center;flex-wrap:wrap">
                        <span><i class="fas fa-list" style="color:var(--primary-light)"></i> Checked: ${checked}/${lines.length}</span>
                        <span><i class="fas fa-check-circle" style="color:var(--success)"></i> Live: ${live}</span>
                        <span><i class="fas fa-times-circle" style="color:var(--danger)"></i> Dead: ${dead}</span>
                    </div>
                    <div style="margin-top:8px;height:4px;background:rgba(255,255,255,0.05);border-radius:2px;overflow:hidden">
                        <div style="height:100%;width:${(checked/lines.length)*100}%;background:var(--gradient-1);border-radius:2px;transition:width 0.3s"></div>
                    </div>
                `;

                if (checked === lines.length) {
                    btn.innerHTML = '<i class="fas fa-rocket"></i> Mass Check';
                    btn.disabled = false;
                    showToast(`Done! ${live} Live / ${dead} Dead`, live > 0 ? 'success' : 'info');
                }
            }, (index + 1) * (800 + Math.random() * 600));
        });
    });
}

// ===== CLEAR & EXPORT =====
function initControls() {
    document.getElementById('clearResults').addEventListener('click', () => {
        const tbody = document.getElementById('resultsBody');
        tbody.innerHTML = `
            <tr class="empty-row">
                <td colspan="7">
                    <div class="empty-state">
                        <i class="fas fa-inbox"></i>
                        <p>No results yet. Start checking cards above.</p>
                    </div>
                </td>
            </tr>
        `;
        resultCount = 0;
        showToast('Results cleared', 'info');
    });

    document.getElementById('exportResults').addEventListener('click', () => {
        const rows = document.querySelectorAll('#resultsBody tr:not(.empty-row)');
        if (rows.length === 0) {
            showToast('No results to export', 'error');
            return;
        }
        let csv = 'No,Card,Type,Bank,Country,Status,Response\n';
        rows.forEach(row => {
            const cells = row.querySelectorAll('td');
            const values = Array.from(cells).map(c => c.textContent.trim());
            csv += values.join(',') + '\n';
        });
        const blob = new Blob([csv], { type: 'text/csv' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'tretrauchecker_results.csv';
        a.click();
        URL.revokeObjectURL(url);
        showToast('Results exported!', 'success');
    });
}

// ===== NUMBER COUNTER ANIMATION =====
function animateCounters() {
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const counters = entry.target.querySelectorAll('[data-count]');
                counters.forEach(counter => {
                    const target = parseInt(counter.dataset.count);
                    const duration = 2000;
                    const step = target / (duration / 16);
                    let current = 0;

                    const update = () => {
                        current += step;
                        if (current < target) {
                            counter.textContent = Math.floor(current).toLocaleString();
                            requestAnimationFrame(update);
                        } else {
                            counter.textContent = target.toLocaleString();
                        }
                    };
                    update();
                });
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.3 });

    document.querySelectorAll('.hero-stats-row, .stats-grid').forEach(el => observer.observe(el));
}

// ===== SCROLL REVEAL =====
function initScrollReveal() {
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.animation = 'fadeInUp 0.6s ease forwards';
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.1 });

    document.querySelectorAll('.feature-card, .stat-card, .pricing-card, .checker-card, .live-results').forEach(el => {
        el.style.opacity = '0';
        observer.observe(el);
    });
}

// ===== CREDIT CARD TILT =====
function initCardTilt() {
    const card = document.querySelector('.credit-card');
    if (!card) return;

    card.addEventListener('mousemove', (e) => {
        const rect = card.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        const centerX = rect.width / 2;
        const centerY = rect.height / 2;
        const rotateX = (y - centerY) / 10;
        const rotateY = (centerX - x) / 10;
        card.style.transform = `rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale(1.02)`;
    });

    card.addEventListener('mouseleave', () => {
        card.style.transform = 'rotateY(-8deg) rotateX(5deg)';
    });
}

// ===== INIT =====
document.addEventListener('DOMContentLoaded', () => {
    createParticles();
    initNavbar();
    initModal();
    initUserPanel();
    checkSession();
    formatCCInput();
    initSingleCheck();
    initMassCheck();
    initControls();
    animateCounters();
    initScrollReveal();
    initCardTilt();
});
