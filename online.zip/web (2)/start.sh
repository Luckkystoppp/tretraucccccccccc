#!/bin/bash

DIR="$(cd "$(dirname "$0")" && pwd)"

echo ""
echo "  TreTrauChecker — Starting..."
echo ""

# Kill any existing instances first
echo "  [*] Killing old instances..."
pkill -f "node.*server/server.js" 2>/dev/null
pkill -f "node.*server/bot.js" 2>/dev/null
pkill -f "python.*pay.py" 2>/dev/null
pkill -f "python3.*pay.py" 2>/dev/null
sleep 2

# Check node
if ! command -v node &>/dev/null; then
    echo "  ERROR: Node.js not found."
    exit 1
fi

# Check python3
if ! command -v python3 &>/dev/null; then
    echo "  ERROR: Python3 not found."
    exit 1
fi

# Install node deps if needed
if [ ! -d "$DIR/node_modules" ]; then
    echo "  Installing Node dependencies..."
    cd "$DIR" && npm install
fi

# Use virtualenv if available
if [ -d "$DIR/myenv" ]; then
    source "$DIR/myenv/bin/activate"
elif ! python3 -c "import telebot" &>/dev/null; then
    echo "  Installing pytelegrambotapi..."
    pip3 install pytelegrambotapi -q
fi

echo "  [+] Starting server.js (port 80 + 3456)..."
PORT=80 node "$DIR/server/server.js" &
NODE_PID=$!

sleep 2

echo "  [+] Starting pay.py (payment bot)..."
python3 "$DIR/server/pay.py" &
PY_PID=$!

sleep 1

echo "  [+] Starting admin_bot.py (admin bot)..."
python3 "$DIR/server/admin_bot.py" &
ADMIN_PID=$!

sleep 1

echo "  [+] Starting bot.js (checker bot)..."
node "$DIR/bot.js" &
BOT_PID=$!

echo ""
echo "  Dashboard  : http://localhost/dashboard (port 80)"
echo "  Bots       : Running"
echo "  PIDs       : node=$NODE_PID  pay=$PY_PID  admin=$ADMIN_PID  bot=$BOT_PID"
echo ""
echo "  Press Ctrl+C to stop all."
echo ""

trap "echo '  Stopping...'; kill $NODE_PID $PY_PID $ADMIN_PID $BOT_PID 2>/dev/null; exit 0" SIGINT SIGTERM

wait
