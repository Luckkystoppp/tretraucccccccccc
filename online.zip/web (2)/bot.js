'use strict';
/**
 * TreTrauChecker — Telegram Checker Bot
 * Standalone: không cần đăng ký, không cần tài khoản.
 * Giới hạn 30 check/ngày mỗi Telegram user.
 * Admin: không giới hạn, full panel.
 */

const TelegramBot = require('node-telegram-bot-api');
const fs    = require('fs');
const path  = require('path');
const http  = require('http');
const https = require('https');
const crypto = require('crypto');

// ─── Config ───────────────────────────────────────────────────────────────────
const BOT_TOKEN   = process.env.CHECKER_BOT_TOKEN || '8601700010:AAGogRRJMVbDLijXYTqEEUmQftK8B1VE9GM';
const ADMIN_ID    = parseInt(process.env.ADMIN_ID || '7490574579');
const DB_PATH     = path.join(__dirname, 'data', 'db.json');
const USAGE_PATH  = path.join(__dirname, 'data', 'bot_usage.json');
const GATE_HOST   = '104.214.171.212';
const DAILY_LIMIT = 30; // max checks per day per TG user

// ─── Premium Emoji ────────────────────────────────────────────────────────────
function E(char, id) { return id ? `<tg-emoji emoji-id="${id}">${char}</tg-emoji>` : char; }
const em = {
    check:   () => E('✅','6296361136119878197'),
    cross:   () => E('❌','5210952531676504517'),
    fire:    () => E('🔥','5424972470023104089'),
    bolt:    () => E('⚡️','6084603670580693532'),
    shield:  () => E('🛡','5197288647275071607'),
    money:   () => E('💰','5224257782013769471'),
    gear:    () => E('⚙️','5341715473882955310'),
    warn:    () => E('⚠️','5274099962655816924'),
    robot:   () => E('🤖','5287684458881756303'),
    chart:   () => E('📈','6084693581426069171'),
    search:  () => E('🔍','5231012545799666522'),
    card:    () => E('💳','5463172695132745432'),
    crown:   () => E('👑','6293878670792595939'),
    siren:   () => E('🚨','5395695537687123235'),
    clock:   () => E('🕐','5778605968208170641'),
    stars:   () => E('✨','5325547803936572038'),
    nope:    () => E('🚫','5240241223632954241'),
    refresh: () => E('🔃','5375338737028841420'),
    person:  () => E('🤓','5920344347152224466'),
    group:   () => E('👥','5942877472163892475'),
    diamond: () => E('💎','6086857274280642991'),
    target:  () => E('🎯','5310278924616356636'),
    rocket:  () => E('🚀','5188481279963715781'),
    tools:   () => E('🛠','5462921117423384478'),
    trash:   () => E('🗑️','5775903905'),
    speaker: () => E('📢','5388632425314140043'),
    tick:    () => E('☑️','5206607081334906820'),
    noEntry: () => E('⛔','6269145070826426586'),
    info:    () => E('ℹ️','5277666690028380039'),
    memo:    () => E('📝','6008090211181923982'),
    folder:  () => E('📂','5345987742276797245'),
    globe:   () => E('🌐','5447410659077661506'),
    proxy:   () => E('🌩','5202010667464279188'),
    key:     () => E('🔑','6005570495603282482'),
    dice:    () => E('🎲','5289722755871162900'),
};

// ─── Database (dùng chung với web) ───────────────────────────────────────────
function readDB() {
    try { return JSON.parse(fs.readFileSync(DB_PATH, 'utf8')); }
    catch { return { users:{}, banned:[], banned_ips:[], stats:{}, statsLive:{}, gateStates:{} }; }
}
function writeDB(db) { fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2)); }
let _dbLock = Promise.resolve();
function withDB(fn) {
    _dbLock = _dbLock.then(() => { const db=readDB(); fn(db); writeDB(db); }).catch(()=>{});
    return _dbLock;
}

// ─── Daily usage tracking (per TG user) ──────────────────────────────────────
function readUsage() {
    try { return JSON.parse(fs.readFileSync(USAGE_PATH, 'utf8')); }
    catch { return {}; }
}
function saveUsage(u) { fs.writeFileSync(USAGE_PATH, JSON.stringify(u, null, 2)); }

const TODAY = () => new Date().toISOString().substring(0, 10);

function getUsed(tgId) {
    const usage = readUsage();
    const today = TODAY();
    const rec = usage[String(tgId)];
    if (!rec || rec.date !== today) return 0;
    return rec.count || 0;
}
function addUsed(tgId, n = 1) {
    const usage = readUsage();
    const today = TODAY();
    const key = String(tgId);
    if (!usage[key] || usage[key].date !== today) usage[key] = { date: today, count: 0 };
    usage[key].count += n;
    saveUsage(usage);
    return usage[key].count;
}
function resetUsed(tgId) {
    const usage = readUsage();
    delete usage[String(tgId)];
    saveUsage(usage);
}

// ─── Gate Config ──────────────────────────────────────────────────────────────
const GATES = {
    stripe_auth:  { label:'Stripe Auth',    emoji:'⚡',url:`http://${GATE_HOST}/stripe.php`,     type:'auth'                    },
    stripe_auth2: { label:'Stripe Auth V2', emoji:'⚡',url:`http://${GATE_HOST}/stripe1.php`,    type:'auth'                    },
    stripe_auto:  { label:'Stripe Auto',    emoji:'⚡',url:`http://${GATE_HOST}/autostripe.php`, type:'auth',  needSite:true    },
    adyen:        { label:'Adyen Auth',     emoji:'⚡',url:`http://${GATE_HOST}/ayden_api.php`,  type:'auth'                    },
    vbv_db:       { label:'VBV DB',         emoji:'🔍',url:`http://${GATE_HOST}/vbv.php`,        type:'auth'                    },
    vbv_api:      { label:'VBV API',        emoji:'🔍',url:`http://${GATE_HOST}/vbv_old.php`,    type:'auth',  timeout:30000    },
    stripe5:      { label:'Stripe $5',      emoji:'💰',url:`http://${GATE_HOST}/st5$.php`,       type:'charge'                  },
    stripe_chg:   { label:'Stripe $1',      emoji:'💰',url:`http://${GATE_HOST}/st11.php`,       type:'charge'                  },
    stripe1:      { label:'Stripe Auth$1',  emoji:'💰',url:`http://${GATE_HOST}/st1.php`,        type:'charge'                  },
    square1:      { label:'Square $1',      emoji:'💰',url:`http://${GATE_HOST}/sq.php`,         type:'charge'                  },
    paypal1:      { label:'PayPal $1',      emoji:'💰',url:`http://${GATE_HOST}/pp_charge.php`,  type:'charge', timeout:30000   },
    paypal_wp1:   { label:'PayPal WP $1',   emoji:'💰',url:`http://${GATE_HOST}/pp.php`,         type:'charge'                  },
    shopify:      { label:'Shopify Auto',   emoji:'🛒',url:`http://${GATE_HOST}:3636/`,          type:'shopify',needSite:true,needProxy:true },
};

const CMD_GATE = {
    auth:      'stripe_auth',
    auth2:     'stripe_auth2',
    strip5:    'stripe5',
    strip1:    'stripe_chg',
    ccn3:      'stripe1',
    vbv:       'vbv_api',
    square1:   'square1',
    aydenauth: 'adyen',
    pp1:       'paypal1',
    ppwp1:     'paypal_wp1',
    ssop:      'shopify',
};

// ─── Gate caller ──────────────────────────────────────────────────────────────
function callGate(url, ms = 20000) {
    return new Promise((resolve, reject) => {
        const req = http.get(url, res => {
            let body = '';
            res.on('data', c => body += c);
            res.on('end', () => resolve(body.trim()));
        });
        req.on('error', reject);
        req.setTimeout(ms, () => { req.destroy(); reject(new Error('timeout')); });
    });
}

function parseGate(body) {
    let json = null;
    try { json = JSON.parse(body); } catch {}
    if (json && json.status) {
        const s   = String(json.status).toLowerCase();
        const raw = String(json.message || json.response || '').trim();
        const msg = (raw.includes(' | ') ? raw.split(' | ')[0] : raw).substring(0,90).trim();
        const ml  = raw.toLowerCase(), lm = msg.toLowerCase();
        if (s==='approved'||s==='live'||s==='success') return {status:'APPROVED',response:msg||'Approved'};
        if (lm.includes('authenticate successful')||lm.includes('authentication successful')||lm.includes('authenticate attempt successful')) return {status:'APPROVED',response:msg};
        if (s==='charged'||s==='captured') return {status:'CHARGED',response:msg||'Charged'};
        if (s==='3ds'||s==='vbv'||s==='3ds_required'||s==='3d_secure') return {status:'VBV',response:msg||'3D Secure'};
        if (ml.includes('3d secure')||ml.includes('3ds')||ml.includes('authentication_required')||ml.includes('challenge')||ml.includes('enrolled')) return {status:'VBV',response:msg||'3D Secure'};
        return {status:'DECLINED',response:msg||s};
    }
    const t=(body||'').toLowerCase(),fb=body.substring(0,90);
    if (t.includes('approved')||t.includes('authenticate successful')) return {status:'APPROVED',response:fb};
    if (t.includes('charged')||t.includes('captured')) return {status:'CHARGED',response:fb};
    if (t.includes('3d secure')||t.includes('3ds')||t.includes('authentication required')||t.includes('challenge required')||t.includes('enrolled')) return {status:'VBV',response:fb};
    return {status:'DECLINED',response:fb};
}

function parseShopify(data, rawBody) {
    const trimmed = (rawBody||'').trim();
    if (trimmed.startsWith('<')) return {status:'ERROR',response:'Gate error (no JSON)'};
    const resp = (data.Response||data.response||'').toString().trim();
    const r    = resp.toUpperCase();
    const orderUrl = (data['Order url']||data.orderUrl||'').toString().trim();
    if (r==='3DS_REQUIRED'||r.includes('3DS')) return {status:'VBV',response:resp};
    if (orderUrl&&orderUrl!=='null'&&orderUrl!=='undefined') return {status:'CHARGED',response:resp};
    const rl = resp.toLowerCase();
    if (rl.includes('charged')||rl.includes('captured')||rl.includes('paid')) return {status:'CHARGED',response:resp};
    if (rl.includes('approved')||rl.includes('authorized')||rl.includes('live')) return {status:'APPROVED',response:resp};
    if (resp===''||resp==='null'||rl.includes('gateway_error')||rl.includes('timeout')) return {status:'ERROR',response:resp||'Gate error'};
    return {status:'DECLINED',response:resp};
}

// ─── Stats recording (vào db.json chung) ─────────────────────────────────────
function recordStat(isLive) {
    const db=readDB(), today=TODAY();
    if (!db.stats) db.stats={};
    if (!db.statsLive) db.statsLive={};
    db.stats[today]=(db.stats[today]||0)+1;
    if (isLive) db.statsLive[today]=(db.statsLive[today]||0)+1;
    writeDB(db);
}

// ─── Gate enabled check ───────────────────────────────────────────────────────
function isGateOn(gateId) {
    const db=readDB();
    return (db.gateStates||{})[gateId]!==false;
}
function setGateOn(gateId, on) {
    const db=readDB();
    if (!db.gateStates) db.gateStates={};
    db.gateStates[gateId]=!!on;
    writeDB(db);
}

// ─── BIN Lookup ───────────────────────────────────────────────────────────────
function binLookup(bin) {
    return new Promise(resolve => {
        https.get({
            hostname:'bins.antipublic.cc', path:`/bins/${bin}`,
            headers:{'User-Agent':'TreTrauChecker/2.0',Accept:'application/json'}
        }, r => {
            let b='';
            r.on('data',d=>b+=d);
            r.on('end',()=>{ try{if(r.statusCode===200)return resolve(JSON.parse(b));}catch{}resolve(null); });
        }).on('error',()=>resolve(null));
        setTimeout(()=>resolve(null),8000);
    });
}

// ─── Fake Info Generator (copy từ web) ───────────────────────────────────────
function genFakeInfo(country='US') {
    country=country.toUpperCase();
    const pick=arr=>arr[Math.floor(Math.random()*arr.length)];
    const rnd=(min,max)=>Math.floor(Math.random()*(max-min+1))+min;
    const maleNames={US:['James','Robert','John','Michael','David','William'],UK:['Oliver','Harry','George','Jack','Leo'],DEFAULT:['Alex','Chris','Sam','Jordan','Taylor']};
    const femaleNames={US:['Mary','Jennifer','Linda','Sarah','Emily','Jessica'],UK:['Amelia','Olivia','Isla','Ava','Mia'],DEFAULT:['Emma','Sophia','Olivia','Ava','Isabella']};
    const lastNames={US:['Smith','Johnson','Williams','Brown','Jones','Miller'],UK:['Smith','Jones','Taylor','Brown','Wilson'],DEFAULT:['Smith','Johnson','Williams','Brown','Jones']};
    const cities={US:['New York','Los Angeles','Chicago','Houston','Phoenix'],UK:['London','Manchester','Birmingham','Leeds','Glasgow'],DEFAULT:['Capital City','Metro','Downtown']};
    const phones={US:'+1',UK:'+44',CA:'+1',DE:'+49',FR:'+33',AU:'+61',DEFAULT:'+1'};
    const isMale=Math.random()>0.5;
    const first=pick(isMale?(maleNames[country]||maleNames.DEFAULT):(femaleNames[country]||femaleNames.DEFAULT));
    const last=pick(lastNames[country]||lastNames.DEFAULT);
    const phone=phones[country]||phones.DEFAULT;
    const domains=['gmail.com','yahoo.com','outlook.com','protonmail.com','icloud.com'];
    const streets=['Main St','Oak Ave','Pine Dr','Elm Blvd','Maple Ln','Cedar Way'];
    const dob_y=rnd(1975,2003),dob_m=rnd(1,12),dob_d=rnd(1,28);
    const username=`${first.toLowerCase()}${rnd(10,999)}`;
    return {first,last,username,email:`${username}@${pick(domains)}`,password:`${first}@${rnd(1000,9999)}`,phone:`${phone} ${rnd(200,999)}-${rnd(100,999)}-${rnd(1000,9999)}`,address:`${rnd(100,9999)} ${pick(streets)}`,city:pick(cities[country]||cities.DEFAULT),zip:`${rnd(10000,99999)}`,country,dob:`${String(dob_m).padStart(2,'0')}/${String(dob_d).padStart(2,'0')}/${dob_y}`,ssn:`${rnd(100,999)}-${rnd(10,99)}-${rnd(1000,9999)}`};
}

// ─── Card validators ──────────────────────────────────────────────────────────
function isVNCard(cc) { return cc.replace(/\D/g,'').startsWith('9704'); }
function validateCard(cc,mm,yy,cvv) {
    if (!/^\d{13,19}$/.test(cc)) return 'Số thẻ không hợp lệ (13–19 chữ số).';
    const mo=parseInt(mm,10);
    if (!/^\d{1,2}$/.test(mm)||mo<1||mo>12) return 'Tháng không hợp lệ (01–12).';
    const yr=parseInt(yy,10),fy=yr<100?2000+yr:yr,cy=new Date().getFullYear();
    if (!/^\d{2,4}$/.test(yy)||fy<cy||fy>cy+25) return 'Thẻ hết hạn hoặc năm không hợp lệ.';
    if (!/^\d{3,4}$/.test(cvv)) return 'CVV không hợp lệ.';
    return null;
}
function parseCard(text) {
    const t=text.trim().replace(/\s+/g,'');
    const p=t.split('|');
    if (p.length===4) return {cc:p[0],mm:p[1],yy:p[2],cvv:p[3]};
    const a=text.trim().split(/[\/\s]+/);
    if (a.length===4) return {cc:a[0],mm:a[1],yy:a[2],cvv:a[3]};
    return null;
}
function parseCards(text) {
    return text.split('\n').map(l=>l.trim()).filter(l=>l&&!l.startsWith('#')).map(l=>parseCard(l)).filter(Boolean);
}

// ─── Format helpers ───────────────────────────────────────────────────────────
function statusIcon(s) {
    if (s==='APPROVED'||s==='CHARGED') return em.check();
    if (s==='VBV') return em.warn();
    if (s==='DECLINED') return em.cross();
    return em.warn();
}
function statusColor(s) {
    if (s==='APPROVED'||s==='CHARGED') return '🟢';
    if (s==='VBV') return '🟡';
    return '🔴';
}
function maskCard(cc) { return cc.substring(0,6)+'***'+cc.slice(-4); }
function fmtDate(iso) { if(!iso)return 'N/A'; return new Date(iso).toLocaleDateString('vi-VN',{day:'2-digit',month:'2-digit',year:'numeric'}); }

// ─── Bot Init ─────────────────────────────────────────────────────────────────
const bot = new TelegramBot(BOT_TOKEN, {polling:true});
bot.getMe().then(me=>console.log(`[CheckerBot] @${me.username} ready`)).catch(()=>{});

function send(chatId, text, extra={}) { return bot.sendMessage(chatId, text, {parse_mode:'HTML',...extra}).catch(()=>{}); }
function edit(chatId, msgId, text, extra={}) { return bot.editMessageText(text,{chat_id:chatId,message_id:msgId,parse_mode:'HTML',...extra}).catch(()=>{}); }
function answerCb(qId, text='', alert=false) { return bot.answerCallbackQuery(qId,{text,show_alert:alert}).catch(()=>{}); }
function kb(...rows) { return {reply_markup:{inline_keyboard:rows}}; }
function btn(text, cb) { return {text,callback_data:cb}; }

// ─── Session ──────────────────────────────────────────────────────────────────
const state = {};
function getState(id) { return state[id]||{}; }
function setState(id, s) { state[id]=s; }
function clearState(id) { delete state[id]; }

// ─── Admin check ──────────────────────────────────────────────────────────────
function isAdmin(tgId) { return parseInt(tgId)===ADMIN_ID; }

// ─── Main Menu ────────────────────────────────────────────────────────────────
function mainMenu(tgId) {
    const rows = [
        [btn(`${em.bolt()} Auth Gates`,'menu_auth'),   btn(`${em.fire()} Charge Gates`,'menu_charge')],
        [btn(`${em.proxy()} Shopify Auto`,'menu_shopify'), btn(`${em.search()} BIN Lookup`,'menu_bin')],
        [btn(`${em.folder()} Batch File`,'menu_batch'),btn(`${em.dice()} Fake Info`,'menu_fake')],
        [btn(`${em.chart()} Stats`,'menu_stats'),      btn(`${em.info()} Help`,'menu_help')],
    ];
    if (isAdmin(tgId)) rows.push([btn(`${em.shield()} Admin Panel`,'admin_main')]);
    return {reply_markup:{inline_keyboard:rows}};
}

function mainText(tgId) {
    const used = isAdmin(tgId) ? '∞' : `${getUsed(tgId)}/${DAILY_LIMIT}`;
    return [
        `${em.robot()} <b>TreTrauChecker Bot</b>`,``,
        `${em.fire()} Checker mạnh nhất — miễn phí 100%`,``,
        `${em.chart()} Checks hôm nay: <b>${used}</b>`,``,
        `${em.card()} Gửi thẻ: <code>cc|mm|yy|cvv</code>`,
        `${em.folder()} Gửi file <b>.txt</b> để batch check`,
        `${em.search()} Dùng lệnh hoặc nút bên dưới`,
    ].join('\n');
}

// ─── Gate keyboards ───────────────────────────────────────────────────────────
function gateKb(prefix, types) {
    const gates = Object.entries(GATES).filter(([,g])=>types.includes(g.type));
    const rows = [];
    for (let i=0;i<gates.length;i+=2) {
        rows.push(gates.slice(i,i+2).map(([id,g])=>btn(`${isGateOn(id)?'🟢':'🔴'} ${g.emoji} ${g.label}`,`${prefix}${id}`)));
    }
    rows.push([btn(`⬅️ Menu`,'menu_main')]);
    return {reply_markup:{inline_keyboard:rows}};
}
function allGateKb(prefix) {
    const rows = [];
    const auth=Object.entries(GATES).filter(([,g])=>g.type==='auth');
    const chg=Object.entries(GATES).filter(([,g])=>g.type!=='auth');
    rows.push([btn('─── Auth Gates ───','noop')]);
    for(let i=0;i<auth.length;i+=2) rows.push(auth.slice(i,i+2).map(([id,g])=>btn(`${isGateOn(id)?'🟢':'🔴'} ${g.emoji} ${g.label}`,`${prefix}${id}`)));
    rows.push([btn('─── Charge + Shopify ───','noop')]);
    for(let i=0;i<chg.length;i+=2)  rows.push(chg.slice(i,i+2).map(([id,g])=>btn(`${isGateOn(id)?'🟢':'🔴'} ${g.emoji} ${g.label}`,`${prefix}${id}`)));
    rows.push([btn(`${em.cross()} Hủy`,'cancel')]);
    return {reply_markup:{inline_keyboard:rows}};
}

// ─── Core: Run single check ───────────────────────────────────────────────────
async function runCheck(chatId, tgId, card, gateId, site, proxy, editId) {
    const gateConf = GATES[gateId];
    if (!gateConf) return;
    if (!isGateOn(gateId)) return send(chatId,`${em.nope()} Gate <b>${gateConf.label}</b> đang bị tắt.`);

    // Daily limit
    if (!isAdmin(tgId)) {
        const used = getUsed(tgId);
        if (used >= DAILY_LIMIT) {
            return send(chatId,[
                `${em.warn()} <b>Hết limit hôm nay!</b>`,
                `Bạn đã dùng <b>${used}/${DAILY_LIMIT}</b> checks.`,
                `Reset lúc 00:00 UTC.`,
            ].join('\n'));
        }
    }

    const {cc,mm,yy,cvv}=card;
    const loading=[
        `${em.clock()} <b>Đang check...</b>`,
        `${em.card()} <code>${cc}|${mm}|${yy}|${cvv}</code>`,
        `${em.target()} <b>Gate:</b> ${gateConf.emoji} ${gateConf.label}`,
    ].join('\n');

    let outId = editId;
    if (editId) await edit(chatId,editId,loading);
    else { const w=await send(chatId,loading); outId=w?.message_id; }

    // Count usage before check
    if (!isAdmin(tgId)) addUsed(tgId);

    let status='ERROR', response='Gate error';
    try {
        let body;
        if (gateConf.type==='shopify') {
            const ccStr=`${cc}|${mm}|${yy}|${cvv}`;
            const url=`http://${GATE_HOST}:3636/?${ccStr}&url=${encodeURIComponent(site||'')}${proxy?`&proxy=${proxy}`:''}`;
            body=await callGate(url,90000);
            let d={}; try{d=JSON.parse(body);}catch{}
            ({status,response}=parseShopify(d,body));
        } else {
            const cp=encodeURIComponent(`${cc}|${mm}|${yy}|${cvv}`);
            let url=`${gateConf.url}?card=${cp}`;
            if (gateConf.needSite&&site) url+=`&site=${encodeURIComponent(site)}`;
            body=await callGate(url,gateConf.timeout||20000);
            ({status,response}=parseGate(body));
            if (gateConf.type==='charge'&&status==='APPROVED') status='CHARGED';
        }
    } catch(e) {
        // Refund usage on gate error
        if (!isAdmin(tgId)) { const u=readUsage(),k=String(tgId),t=TODAY(); if(u[k]&&u[k].date===t&&u[k].count>0){u[k].count--;saveUsage(u);} }
        const t=`${em.siren()} Lỗi kết nối gate. Không tốn limit.\n<i>${e.message?.substring(0,40)||''}</i>`;
        outId?edit(chatId,outId,t):send(chatId,t);
        return null;
    }

    recordStat(status==='APPROVED'||status==='CHARGED');
    const usedNow = isAdmin(tgId) ? '∞' : `${getUsed(tgId)}/${DAILY_LIMIT}`;
    const icon = statusIcon(status);
    const col  = statusColor(status);

    // BIN info
    const bin6=cc.substring(0,6);
    const binInfo=await binLookup(bin6).catch(()=>null);
    const binLine=binInfo?`${em.search()} <b>BIN:</b> ${(binInfo.brand||'').toUpperCase()} ${(binInfo.type||'').toUpperCase()} — ${binInfo.bank||''} — ${binInfo.country_name||''}`:'';

    const result=[
        `${col} ${icon} <b>${status}</b>`,``,
        `${em.card()} <code>${cc}|${mm}|${yy}|${cvv}</code>`,
        binLine,
        `${em.target()} <b>Gate:</b> ${gateConf.emoji} ${gateConf.label}`,
        `${em.memo()} <b>Response:</b> <code>${response.substring(0,120)}</code>`,
        `${em.chart()} <b>Used:</b> ${usedNow}`,
    ].filter(Boolean).join('\n');

    const reKb=kb(
        [btn(`${em.refresh()} Gate khác`,`repick_${cc}|${mm}|${yy}|${cvv}`),btn(`${em.chart()} Menu`,'menu_main')],
    );
    outId?edit(chatId,outId,result,reKb):send(chatId,result,reKb);
    return {status,response};
}

// ─── Core: Batch check ────────────────────────────────────────────────────────
async function runBatch(chatId, tgId, cards, gateId, site, proxy) {
    const gateConf=GATES[gateId];
    if (!gateConf) return;
    if (!isGateOn(gateId)) return send(chatId,`${em.nope()} Gate đang tắt.`);

    const remaining = isAdmin(tgId) ? cards.length : Math.max(0,DAILY_LIMIT-getUsed(tgId));
    const toCheck = cards.slice(0, Math.min(remaining, 100, isAdmin(tgId)?100:DAILY_LIMIT));

    if (toCheck.length===0) {
        return send(chatId,[
            `${em.warn()} <b>Hết limit hôm nay!</b>`,
            `Đã dùng ${getUsed(tgId)}/${DAILY_LIMIT} checks.`,
            `Reset lúc 00:00 UTC.`,
        ].join('\n'));
    }

    let ok=0,vbv=0,dec=0,err=0;
    const hitLines=[];
    const pm=await send(chatId,[
        `${em.rocket()} <b>Batch Check</b>`,
        `${em.target()} Gate: <b>${gateConf.emoji} ${gateConf.label}</b>`,
        `${em.card()} Tổng: <b>${toCheck.length}</b> thẻ`,
        `${em.clock()} Đang check 0/${toCheck.length}...`,
    ].join('\n'));
    const pmId=pm?.message_id;

    for (let i=0;i<toCheck.length;i++) {
        const {cc,mm,yy,cvv}=toCheck[i];
        if (isVNCard(cc)) { err++; continue; }

        // Count usage
        if (!isAdmin(tgId)) {
            const used=getUsed(tgId);
            if (used>=DAILY_LIMIT) {
                if (pmId) edit(chatId,pmId,[
                    `${em.warn()} Hết limit tại thẻ ${i+1}!`,
                    `${em.check()} Hits: ${ok}  ${em.warn()} VBV: ${vbv}  ${em.cross()} Dec: ${dec}`,
                ].join('\n'));
                return;
            }
            addUsed(tgId);
        }

        let status='ERROR',response='err';
        try {
            let body;
            if (gateConf.type==='shopify') {
                const ccStr=`${cc}|${mm}|${yy}|${cvv}`;
                const url=`http://${GATE_HOST}:3636/?${ccStr}&url=${encodeURIComponent(site||'')}${proxy?`&proxy=${proxy}`:''}`;
                body=await callGate(url,90000);
                let d={}; try{d=JSON.parse(body);}catch{}
                ({status,response}=parseShopify(d,body));
            } else {
                const cp=encodeURIComponent(`${cc}|${mm}|${yy}|${cvv}`);
                body=await callGate(`${gateConf.url}?card=${cp}`,gateConf.timeout||20000);
                ({status,response}=parseGate(body));
                if (gateConf.type==='charge'&&status==='APPROVED') status='CHARGED';
            }
        } catch {
            // Refund on error
            if (!isAdmin(tgId)) { const u=readUsage(),k=String(tgId),t=TODAY(); if(u[k]&&u[k].date===t&&u[k].count>0){u[k].count--;saveUsage(u);} }
            err++; continue;
        }

        recordStat(status==='APPROVED'||status==='CHARGED');
        if (status==='APPROVED'||status==='CHARGED') { ok++; hitLines.push(`${statusIcon(status)} <code>${cc}|${mm}|${yy}|${cvv}</code> — ${response.substring(0,50)}`); }
        else if (status==='VBV') vbv++;
        else if (status==='DECLINED') dec++;
        else err++;

        if (pmId&&(i+1)%5===0) {
            const usedNow=isAdmin(tgId)?'∞':`${getUsed(tgId)}/${DAILY_LIMIT}`;
            edit(chatId,pmId,[
                `${em.rocket()} <b>Batch</b> ${i+1}/${toCheck.length}`,
                `${em.check()} Hits: <b>${ok}</b>  ${em.warn()} VBV: <b>${vbv}</b>  ${em.cross()} Dec: <b>${dec}</b>`,
                `${em.chart()} Used: ${usedNow}`,
            ].join('\n'));
        }
        await new Promise(r=>setTimeout(r,400));
    }

    const usedFinal=isAdmin(tgId)?'∞':`${getUsed(tgId)}/${DAILY_LIMIT}`;
    const finalMsg=[
        `${em.check()} <b>Batch xong!</b>`,
        `${em.target()} Gate: <b>${gateConf.emoji} ${gateConf.label}</b>`,
        `${em.card()} Checked: <b>${toCheck.length}</b>`,``,
        `${em.check()} Hits (Approved/Charged): <b>${ok}</b>`,
        `${em.warn()} VBV: <b>${vbv}</b>`,
        `${em.cross()} Declined: <b>${dec}</b>`,
        `❗ Errors: <b>${err}</b>`,
        `${em.chart()} Used: <b>${usedFinal}</b>`,
        hitLines.length?`\n${em.fire()} <b>HIT LIST:</b>\n${hitLines.join('\n')}`:'',
    ].filter(x=>x!=='').join('\n');
    if (pmId) edit(chatId,pmId,finalMsg,kb([btn(`${em.refresh()} Batch lại`,'menu_batch'),btn(`${em.chart()} Menu`,'menu_main')]));
}

// ─── Gate command handler ─────────────────────────────────────────────────────
async function handleGateCmd(msg, cmdKey, argText) {
    const chatId=msg.chat.id, tgId=msg.from.id;
    const gateId=CMD_GATE[cmdKey], gateConf=GATES[gateId];
    if (!gateConf) return;
    if (!isGateOn(gateId)) return send(chatId,`${em.nope()} Gate <b>${gateConf.label}</b> đang tắt.`);

    if (!isAdmin(tgId)&&getUsed(tgId)>=DAILY_LIMIT) {
        return send(chatId,`${em.warn()} Hết limit hôm nay! (${DAILY_LIMIT} checks/ngày). Reset lúc 00:00 UTC.`);
    }

    const text=(argText||'').trim();

    if (gateConf.needProxy) {
        const card=text?parseCard(text):null;
        if (card) {
            const e=validateCard(card.cc,card.mm,card.yy,card.cvv);
            if (e) return send(chatId,`${em.cross()} ${e}`);
            if (isVNCard(card.cc)) return send(chatId,`${em.noEntry()} Thẻ VN không được phép.`);
            setState(chatId,{step:'await_ssop_proxy',card,gateId});
            return send(chatId,[
                `${em.proxy()} <b>Shopify Auto</b>`,``,
                `Nhập proxy + site:`,
                `<code>ip:port:user:pass https://store.com</code>`,
            ].join('\n'),kb([btn(`${em.cross()} Hủy`,'cancel')]));
        }
        setState(chatId,{step:'await_ssop_card',gateId});
        return send(chatId,`${em.proxy()} <b>Shopify Auto</b>\n\nGửi thẻ <code>cc|mm|yy|cvv</code>:`,kb([btn(`${em.cross()} Hủy`,'cancel')]));
    }

    if (gateConf.needSite) {
        const card=text?parseCard(text):null;
        if (card) {
            const e=validateCard(card.cc,card.mm,card.yy,card.cvv);
            if (e) return send(chatId,`${em.cross()} ${e}`);
            setState(chatId,{step:'await_site',card,gateId});
            return send(chatId,`${em.globe()} Nhập site URL:`,kb([btn(`${em.cross()} Hủy`,'cancel')]));
        }
        setState(chatId,{step:'await_site_card',gateId});
        return send(chatId,`${em.card()} Gửi thẻ <code>cc|mm|yy|cvv</code>:`,kb([btn(`${em.cross()} Hủy`,'cancel')]));
    }

    if (!text) {
        setState(chatId,{step:'await_card_for_gate',gateId});
        return send(chatId,[
            `${em.target()} <b>${gateConf.emoji} ${gateConf.label}</b>`,``,
            `Gửi thẻ <code>cc|mm|yy|cvv</code>:`,
        ].join('\n'),kb([btn(`${em.cross()} Hủy`,'cancel')]));
    }

    const card=parseCard(text);
    if (!card) return send(chatId,`${em.cross()} Format: <code>cc|mm|yy|cvv</code>`);
    const ev=validateCard(card.cc,card.mm,card.yy,card.cvv);
    if (ev) return send(chatId,`${em.cross()} ${ev}`);
    if (isVNCard(card.cc)) return send(chatId,`${em.noEntry()} Thẻ VN không được phép.`);
    await runCheck(chatId,tgId,card,gateId);
}

// ─── Register slash commands ──────────────────────────────────────────────────
for (const [cmd] of Object.entries(CMD_GATE)) {
    bot.onText(new RegExp(`^\\/${cmd}(?:\\s+(.+))?$`,'i'),(msg,match)=>{
        handleGateCmd(msg,cmd,(match[1]||'').trim());
    });
}

// ─── /start ──────────────────────────────────────────────────────────────────
bot.onText(/\/start(?:\s|$)/,(msg)=>{
    clearState(msg.chat.id);
    send(msg.chat.id,mainText(msg.from.id),mainMenu(msg.from.id));
});

// ─── /menu ───────────────────────────────────────────────────────────────────
bot.onText(/\/menu(?:\s|$)/,(msg)=>{
    clearState(msg.chat.id);
    send(msg.chat.id,mainText(msg.from.id),mainMenu(msg.from.id));
});

// ─── /bin <number> ───────────────────────────────────────────────────────────
bot.onText(/\/bin(?:\s+(\d+))?$/,async(msg,match)=>{
    const chatId=msg.chat.id;
    const bin=(match[1]||'').replace(/\D/g,'');
    if (bin.length<6) {
        setState(chatId,{step:'await_bin'});
        return send(chatId,`${em.search()} Nhập BIN (6–8 chữ số):`,kb([btn(`${em.cross()} Hủy`,'cancel')]));
    }
    doBin(chatId,bin);
});
async function doBin(chatId,bin) {
    const w=await send(chatId,`${em.search()} Tra cứu <code>${bin}</code>...`);
    const info=await binLookup(bin);
    const brand=info?(info.brand||info.scheme||'').toUpperCase():(bin.startsWith('4')?'VISA':bin.startsWith('5')?'MASTERCARD':'UNKNOWN');
    const text=[
        `${em.search()} <b>BIN Lookup — ${bin}</b>`,``,
        `<b>Brand:</b> ${brand}`,
        `<b>Type:</b> ${info?(info.type||'').toUpperCase():'N/A'}`,
        `<b>Level:</b> ${info?(info.level||info.category||'').toUpperCase():'N/A'}`,
        `<b>Bank:</b> ${info?(info.bank||info.issuer||'Unknown'):'Unknown'}`,
        `<b>Country:</b> ${info?(info.country_name||info.country||'Unknown'):'Unknown'}`,
        `<b>Prepaid:</b> ${info?(info.prepaid?'Yes':'No'):'Unknown'}`,
        `<b>Currency:</b> ${info?(info.currency||'USD'):'USD'}`,
    ].join('\n');
    if (w) bot.editMessageText(text,{chat_id:chatId,message_id:w.message_id,parse_mode:'HTML'}).catch(()=>{});
}

// ─── /fake [country] ─────────────────────────────────────────────────────────
bot.onText(/\/fake(?:\s+([A-Za-z]{2}))?$/,(msg,match)=>{
    const chatId=msg.chat.id;
    const country=(match[1]||'US').toUpperCase();
    const f=genFakeInfo(country);
    send(chatId,[
        `${em.dice()} <b>Fake Info — ${country}</b>`,``,
        `<b>Name:</b> ${f.first} ${f.last}`,
        `<b>Username:</b> <code>${f.username}</code>`,
        `<b>Email:</b> <code>${f.email}</code>`,
        `<b>Password:</b> <code>${f.password}</code>`,
        `<b>Phone:</b> ${f.phone}`,
        `<b>Address:</b> ${f.address}, ${f.city}, ${f.zip}`,
        `<b>Country:</b> ${f.country}`,
        `<b>DOB:</b> ${f.dob}`,
        `<b>SSN:</b> <code>${f.ssn}</code>`,
    ].join('\n'),kb([[btn(`🔄 Tạo lại ${country}`,`fake_${country}`),btn(`⬅️ Menu`,'menu_main')]]));
});

// ─── /stats ───────────────────────────────────────────────────────────────────
bot.onText(/\/stats(?:\s|$)/,(msg)=>{
    const chatId=msg.chat.id,tgId=msg.from.id;
    const db=readDB(),today=TODAY();
    const todayC=(db.stats||{})[today]||0,todayL=(db.statsLive||{})[today]||0;
    const total=Object.values(db.stats||{}).reduce((a,b)=>a+b,0);
    const totalL=Object.values(db.statsLive||{}).reduce((a,b)=>a+b,0);
    const used=isAdmin(tgId)?'∞':`${getUsed(tgId)}/${DAILY_LIMIT}`;
    send(chatId,[
        `${em.chart()} <b>Stats</b>`,``,
        `${em.fire()} <b>Today:</b> ${todayC} checks / ${todayL} hits`,
        `${em.chart()} <b>Total:</b> ${total} checks / ${totalL} hits`,
        `${em.clock()} <b>Your today:</b> ${used}`,
    ].join('\n'),kb([[btn(`${em.refresh()} Refresh`,'menu_stats'),btn(`⬅️ Menu`,'menu_main')]]));
});

// ─── /help ───────────────────────────────────────────────────────────────────
bot.onText(/\/help(?:\s|$)/,(msg)=>{
    const tgId=msg.from.id,chatId=msg.chat.id;
    const lines=[
        `${em.robot()} <b>TreTrauChecker — Hướng dẫn</b>`,``,
        `${em.bolt()} <b>Auth Gates:</b>`,
        `/auth &lt;cc|mm|yy|cvv&gt;`,
        `/auth2  /aydenauth  /vbv`,``,
        `${em.fire()} <b>Charge Gates:</b>`,
        `/strip5  /strip1  /ccn3`,
        `/square1  /pp1  /ppwp1`,``,
        `${em.proxy()} <b>Shopify:</b>`,
        `/ssop &lt;cc&gt; → gửi proxy+site`,``,
        `${em.search()} <b>Tiện ích:</b>`,
        `/bin &lt;số&gt; — BIN lookup`,
        `/fake &lt;US/UK/DE...&gt; — Fake info`,
        `/stats — Thống kê`,``,
        `${em.folder()} Gửi file <b>.txt</b> → batch check (max 30/ngày)`,
        `${em.card()} Gửi thẻ trực tiếp → chọn gate`,``,
        `${em.warn()} Giới hạn: <b>${DAILY_LIMIT} checks/ngày</b>`,
    ];
    if (isAdmin(tgId)) {
        lines.push(``,`${em.shield()} <b>Admin:</b>`);
        lines.push(`/info &lt;user&gt;  /addcredits  /setplan`);
        lines.push(`/ban &lt;user&gt;  /unban &lt;user&gt;`);
        lines.push(`/resetlimit &lt;tgId&gt;`);
    }
    send(chatId,lines.join('\n'),kb([[btn(`${em.chart()} Menu`,'menu_main')]]));
});

// ─── Admin commands ───────────────────────────────────────────────────────────
bot.onText(/\/resetlimit(?:\s+(\d+))?$/,(msg,match)=>{
    if (!isAdmin(msg.from.id)) return;
    const targetId=match[1]?parseInt(match[1]):null;
    if (targetId) {
        resetUsed(targetId);
        send(msg.chat.id,`${em.check()} Đã reset limit cho TG ID <code>${targetId}</code>.`);
    } else {
        // Reset all
        saveUsage({});
        send(msg.chat.id,`${em.check()} Đã reset limit tất cả users.`);
    }
});

bot.onText(/\/info (.+)/,(msg,match)=>{
    if (!isAdmin(msg.from.id)) return;
    const target=match[1].trim().toLowerCase();
    const db=readDB();
    const u=db.users[target];
    if (!u) return send(msg.chat.id,`${em.cross()} Không tìm thấy user <code>${target}</code>.`);
    const banned=(db.banned||[]).includes(u.username);
    const hist=u.history||[],hits=hist.filter(h=>h.status==='APPROVED'||h.status==='CHARGED').length;
    send(msg.chat.id,[
        `${em.person()} <b>User Info</b>`,``,
        `<b>Username:</b> <code>${u.username}</code>`,
        `<b>Plan:</b> ${u.plan||'free'}`,
        `<b>Credits:</b> ${(u.credits||0).toFixed(2)} cr`,
        `<b>Hits/Total:</b> ${hits}/${hist.length}`,
        `<b>TG ID:</b> ${u.telegramId||'N/A'}`,
        `<b>Joined:</b> ${fmtDate(u.createdAt)}`,
        `<b>Status:</b> ${banned?`${em.noEntry()} Banned`:`${em.check()} Active`}`,
    ].join('\n'),kb(
        [btn(`${em.money()} Add Credits`,`admin_uc_${target}`),btn(`${em.gear()} Set Plan`,`admin_up_${target}`)],
        [btn(`${em.noEntry()} Ban`,`admin_ban_${target}`),btn(`${em.check()} Unban`,`admin_unban_${target}`)],
    ));
});

bot.onText(/\/addcredits (\S+) (\d+(?:\.\d+)?)/,(msg,match)=>{
    if (!isAdmin(msg.from.id)) return;
    const target=match[1].trim().toLowerCase(),amount=parseFloat(match[2]);
    const db=readDB();
    if (!db.users[target]) return send(msg.chat.id,`${em.cross()} User không tồn tại.`);
    db.users[target].credits=Math.round(((db.users[target].credits||0)+amount)*100)/100;
    writeDB(db);
    send(msg.chat.id,`${em.check()} Đã thêm <b>${amount} cr</b> cho <code>${target}</code>.`);
});

bot.onText(/\/setplan (\S+) (free|basic|premium|reign)(?:\s+(\d+))?/,(msg,match)=>{
    if (!isAdmin(msg.from.id)) return;
    const target=match[1].trim().toLowerCase(),planId=match[2];
    const planDays={basic:30,premium:60,reign:150};
    const days=match[3]?parseInt(match[3]):(planDays[planId]||30);
    const db=readDB();
    if (!db.users[target]) return send(msg.chat.id,`${em.cross()} User không tồn tại.`);
    db.users[target].plan=planId;
    db.users[target].planExpiry=planId==='free'?null:new Date(Date.now()+days*86400000).toISOString();
    writeDB(db);
    send(msg.chat.id,`${em.check()} Set plan <b>${planId}</b> cho <code>${target}</code>${planId!=='free'?` (${days}d)`:''}.`);
});

bot.onText(/\/ban (.+)/,(msg,match)=>{
    if (!isAdmin(msg.from.id)) return;
    const target=match[1].trim().toLowerCase();
    withDB(db=>{if(!db.banned)db.banned=[];if(!db.banned.includes(target))db.banned.push(target);});
    send(msg.chat.id,`${em.noEntry()} Đã ban <code>${target}</code>.`);
});
bot.onText(/\/unban (.+)/,(msg,match)=>{
    if (!isAdmin(msg.from.id)) return;
    const target=match[1].trim().toLowerCase();
    withDB(db=>{if(db.banned)db.banned=db.banned.filter(u=>u!==target);});
    send(msg.chat.id,`${em.check()} Đã unban <code>${target}</code>.`);
});

// ─── Document (batch file) ────────────────────────────────────────────────────
bot.on('document',async(msg)=>{
    const chatId=msg.chat.id,tgId=msg.from.id;
    if (!isAdmin(tgId)&&getUsed(tgId)>=DAILY_LIMIT) {
        return send(chatId,`${em.warn()} Hết limit hôm nay! (${DAILY_LIMIT}/ngày). Reset 00:00 UTC.`);
    }
    const doc=msg.document;
    if (!(doc.file_name||'').toLowerCase().endsWith('.txt')) return send(chatId,`${em.cross()} Chỉ hỗ trợ file .txt`);
    if (doc.file_size>500*1024) return send(chatId,`${em.cross()} File quá lớn (max 500KB).`);
    let content='';
    try {
        const fi=await bot.getFile(doc.file_id);
        const url=`https://api.telegram.org/file/bot${BOT_TOKEN}/${fi.file_path}`;
        content=await new Promise((res,rej)=>{
            https.get(url,r=>{let d='';r.on('data',c=>d+=c);r.on('end',()=>res(d));}).on('error',rej);
            setTimeout(()=>rej(new Error('timeout')),15000);
        });
    } catch(e) { return send(chatId,`${em.siren()} Lỗi tải file.`); }
    const cards=parseCards(content);
    if (cards.length===0) return send(chatId,`${em.cross()} Không tìm thấy thẻ hợp lệ.`);
    const limit=isAdmin(tgId)?100:Math.min(DAILY_LIMIT-getUsed(tgId),100);
    setState(chatId,{step:'batch_pick_gate',cards,limit});
    send(chatId,[
        `${em.folder()} <b>File nhận được</b>`,
        `${em.card()} Tìm thấy <b>${cards.length}</b> thẻ`,
        `${em.chart()} Sẽ check tối đa <b>${limit}</b> thẻ`,``,
        `Chọn gate:`,
    ].join('\n'),allGateKb('batch_'));
});

// ─── Text messages ────────────────────────────────────────────────────────────
bot.on('message',async(msg)=>{
    if (!msg.text||msg.text.startsWith('/')) return;
    const chatId=msg.chat.id,tgId=msg.from.id,text=msg.text.trim();
    const st=getState(chatId);

    // BIN input
    if (st.step==='await_bin') { clearState(chatId); const b=text.replace(/\D/g,'').substring(0,8); if(b.length<6)return send(chatId,`${em.cross()} BIN ít nhất 6 số.`); return doBin(chatId,b); }

    // Card for specific gate
    if (st.step==='await_card_for_gate') {
        const card=parseCard(text); if(!card)return send(chatId,`${em.cross()} Format: <code>cc|mm|yy|cvv</code>`);
        const e=validateCard(card.cc,card.mm,card.yy,card.cvv); if(e)return send(chatId,`${em.cross()} ${e}`);
        if(isVNCard(card.cc))return send(chatId,`${em.noEntry()} Thẻ VN không được phép.`);
        const gateId=st.gateId; clearState(chatId);
        return runCheck(chatId,tgId,card,gateId);
    }

    // Shopify: card
    if (st.step==='await_ssop_card') {
        const card=parseCard(text); if(!card)return send(chatId,`${em.cross()} Format: <code>cc|mm|yy|cvv</code>`);
        const e=validateCard(card.cc,card.mm,card.yy,card.cvv); if(e)return send(chatId,`${em.cross()} ${e}`);
        if(isVNCard(card.cc))return send(chatId,`${em.noEntry()} Thẻ VN không được phép.`);
        setState(chatId,{...st,step:'await_ssop_proxy',card});
        return send(chatId,`${em.proxy()} Nhập proxy + site:\n<code>ip:port:user:pass https://store.com</code>`,kb([btn(`${em.cross()} Hủy`,'cancel')]));
    }

    // Shopify: proxy (+site optional)
    if (st.step==='await_ssop_proxy') {
        const parts=text.split(/\s+/),proxy=parts[0],site=parts[1]||null;
        if(!proxy||!proxy.includes(':'))return send(chatId,`${em.cross()} Proxy format: <code>ip:port:user:pass</code>`);
        if(site){try{new URL(site);}catch{return send(chatId,`${em.cross()} URL không hợp lệ.`);} clearState(chatId); return runCheck(chatId,tgId,st.card,st.gateId,site,proxy);}
        setState(chatId,{...st,step:'await_ssop_site',proxy});
        return send(chatId,`${em.globe()} Nhập site URL (vd: <code>https://store.com</code>):`,kb([btn(`${em.cross()} Hủy`,'cancel')]));
    }

    // Shopify: site
    if (st.step==='await_ssop_site') {
        try{new URL(text);}catch{return send(chatId,`${em.cross()} URL không hợp lệ.`);}
        const{card,proxy,gateId}=st; clearState(chatId);
        return runCheck(chatId,tgId,card,gateId,text,proxy);
    }

    // needSite: card first
    if (st.step==='await_site_card') {
        const card=parseCard(text); if(!card)return send(chatId,`${em.cross()} Format: <code>cc|mm|yy|cvv</code>`);
        const e=validateCard(card.cc,card.mm,card.yy,card.cvv); if(e)return send(chatId,`${em.cross()} ${e}`);
        setState(chatId,{...st,step:'await_site',card});
        return send(chatId,`${em.globe()} Nhập site URL:`,kb([btn(`${em.cross()} Hủy`,'cancel')]));
    }
    if (st.step==='await_site') {
        try{new URL(text);}catch{return send(chatId,`${em.cross()} URL không hợp lệ.`);}
        const{card,gateId}=st; clearState(chatId);
        return runCheck(chatId,tgId,card,gateId,text);
    }

    // Admin announce
    if (st.step==='await_announce'&&isAdmin(tgId)) {
        clearState(chatId);
        if (text==='-') { withDB(db=>{db.notification={active:false};}); return send(chatId,`${em.check()} Đã xóa.`,kb([[btn(`⬅️ Admin`,'admin_main')]])); }
        withDB(db=>{db.notification={active:true,message:text,type:'info',ts:new Date().toISOString()};});
        return send(chatId,`${em.check()} Thông báo đã lưu.`,kb([[btn(`⬅️ Admin`,'admin_main')]]));
    }

    // Admin credits
    if (st.step==='await_credits_amount'&&isAdmin(tgId)) {
        const amount=parseFloat(text);
        if (isNaN(amount)||amount<=0) return send(chatId,`${em.cross()} Nhập số hợp lệ.`);
        const db=readDB();
        if (db.users[st.data.username]) {
            db.users[st.data.username].credits=Math.round(((db.users[st.data.username].credits||0)+amount)*100)/100;
            writeDB(db);
        }
        clearState(chatId);
        return send(chatId,`${em.check()} Đã thêm <b>${amount} cr</b> cho <code>${st.data.username}</code>.`,kb([[btn(`⬅️ Admin`,'admin_main')]]));
    }

    // Admin user search
    if (st.step==='await_user_search'&&isAdmin(tgId)) {
        clearState(chatId);
        const target=text.toLowerCase(),db=readDB(),u=db.users[target];
        if (!u) return send(chatId,`${em.cross()} Không tìm thấy.`,kb([[btn(`⬅️ Admin`,'admin_main')]]));
        const banned=(db.banned||[]).includes(u.username);
        const hist=u.history||[],hits=hist.filter(h=>h.status==='APPROVED'||h.status==='CHARGED').length;
        return send(chatId,[
            `${em.person()} <b>User:</b> <code>${u.username}</code>`,
            `<b>Plan:</b> ${u.plan||'free'}  <b>Credits:</b> ${(u.credits||0).toFixed(2)} cr`,
            `<b>Hits:</b> ${hits}/${hist.length}  <b>Status:</b> ${banned?'⛔ Banned':'✅ Active'}`,
        ].join('\n'),kb(
            [btn(`${em.money()} Add Credits`,`admin_uc_${target}`),btn(`${em.gear()} Set Plan`,`admin_up_${target}`)],
            [btn(`${em.noEntry()} Ban`,`admin_ban_${target}`),btn(`${em.check()} Unban`,`admin_unban_${target}`)],
            [btn(`⬅️ Admin`,'admin_main')],
        ));
    }

    // Default: parse as card
    const card=parseCard(text);
    if (!card) return;
    const ev=validateCard(card.cc,card.mm,card.yy,card.cvv);
    if (ev) return send(chatId,`${em.cross()} ${ev}`);
    if (isVNCard(card.cc)) return send(chatId,`${em.noEntry()} Thẻ VN không được phép.`);
    if (!isAdmin(tgId)&&getUsed(tgId)>=DAILY_LIMIT) return send(chatId,`${em.warn()} Hết limit hôm nay! (${DAILY_LIMIT}/ngày).`);
    setState(chatId,{step:'pick_gate',card});
    send(chatId,[
        `${em.card()} <code>${card.cc}|${card.mm}|${card.yy}|${card.cvv}</code>`,
        `${em.target()} Chọn gate:`,
    ].join('\n'),allGateKb('pick_'));
});

// ─── Callback Queries ─────────────────────────────────────────────────────────
bot.on('callback_query',async(query)=>{
    const chatId=query.message?.chat?.id,msgId=query.message?.message_id;
    const data=query.data||'',tgId=query.from.id;
    answerCb(query.id);
    if (data==='noop') return;

    // Cancel / Back
    if (data==='cancel'||data==='menu_main') {
        clearState(chatId);
        return edit(chatId,msgId,mainText(tgId),mainMenu(tgId));
    }

    // ── Gate pick (single card) ───────────────────────────────────────────────
    if (data.startsWith('pick_')) {
        const gateId=data.replace('pick_','');
        const gateConf=GATES[gateId];
        if (!gateConf) return;
        if (!isGateOn(gateId)) return bot.answerCallbackQuery(query.id,{text:'Gate đang tắt!',show_alert:true});
        const st=getState(chatId);
        if (!st.card) return edit(chatId,msgId,`${em.cross()} Session hết hạn. Gửi lại thẻ.`);
        if (gateConf.needProxy) {
            setState(chatId,{...st,step:'await_ssop_proxy',gateId});
            return edit(chatId,msgId,`${em.proxy()} Nhập proxy + site:\n<code>ip:port:user:pass https://store.com</code>`,kb([btn(`${em.cross()} Hủy`,'cancel')]));
        }
        if (gateConf.needSite) {
            setState(chatId,{...st,step:'await_site',gateId});
            return edit(chatId,msgId,`${em.globe()} Nhập site URL:`,kb([btn(`${em.cross()} Hủy`,'cancel')]));
        }
        clearState(chatId);
        return runCheck(chatId,tgId,st.card,gateId,null,null,msgId);
    }

    // ── Gate pick (batch) ─────────────────────────────────────────────────────
    if (data.startsWith('batch_')) {
        const gateId=data.replace('batch_','');
        const gateConf=GATES[gateId];
        if (!gateConf) return;
        if (!isGateOn(gateId)) return bot.answerCallbackQuery(query.id,{text:'Gate đang tắt!',show_alert:true});
        const{cards}=getState(chatId);
        if (!cards) return edit(chatId,msgId,`${em.cross()} Session hết hạn.`);
        if (gateConf.needProxy) {
            setState(chatId,{step:'await_ssop_proxy',cards,gateId,isBatch:true});
            return edit(chatId,msgId,`${em.proxy()} <b>Shopify Batch</b>\nNhập proxy + site:\n<code>ip:port:user:pass https://store.com</code>`,kb([btn(`${em.cross()} Hủy`,'cancel')]));
        }
        clearState(chatId);
        edit(chatId,msgId,`${em.rocket()} Batch đang khởi động...`);
        runBatch(chatId,tgId,cards,gateId);
        return;
    }

    // ── Re-pick gate after result ─────────────────────────────────────────────
    if (data.startsWith('repick_')) {
        const raw=data.replace('repick_','');
        const p=raw.split('|');
        if (p.length===4) {
            setState(chatId,{step:'pick_gate',card:{cc:p[0],mm:p[1],yy:p[2],cvv:p[3]}});
            return edit(chatId,msgId,[`${em.card()} <code>${raw}</code>`,`${em.target()} Chọn gate:`].join('\n'),allGateKb('pick_'));
        }
    }

    // ── Menu: Auth gates ──────────────────────────────────────────────────────
    if (data==='menu_auth') {
        setState(chatId,{step:'pick_gate_type',type:'auth'});
        return edit(chatId,msgId,`${em.bolt()} <b>Auth Gates</b>\n\nGửi thẻ rồi chọn gate, hoặc chọn gate trước:`,gateKb('pick_',['auth']));
    }
    if (data==='menu_charge') {
        setState(chatId,{step:'pick_gate_type',type:'charge'});
        return edit(chatId,msgId,`${em.fire()} <b>Charge Gates</b>`,gateKb('pick_',['charge']));
    }
    if (data==='menu_shopify') {
        setState(chatId,{step:'await_ssop_card',gateId:'shopify'});
        return edit(chatId,msgId,`${em.proxy()} <b>Shopify Auto</b>\n\nGửi thẻ <code>cc|mm|yy|cvv</code>:`,kb([btn(`${em.cross()} Hủy`,'cancel')]));
    }
    if (data==='menu_bin') {
        setState(chatId,{step:'await_bin'});
        return edit(chatId,msgId,`${em.search()} <b>BIN Lookup</b>\n\nNhập BIN (6–8 chữ số):`,kb([btn(`${em.cross()} Hủy`,'cancel')]));
    }
    if (data==='menu_batch') {
        return edit(chatId,msgId,[
            `${em.folder()} <b>Batch Check</b>`,``,
            `Gửi file <b>.txt</b> mỗi dòng một thẻ:`,
            `<code>cc|mm|yy|cvv</code>`,``,
            `${em.warn()} Giới hạn: <b>${DAILY_LIMIT} checks/ngày</b>`,
        ].join('\n'),kb([[btn(`⬅️ Menu`,'menu_main')]]));
    }
    if (data==='menu_fake') {
        const f=genFakeInfo('US');
        return edit(chatId,msgId,[
            `${em.dice()} <b>Fake Info — US</b>`,``,
            `<b>Name:</b> ${f.first} ${f.last}`,
            `<b>Email:</b> <code>${f.email}</code>`,
            `<b>Password:</b> <code>${f.password}</code>`,
            `<b>Phone:</b> ${f.phone}`,
            `<b>Address:</b> ${f.address}, ${f.city}, ${f.zip}`,
            `<b>DOB:</b> ${f.dob}`,
            `<b>SSN:</b> <code>${f.ssn}</code>`,
        ].join('\n'),kb([
            [btn('🔄 US',`fake_US`),btn('🔄 UK',`fake_UK`),btn('🔄 DE',`fake_DE`)],
            [btn('🔄 FR',`fake_FR`),btn('🔄 CA',`fake_CA`),btn('🔄 AU',`fake_AU`)],
            [btn(`⬅️ Menu`,'menu_main')],
        ]));
    }
    if (data.startsWith('fake_')) {
        const country=data.replace('fake_','');
        const f=genFakeInfo(country);
        return edit(chatId,msgId,[
            `${em.dice()} <b>Fake Info — ${country}</b>`,``,
            `<b>Name:</b> ${f.first} ${f.last}`,
            `<b>Email:</b> <code>${f.email}</code>`,
            `<b>Password:</b> <code>${f.password}</code>`,
            `<b>Phone:</b> ${f.phone}`,
            `<b>Address:</b> ${f.address}, ${f.city}, ${f.zip}`,
            `<b>DOB:</b> ${f.dob}`,
            `<b>SSN:</b> <code>${f.ssn}</code>`,
        ].join('\n'),kb([
            [btn('🔄 US',`fake_US`),btn('🔄 UK',`fake_UK`),btn('🔄 DE',`fake_DE`)],
            [btn('🔄 FR',`fake_FR`),btn('🔄 CA',`fake_CA`),btn('🔄 AU',`fake_AU`)],
            [btn(`⬅️ Menu`,'menu_main')],
        ]));
    }
    if (data==='menu_stats') {
        const db=readDB(),today=TODAY();
        const todayC=(db.stats||{})[today]||0,todayL=(db.statsLive||{})[today]||0;
        const total=Object.values(db.stats||{}).reduce((a,b)=>a+b,0);
        const used=isAdmin(tgId)?'∞':`${getUsed(tgId)}/${DAILY_LIMIT}`;
        return edit(chatId,msgId,[
            `${em.chart()} <b>Stats</b>`,``,
            `${em.fire()} Today: <b>${todayC}</b> checks / <b>${todayL}</b> hits`,
            `${em.chart()} Total: <b>${total}</b> checks`,
            `${em.clock()} Your today: <b>${used}</b>`,
        ].join('\n'),kb([[btn(`${em.refresh()} Refresh`,'menu_stats'),btn(`⬅️ Menu`,'menu_main')]]));
    }
    if (data==='menu_help') {
        return edit(chatId,msgId,[
            `${em.info()} <b>Lệnh nhanh:</b>`,``,
            `/auth /auth2 /vbv /aydenauth`,
            `/strip5 /strip1 /ccn3`,
            `/square1 /pp1 /ppwp1`,
            `/ssop — Shopify (cần proxy+site)`,
            `/bin &lt;số&gt; — BIN lookup`,
            `/fake &lt;US/UK&gt; — Fake info`,
            `/stats — Thống kê`,``,
            `${em.warn()} <b>Limit:</b> ${DAILY_LIMIT} checks/ngày`,
        ].join('\n'),kb([[btn(`⬅️ Menu`,'menu_main')]]));
    }

    // ════════════════ ADMIN ════════════════
    if (!isAdmin(tgId)) {
        if (data.startsWith('admin_')) bot.answerCallbackQuery(query.id,{text:'Không có quyền.',show_alert:true});
        return;
    }

    if (data==='admin_main') {
        const db=readDB(),today=TODAY();
        const total=Object.keys(db.users||{}).length;
        const todayC=(db.stats||{})[today]||0,todayL=(db.statsLive||{})[today]||0;
        const pend=Object.values(db.orders||{}).filter(o=>o.status==='pending').length;
        return edit(chatId,msgId,[
            `${em.shield()} <b>Admin Panel</b>`,``,
            `${em.group()} Web Users: <b>${total}</b>`,
            `${em.fire()} Today: <b>${todayC}</b> checks / <b>${todayL}</b> hits`,
            pend>0?`${em.warn()} Pending orders: <b>${pend}</b>`:'',
        ].filter(Boolean).join('\n'),kb(
            [btn(`${em.chart()} Overview`,'admin_overview'),btn(`${em.group()} Users`,'admin_users')],
            [btn(`${em.bolt()} Gates`,'admin_gates'),       btn(`${em.chart()} Feed`,'admin_feed')],
            [btn(`${em.speaker()} Announce`,'admin_announce'),btn(`${em.trash()} Clear Announce`,'admin_clear_ann')],
            [btn(`${em.refresh()} Refresh`,'admin_main')],
        ));
        return;
    }
    if (data==='admin_overview') {
        const db=readDB(),today=TODAY();
        const total=Object.keys(db.users||{}).length,banned=(db.banned||[]).length;
        const premium=Object.values(db.users||{}).filter(u=>['basic','premium','reign'].includes(u.plan)).length;
        const todayC=(db.stats||{})[today]||0,todayL=(db.statsLive||{})[today]||0;
        const allChecks=Object.values(db.stats||{}).reduce((a,b)=>a+b,0);
        return edit(chatId,msgId,[
            `${em.chart()} <b>Overview</b>`,``,
            `${em.group()} Web Users: ${total} total | ${premium} premium | ${banned} banned`,
            `${em.fire()} Today: ${todayC} checks | ${todayL} hits`,
            `${em.chart()} All time: ${allChecks} checks`,
        ].join('\n'),kb([[btn(`${em.refresh()} Refresh`,'admin_overview'),btn(`⬅️ Admin`,'admin_main')]]));
    }
    if (data==='admin_users'||data.startsWith('admin_users_')) {
        const page=data.startsWith('admin_users_')?parseInt(data.replace('admin_users_',''))||0:0;
        const db=readDB();
        const users=Object.values(db.users||{}).sort((a,b)=>new Date(b.createdAt)-new Date(a.createdAt));
        const perPage=8,slice=users.slice(page*perPage,(page+1)*perPage);
        const lines=slice.map(u=>{
            const badge=['basic','premium','reign'].includes(u.plan)?`[${u.plan.toUpperCase()}]`:'';
            const bnd=(db.banned||[]).includes(u.username)?'⛔':'';
            return `• <code>${u.username}</code>${badge?' '+badge:''} ${bnd} — ${(u.credits||0).toFixed(0)} cr`;
        }).join('\n');
        const nav=[];
        if (page>0) nav.push(btn(`◀️`,`admin_users_${page-1}`));
        if ((page+1)*perPage<users.length) nav.push(btn(`▶️`,`admin_users_${page+1}`));
        return edit(chatId,msgId,[`${em.group()} <b>Web Users</b> (${users.length}) — trang ${page+1}`,``,lines||'Trống.'].join('\n'),kb(
            ...(nav.length?[nav]:[]),
            [btn(`${em.search()} Tìm user`,'admin_search_user')],
            [btn(`⬅️ Admin`,'admin_main')],
        ));
    }
    if (data==='admin_search_user') { setState(chatId,{step:'await_user_search'}); return edit(chatId,msgId,`${em.search()} Nhập username:`,kb([[btn(`${em.cross()} Hủy`,'admin_main')]])); }
    if (data.startsWith('admin_uc_')) { const t=data.replace('admin_uc_',''); setState(chatId,{step:'await_credits_amount',data:{username:t}}); return edit(chatId,msgId,`${em.money()} Số credits thêm cho <code>${t}</code>:`,kb([[btn(`${em.cross()} Hủy`,'admin_main')]])); }
    if (data.startsWith('admin_up_')) {
        const t=data.replace('admin_up_','');
        return edit(chatId,msgId,`${em.gear()} Plan cho <code>${t}</code>:`,kb(
            [btn('Free',`admin_sp_${t}_free`),btn('Basic 30d',`admin_sp_${t}_basic`)],
            [btn('Premium 60d',`admin_sp_${t}_premium`),btn('Reign 150d',`admin_sp_${t}_reign`)],
            [btn(`⬅️ Admin`,'admin_main')],
        ));
    }
    if (data.startsWith('admin_sp_')) {
        const raw=data.replace('admin_sp_',''),planId=raw.split('_').pop(),target=raw.split('_').slice(0,-1).join('_');
        const planDays={basic:30,premium:60,reign:150};
        const db=readDB();
        if (db.users[target]) {
            db.users[target].plan=planId;
            db.users[target].planExpiry=planId==='free'?null:new Date(Date.now()+(planDays[planId]||30)*86400000).toISOString();
            writeDB(db);
        }
        return edit(chatId,msgId,`${em.check()} Set plan <b>${planId}</b> cho <code>${target}</code>.`,kb([[btn(`⬅️ Admin`,'admin_main')]]));
    }
    if (data.startsWith('admin_ban_')) { const t=data.replace('admin_ban_',''); withDB(db=>{if(!db.banned)db.banned=[];if(!db.banned.includes(t))db.banned.push(t);}); return edit(chatId,msgId,`${em.noEntry()} Đã ban <code>${t}</code>.`,kb([[btn(`⬅️ Admin`,'admin_main')]])); }
    if (data.startsWith('admin_unban_')) { const t=data.replace('admin_unban_',''); withDB(db=>{if(db.banned)db.banned=db.banned.filter(u=>u!==t);}); return edit(chatId,msgId,`${em.check()} Đã unban <code>${t}</code>.`,kb([[btn(`⬅️ Admin`,'admin_main')]])); }

    if (data==='admin_gates') {
        const db=readDB();
        const rows=Object.entries(GATES).map(([id,g])=>[btn(`${isGateOn(id)?'🟢':'🔴'} ${g.emoji} ${g.label}`,`admin_gt_${id}`)]);
        rows.push([btn(`⬅️ Admin`,'admin_main')]);
        return edit(chatId,msgId,[
            `${em.bolt()} <b>Gate Management</b>`,``,
            Object.entries(GATES).map(([id,g])=>`${isGateOn(id)?'🟢':'🔴'} ${g.label}`).join('\n'),
        ].join('\n'),kb(...rows));
    }
    if (data.startsWith('admin_gt_')) {
        const gId=data.replace('admin_gt_','');
        setGateOn(gId,!isGateOn(gId));
        const db=readDB();
        const rows=Object.entries(GATES).map(([id,g])=>[btn(`${isGateOn(id)?'🟢':'🔴'} ${g.emoji} ${g.label}`,`admin_gt_${id}`)]);
        rows.push([btn(`⬅️ Admin`,'admin_main')]);
        return edit(chatId,msgId,[
            `${em.bolt()} <b>Gate Management</b>`,``,
            Object.entries(GATES).map(([id,g])=>`${isGateOn(id)?'🟢':'🔴'} ${g.label}`).join('\n'),
        ].join('\n'),kb(...rows));
    }

    if (data==='admin_announce') { setState(chatId,{step:'await_announce'}); return edit(chatId,msgId,`${em.speaker()} <b>Thông báo web</b>\n\nNhập nội dung (gửi "-" để xóa):`,kb([[btn(`${em.cross()} Hủy`,'admin_main')]])); }
    if (data==='admin_clear_ann') { withDB(db=>{db.notification={active:false};}); return edit(chatId,msgId,`${em.check()} Đã xóa thông báo.`,kb([[btn(`⬅️ Admin`,'admin_main')]])); }

    if (data==='admin_feed') {
        const db=readDB();
        const feed=(db.feed||[]).slice(0,12);
        const lines=feed.map(f=>{
            const ic=f.type==='register'?em.person():statusIcon(f.status);
            const d=f.ts?f.ts.substring(0,16).replace('T',' '):'?';
            return f.type==='register'?`${ic} <code>${f.username}</code> — ${d}`:`${ic} <code>${f.username}</code> ${f.bin}*** ${f.gate} ${f.status} — ${d}`;
        }).join('\n');
        return edit(chatId,msgId,[`${em.chart()} <b>Live Feed</b>`,``,lines||'Trống.'].join('\n'),kb([[btn(`${em.refresh()} Refresh`,'admin_feed'),btn(`⬅️ Admin`,'admin_main')]]));
    }
});

bot.on('polling_error',(err)=>console.error('[CheckerBot]',err.code,err.message?.substring(0,80)));
console.log('[CheckerBot] Starting...');
