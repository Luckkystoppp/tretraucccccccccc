#!/usr/bin/env python3
"""
TreTrauChecker — Admin Telegram Bot
Only responds to ADMIN_ID. Full admin panel via buttons.
"""

import telebot
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
import requests
import os
import time
import logging

# Suppress pyTelegramBotAPI's noisy "Break infinity polling" spam on shutdown
logging.getLogger('TeleBot').setLevel(logging.CRITICAL)

# ── Config ────────────────────────────────────────────────────────────────────
ADMIN_BOT_TOKEN = os.environ.get('ADMIN_BOT_TOKEN', '8803020864:AAHu8zj_xWI3gngN0ohF7Apjd7KVzt5mTLA')
ADMIN_ID        = int(os.environ.get('ADMIN_ID', '7490574579'))
SERVER_URL      = 'http://localhost:3456'

def _load_pay_secret():
    p = os.path.join(os.path.dirname(__file__), '..', 'data', '.pay_secret')
    try:
        with open(p) as f: return f.read().strip()
    except: return ''

PAY_SECRET = _load_pay_secret()

# ── API helper ────────────────────────────────────────────────────────────────
def api(method, path, **kwargs):
    headers = {'X-Pay-Secret': PAY_SECRET, 'Content-Type': 'application/json'}
    try:
        r = requests.request(method, SERVER_URL + path, headers=headers, timeout=10, **kwargs)
        return r.json()
    except Exception as e:
        return {'success': False, 'message': str(e)}

# ── Bot ───────────────────────────────────────────────────────────────────────
bot = telebot.TeleBot(ADMIN_BOT_TOKEN, parse_mode='Markdown')

# Per-chat state for multi-step inputs: chat_id -> {'step': str, 'data': dict}
_state = {}

def guard(fn):
    """Only allow ADMIN_ID."""
    def wrapper(obj):
        uid = obj.from_user.id
        if uid != ADMIN_ID:
            return
        return fn(obj)
    return wrapper

# ── Keyboard builders ─────────────────────────────────────────────────────────
def kb_main():
    kb = InlineKeyboardMarkup(row_width=2)
    kb.add(
        InlineKeyboardButton("📊 Overview",     callback_data="m_ov"),
        InlineKeyboardButton("👥 Users",         callback_data="m_ul_0"),
        InlineKeyboardButton("🚦 Gates",         callback_data="m_gates"),
        InlineKeyboardButton("📢 Announce",      callback_data="m_ann"),
    )
    kb.add(InlineKeyboardButton("🔄 Refresh",    callback_data="m_ov"))
    return kb

def kb_back_main():
    kb = InlineKeyboardMarkup()
    kb.add(InlineKeyboardButton("⬅️ Main Menu", callback_data="m_ov"))
    return kb

# ── Overview ──────────────────────────────────────────────────────────────────
def render_overview():
    stats   = api('GET', '/internal/admin/stats')
    traffic = api('GET', '/internal/admin/traffic')

    if not stats.get('success'):
        err = stats.get('message', 'unknown')
        return f"❌ Server error: `{err[:100]}`\n\nCheck: `pm2 restart web`", kb_main()

    t = traffic.get('today', {})
    hist = traffic.get('history', [])[:7]

    lines = [
        "🛡️ *TreTrauChecker — Admin*",
        "",
        f"👥 Users: `{stats.get('totalUsers',0)}`   🚫 Banned: `{stats.get('bannedCount',0)}`",
        f"🟢 Online: `{stats.get('online',0)}`",
        f"✅ Checks today: `{stats.get('checksToday',0)}`   💳 Live: `{stats.get('liveToday',0)}`",
        "",
        f"🌐 Traffic today — Hits: `{t.get('hits',0)}` | IPs: `{t.get('unique',0)}`",
    ]
    if hist:
        lines.append("")
        lines.append("📈 *Last 7 days:*")
        for h in hist:
            lines.append(f"  `{h['date']}` — {h['hits']} hits, {h['unique']} IPs")

    kb = InlineKeyboardMarkup(row_width=2)
    kb.add(
        InlineKeyboardButton("👥 Users",    callback_data="m_ul_0"),
        InlineKeyboardButton("🚦 Gates",    callback_data="m_gates"),
        InlineKeyboardButton("📢 Announce", callback_data="m_ann"),
        InlineKeyboardButton("🔄 Refresh",  callback_data="m_ov"),
    )
    return "\n".join(lines), kb

# ── Users ─────────────────────────────────────────────────────────────────────
PAGE_SIZE = 8

def render_users(page=0):
    data = api('GET', '/internal/admin/users')
    if not data.get('success'):
        return "❌ Failed to load users.", kb_back_main()

    users = data.get('users', [])
    total  = len(users)
    pages  = max(1, (total + PAGE_SIZE - 1) // PAGE_SIZE)
    start  = page * PAGE_SIZE
    chunk  = users[start:start + PAGE_SIZE]

    lines = [f"👥 *Users* ({total} total) — Page {page+1}/{pages}", ""]
    for u in chunk:
        st = "🚫" if u['banned'] else ("👑" if u['vip'] else "👤")
        pi = {"basic":"⭐","premium":"💎","reign":"👑"}.get(u['plan'], "🆓")
        lines.append(f"{st} `{u['username']}` {pi} {u['credits']:.0f}cr")

    kb = InlineKeyboardMarkup(row_width=2)
    for u in chunk:
        st = "🚫" if u['banned'] else ("👑" if u['vip'] else "")
        kb.add(InlineKeyboardButton(
            f"{st} {u['username']} — {u['credits']:.0f}cr [{u['plan']}]",
            callback_data=f"u_{u['username']}"
        ))

    nav = []
    if page > 0:
        nav.append(InlineKeyboardButton("⬅️ Prev", callback_data=f"m_ul_{page-1}"))
    if start + PAGE_SIZE < total:
        nav.append(InlineKeyboardButton("Next ➡️", callback_data=f"m_ul_{page+1}"))
    if nav:
        kb.row(*nav)

    kb.add(
        InlineKeyboardButton("🔍 Search User", callback_data="u_search"),
        InlineKeyboardButton("⬅️ Menu",        callback_data="m_ov"),
    )
    return "\n".join(lines), kb

def render_user(username):
    data = api('GET', '/internal/admin/users')
    if not data.get('success'):
        return "❌ Failed.", kb_back_main()

    u = next((x for x in data.get('users', []) if x['username'] == username.lower()), None)
    if not u:
        return f"❌ User `{username}` not found.", kb_back_main()

    lines = [
        f"👤 *{u['username']}*",
        f"📧 `{u.get('email','N/A')}`",
        f"📱 @{u.get('telegramUsername','—')}",
        f"📦 Plan: `{u['plan']}`",
        f"💰 Credits: `{u['credits']:.2f}`",
        f"👑 VIP: {'✅' if u['vip'] else '❌'}   🚫 Banned: {'✅' if u['banned'] else '❌'}",
        f"📊 Checks: `{u['historyCount']}`",
        f"📅 `{u.get('createdAt','?')[:10]}`",
    ]

    kb = InlineKeyboardMarkup(row_width=2)
    if u['banned']:
        kb.add(InlineKeyboardButton("✅ Unban",       callback_data=f"ub_{username}"))
    else:
        kb.add(InlineKeyboardButton("🚫 Ban",          callback_data=f"bn_{username}"))

    vip_lbl = "❌ Remove VIP" if u['vip'] else "👑 Give VIP"
    kb.add(
        InlineKeyboardButton(vip_lbl,              callback_data=f"vp_{username}"),
        InlineKeyboardButton("💰 Add Credits",      callback_data=f"cr_{username}"),
    )
    kb.add(InlineKeyboardButton("⬅️ Users",         callback_data="m_ul_0"))
    return "\n".join(lines), kb

# ── Gates ─────────────────────────────────────────────────────────────────────
def render_gates():
    data = api('GET', '/internal/admin/gates')
    if not data.get('success'):
        return "❌ Failed to load gates.", kb_back_main()

    gates = data.get('gates', [])
    auth_g   = [g for g in gates if g['type'] == 'auth']
    charge_g = [g for g in gates if g['type'] == 'charge']

    lines = ["🚦 *Gate Control*\nClick a gate to toggle ON/OFF\n"]
    lines.append("*Auth Gates:*")
    for g in auth_g:
        lines.append(f"{'🟢' if g['enabled'] else '🔴'} {g['label']}")
    lines.append("\n*Charge Gates:*")
    for g in charge_g:
        lines.append(f"{'🟢' if g['enabled'] else '🔴'} {g['label']}")

    kb = InlineKeyboardMarkup(row_width=1)
    kb.add(InlineKeyboardButton("── Auth Gates ──", callback_data="noop"))
    for g in auth_g:
        s = "🟢" if g['enabled'] else "🔴"
        # toggle: 0 = disable, 1 = enable
        nv = "0" if g['enabled'] else "1"
        kb.add(InlineKeyboardButton(f"{s} {g['label']}", callback_data=f"gt_{g['id']}_{nv}"))

    kb.add(InlineKeyboardButton("── Charge Gates ──", callback_data="noop"))
    for g in charge_g:
        s = "🟢" if g['enabled'] else "🔴"
        nv = "0" if g['enabled'] else "1"
        kb.add(InlineKeyboardButton(f"{s} {g['label']}", callback_data=f"gt_{g['id']}_{nv}"))

    kb.add(InlineKeyboardButton("⬅️ Menu", callback_data="m_ov"))
    return "\n".join(lines), kb

# ── Announcements ─────────────────────────────────────────────────────────────
TYPE_ICONS = {'info': 'ℹ️', 'warning': '⚠️', 'success': '✅', 'danger': '🚨'}

def render_announcements():
    data = api('GET', '/internal/admin/announcements')
    if not data.get('success'):
        return "❌ Failed.", kb_back_main()

    anns = data.get('announcements', [])
    lines = ["📢 *Announcements*", ""]
    if not anns:
        lines.append("_No announcements yet._")
    else:
        for a in anns[:8]:
            icon = TYPE_ICONS.get(a.get('type','info'), 'ℹ️')
            preview = a['text'][:45] + ('…' if len(a['text']) > 45 else '')
            lines.append(f"{icon} {preview}")

    kb = InlineKeyboardMarkup(row_width=2)
    kb.add(
        InlineKeyboardButton("ℹ️ Post Info",     callback_data="ap_info"),
        InlineKeyboardButton("⚠️ Post Warning",  callback_data="ap_warning"),
        InlineKeyboardButton("✅ Post Success",   callback_data="ap_success"),
        InlineKeyboardButton("🚨 Post Danger",    callback_data="ap_danger"),
    )
    if anns:
        kb.add(InlineKeyboardButton("── Delete ──", callback_data="noop"))
        for a in anns[:5]:
            icon = TYPE_ICONS.get(a.get('type','info'), 'ℹ️')
            kb.add(InlineKeyboardButton(
                f"🗑️ {icon} {a['text'][:28]}…",
                callback_data=f"ad_{a['id']}"
            ))

    kb.add(InlineKeyboardButton("⬅️ Menu", callback_data="m_ov"))
    return "\n".join(lines), kb

# ── Command handlers ──────────────────────────────────────────────────────────
@bot.message_handler(commands=['start'])
@guard
def cmd_start(msg):
    text, kb = render_overview()
    bot.send_message(msg.chat.id, text, reply_markup=kb)

@bot.message_handler(commands=['help'])
@guard
def cmd_help(msg):
    help_text = (
        "🛡️ *TreTrauChecker Admin Bot*\n\n"
        "*Commands:*\n"
        "/start — Main menu & overview\n"
        "/help — This message\n"
        "/ban `<user>` — Ban a user\n"
        "/unban `<user>` — Unban a user\n"
        "/credits `<user>` `<amount>` — Add credits\n"
        "/gate `<id>` `<on|off>` — Toggle gate\n"
        "/announce `<type>` `<text>` — Post announcement\n"
        "  Types: info · warning · success · danger\n\n"
        "*Or use the menu buttons 👇*"
    )
    bot.send_message(msg.chat.id, help_text, reply_markup=kb_main())

@bot.message_handler(commands=['ban'])
@guard
def cmd_ban(msg):
    parts = msg.text.split()
    if len(parts) < 2:
        return bot.send_message(msg.chat.id, "Usage: /ban `<username>`")
    uname = parts[1].lower().lstrip('@')
    r = api('POST', f'/internal/admin/ban/{uname}')
    bot.send_message(msg.chat.id, f"✅ Banned `{uname}`" if r.get('success') else f"❌ {r.get('message','Error')}")

@bot.message_handler(commands=['unban'])
@guard
def cmd_unban(msg):
    parts = msg.text.split()
    if len(parts) < 2:
        return bot.send_message(msg.chat.id, "Usage: /unban `<username>`")
    uname = parts[1].lower().lstrip('@')
    r = api('POST', f'/internal/admin/unban/{uname}')
    bot.send_message(msg.chat.id, f"✅ Unbanned `{uname}`" if r.get('success') else f"❌ {r.get('message','Error')}")

@bot.message_handler(commands=['credits'])
@guard
def cmd_credits(msg):
    parts = msg.text.split()
    if len(parts) < 3:
        return bot.send_message(msg.chat.id, "Usage: /credits `<username>` `<amount>`")
    uname = parts[1].lower().lstrip('@')
    try:
        amount = int(parts[2])
    except ValueError:
        return bot.send_message(msg.chat.id, "❌ Amount must be a number.")
    r = api('POST', '/internal/addcredit', json={'username': uname, 'amount': amount})
    if r.get('success'):
        bot.send_message(msg.chat.id, f"✅ Added `{amount}` cr to `{uname}`\nBalance: `{r.get('newBalance','?')}`")
    else:
        bot.send_message(msg.chat.id, f"❌ {r.get('message','Error')}")

@bot.message_handler(commands=['gate'])
@guard
def cmd_gate(msg):
    parts = msg.text.split()
    if len(parts) < 3:
        return bot.send_message(msg.chat.id, "Usage: /gate `<gateId>` `<on|off>`")
    gate_id = parts[1]
    enabled = parts[2].lower() in ('on', '1', 'true', 'yes')
    r = api('POST', f'/internal/admin/gates/{gate_id}', json={'enabled': enabled})
    if r.get('success'):
        icon = "🟢" if enabled else "🔴"
        bot.send_message(msg.chat.id, f"{icon} Gate `{gate_id}` {'enabled' if enabled else 'disabled'}.")
    else:
        bot.send_message(msg.chat.id, f"❌ {r.get('message','Unknown gate')}")

@bot.message_handler(commands=['announce'])
@guard
def cmd_announce(msg):
    parts = msg.text.split(maxsplit=2)
    if len(parts) < 3:
        return bot.send_message(msg.chat.id, "Usage: /announce `<type>` `<text>`\nTypes: info · warning · success · danger")
    ann_type = parts[1].lower() if parts[1].lower() in TYPE_ICONS else 'info'
    r = api('POST', '/internal/admin/announcements', json={'text': parts[2], 'type': ann_type})
    bot.send_message(msg.chat.id, "✅ Announcement posted!" if r.get('success') else f"❌ {r.get('message','Error')}")

# ── Multi-step input handler ──────────────────────────────────────────────────
@bot.message_handler(func=lambda m: m.from_user.id == ADMIN_ID and m.chat.id in _state)
def handle_state(msg):
    cid   = msg.chat.id
    state = _state.pop(cid, None)
    if not state:
        return

    step = state.get('step')
    data = state.get('data', {})

    if step == 'add_credits':
        try:
            amount = int(msg.text.strip())
        except ValueError:
            bot.send_message(cid, "❌ Invalid number. Cancelled.")
            return
        username = data['username']
        r = api('POST', '/internal/addcredit', json={'username': username, 'amount': amount})
        if r.get('success'):
            bot.send_message(cid, f"✅ Added `{amount}` cr to `{username}`\nBalance: `{r.get('newBalance','?')}`")
            text, kb = render_user(username)
            bot.send_message(cid, text, reply_markup=kb)
        else:
            bot.send_message(cid, f"❌ {r.get('message','Error')}")

    elif step == 'post_announce':
        ann_type = data['type']
        r = api('POST', '/internal/admin/announcements', json={'text': msg.text.strip(), 'type': ann_type})
        icon = TYPE_ICONS.get(ann_type, 'ℹ️')
        if r.get('success'):
            bot.send_message(cid, f"✅ {icon} Announcement posted!", reply_markup=kb_back_main())
        else:
            bot.send_message(cid, f"❌ {r.get('message','Error')}")

    elif step == 'search_user':
        username = msg.text.strip().lower().lstrip('@')
        text, kb = render_user(username)
        bot.send_message(cid, text, reply_markup=kb)

# ── Callback handler ──────────────────────────────────────────────────────────
@bot.callback_query_handler(func=lambda c: True)
def on_callback(call):
    if call.from_user.id != ADMIN_ID:
        bot.answer_callback_query(call.id, "⛔ Unauthorized.")
        return

    d   = call.data
    cid = call.message.chat.id
    mid = call.message.message_id

    def edit(text, kb):
        try:
            bot.edit_message_text(text, cid, mid, reply_markup=kb, parse_mode='Markdown')
        except Exception:
            bot.send_message(cid, text, reply_markup=kb)

    bot.answer_callback_query(call.id)

    if d == 'noop':
        return

    # ── Overview / home ──
    if d == 'm_ov':
        text, kb = render_overview()
        edit(text, kb)

    # ── Users list ──
    elif d.startswith('m_ul_'):
        page = int(d.split('_')[-1])
        text, kb = render_users(page)
        edit(text, kb)

    # ── User detail / search ──
    elif d.startswith('u_'):
        username = d[2:]
        if username == 'search':
            _state[cid] = {'step': 'search_user', 'data': {}}
            bot.send_message(cid, "🔍 Type the username to search:")
        else:
            text, kb = render_user(username)
            edit(text, kb)

    # ── Ban ──
    elif d.startswith('bn_'):
        username = d[3:]
        r = api('POST', f'/internal/admin/ban/{username}')
        if r.get('success'):
            text, kb = render_user(username)
            edit(text, kb)
        else:
            bot.send_message(cid, f"❌ {r.get('message','Error')}")

    # ── Unban ──
    elif d.startswith('ub_'):
        username = d[3:]
        r = api('POST', f'/internal/admin/unban/{username}')
        if r.get('success'):
            text, kb = render_user(username)
            edit(text, kb)
        else:
            bot.send_message(cid, f"❌ {r.get('message','Error')}")

    # ── VIP toggle ──
    elif d.startswith('vp_'):
        username = d[3:]
        users_data = api('GET', '/internal/admin/users')
        u = next((x for x in users_data.get('users', []) if x['username'] == username), None)
        new_vip = not u.get('vip', False) if u else True
        r = api('POST', f'/internal/admin/vip/{username}', json={'vip': new_vip})
        if r.get('success'):
            text, kb = render_user(username)
            edit(text, kb)
        else:
            bot.send_message(cid, f"❌ {r.get('message','Error')}")

    # ── Add credits ──
    elif d.startswith('cr_'):
        username = d[3:]
        _state[cid] = {'step': 'add_credits', 'data': {'username': username}}
        bot.send_message(cid, f"💰 Add credits to `{username}`\nSend the amount (e.g. `500`):", parse_mode='Markdown')

    # ── Gates ──
    elif d == 'm_gates':
        text, kb = render_gates()
        edit(text, kb)

    elif d.startswith('gt_'):
        # format: gt_GATEID_0or1  (rsplit on last _ to handle gate IDs with underscores)
        parts = d.rsplit('_', 1)
        enabled = parts[1] == '1'
        gate_id = parts[0][3:]  # strip 'gt_'
        r = api('POST', f'/internal/admin/gates/{gate_id}', json={'enabled': enabled})
        if r.get('success'):
            text, kb = render_gates()
            edit(text, kb)
        else:
            bot.send_message(cid, f"❌ {r.get('message','Unknown gate')}")

    # ── Announcements ──
    elif d == 'm_ann':
        text, kb = render_announcements()
        edit(text, kb)

    elif d.startswith('ap_'):
        ann_type = d[3:]
        _state[cid] = {'step': 'post_announce', 'data': {'type': ann_type}}
        icon = TYPE_ICONS.get(ann_type, 'ℹ️')
        bot.send_message(cid, f"📢 {icon} *{ann_type.capitalize()}* — Send the announcement text:", parse_mode='Markdown')

    elif d.startswith('ad_'):
        ann_id = d[3:]
        r = api('DELETE', f'/internal/admin/announcements/{ann_id}')
        if r.get('success'):
            text, kb = render_announcements()
            edit(text, kb)
        else:
            bot.send_message(cid, f"❌ {r.get('message','Error')}")

# ── Entry point ───────────────────────────────────────────────────────────────
if __name__ == '__main__':
    print("[AdminBot] Starting...")
    while True:
        try:
            bot.polling(non_stop=True, interval=1, timeout=30)
        except KeyboardInterrupt:
            print("[AdminBot] Stopped.")
            break
        except Exception as e:
            print(f"[AdminBot] Error: {e}. Restarting in 5s...")
            time.sleep(5)
