import requests

API_KEY = "ttc_65b7fc3fe38141f09bb9faeafbb2a21e692ccf23"

url = "https://tretrauchecker.com/api/check/auth"

payload = {
    "cc": "4532123412341234",
    "mm": "12",
    "yy": "2028",
    "cvv": "123",
    "gate": "stripe_auth"
}

headers = {
    "X-API-Key": API_KEY,
    "Content-Type": "application/json"
}

try:
    response = requests.post(url, json=payload, headers=headers)

    print("Status:", response.status_code)
    print("Response:")
    print(response.text)

except Exception as e:
    print("Error:", e)